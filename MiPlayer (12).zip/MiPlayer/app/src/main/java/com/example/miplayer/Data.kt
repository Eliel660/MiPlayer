package com.example.miplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

data class Song(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val durationMs: Long, val albumId: Long, val track: Int)

fun loadSongs(ctx: Context): List<Song> {
    val out = mutableListOf<Song>()
    val cols = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID,
        MediaStore.Audio.Media.TRACK
    )
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.DATE_ADDED} DESC"
    )?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            out += Song(id, c.getString(1) ?: "Sin título", c.getString(2) ?: "Desconocido", c.getString(3) ?: "",
                ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id), c.getLong(4), c.getLong(5), c.getInt(6))
        }
    }
    // Cambios hechos desde la app: se aplican enseguida, sin esperar a que Android actualice su base
    var res: List<Song> = out
    val ov = Overrides.read(ctx)
    if (ov.isNotEmpty()) {
        val keep = HashMap(ov)
        var changed = false
        res = res.map { sg ->
            val o = ov[sg.id]
            if (o == null) sg
            else if (sg.title == o.first && sg.artist == o.second && sg.album == o.third) { keep.remove(sg.id); changed = true; sg }
            else sg.copy(title = o.first, artist = o.second, album = o.third)
        }
        if (changed) Overrides.write(ctx, keep)
    }
    val tv = TrackOverrides.read(ctx)
    if (tv.isNotEmpty()) {
        val keepT = HashMap(tv)
        var changedT = false
        res = res.map { sg ->
            val t = tv[sg.id]
            if (t == null) sg
            else if (sg.track == t) { keepT.remove(sg.id); changedT = true; sg }
            else sg.copy(track = t)
        }
        if (changedT) TrackOverrides.write(ctx, keepT)
    }
    return res
}

private val Context.ds by preferencesDataStore("prefs")
private val THEME = stringPreferencesKey("theme")
private val SEED = intPreferencesKey("seed")
private val CORNER = intPreferencesKey("corner")
private val SORT = stringPreferencesKey("sort")
private val LISTS = stringPreferencesKey("playlists")
private val HIDDEN = stringSetPreferencesKey("hidden")
private val TAGS = stringPreferencesKey("tags")
private val PIN_ALBUMS = stringSetPreferencesKey("pinalbums")
private val PIN_ARTISTS = stringSetPreferencesKey("pinartists")
private val PIN_LISTS = stringSetPreferencesKey("pinlists")
private val TAG_LISTS = stringPreferencesKey("taglists")
private val ART = booleanPreferencesKey("arttheme")
private val MIX = booleanPreferencesKey("mix")
private val RESUME_HS = booleanPreferencesKey("resumehs")
private val SLOW_MIX = booleanPreferencesKey("slowmix")
private val SLOW_DEPTH = intPreferencesKey("slowdepth")
private val VINYL_PORTRAIT = booleanPreferencesKey("vinylportrait")
private val SILENCE = booleanPreferencesKey("silence")
private val CF_ON = booleanPreferencesKey("cfon")
private val CF_SEC = intPreferencesKey("cfsec")
private val CHIP = booleanPreferencesKey("chip")
private val NOTE_STYLE = stringPreferencesKey("notestyle")
private val PARTICLES = stringPreferencesKey("particles")
private val VINYLS = stringPreferencesKey("vinyls")
private val TEXT_SCALE = intPreferencesKey("textscale")
private val LYRICS_SCALE = intPreferencesKey("lyricsscale")
private val SHUFFLE = booleanPreferencesKey("shuffle")

class Prefs(private val ctx: Context) {
    val mode = ctx.ds.data.map { it[THEME] ?: "system" }
    val seed = ctx.ds.data.map { it[SEED] ?: -2 }
    val corner = ctx.ds.data.map { it[CORNER] ?: 50 }
    val sort = ctx.ds.data.map { it[SORT] ?: "new" }
    val artTheme = ctx.ds.data.map { it[ART] ?: true }
    val mix = ctx.ds.data.map { it[MIX] ?: false }
    /** Retomar solo al conectar auriculares si la música se pausó porque los desconectaste. */
    val resumeHeadset = ctx.ds.data.map { it[RESUME_HS] ?: true }
    suspend fun setResumeHeadset(v: Boolean) { ctx.ds.edit { it[RESUME_HS] = v } }
    /** Al mezclar, la canción que se va se ralentiza un poquito. */
    val slowMix = ctx.ds.data.map { it[SLOW_MIX] ?: true }
    suspend fun setSlowMix(v: Boolean) { ctx.ds.edit { it[SLOW_MIX] = v } }
    /** Cuánto se frena la canción que se va (en %): más es más notorio. */
    val slowDepth = ctx.ds.data.map { it[SLOW_DEPTH] ?: 14 }
    suspend fun setSlowDepth(v: Int) { ctx.ds.edit { it[SLOW_DEPTH] = v } }
    /** En el reproductor vertical, el disco de vinilo con el brazo en lugar de la portada cuadrada. */
    val vinylPortrait = ctx.ds.data.map { it[VINYL_PORTRAIT] ?: false }
    suspend fun setVinylPortrait(v: Boolean) { ctx.ds.edit { it[VINYL_PORTRAIT] = v } }
    val silence = ctx.ds.data.map { it[SILENCE] ?: false }
    val crossfadeOn = ctx.ds.data.map { it[CF_ON] ?: false }
    val crossfadeSec = ctx.ds.data.map { it[CF_SEC] ?: 6 }
    /** Diseño del vinilo de cada álbum (por nombre de álbum). */
    val vinyls = ctx.ds.data.map { p ->
        val o = JSONObject(p[VINYLS] ?: "{}")
        o.keys().asSequence().associateWith { k -> o.getJSONObject(k).let { j -> VinylDesign(j.getString("t"), j.getInt("a"), j.getInt("b")) } }
    }
    suspend fun saveVinyl(album: String, d: VinylDesign?) {
        ctx.ds.edit { p ->
            val o = JSONObject(p[VINYLS] ?: "{}")
            if (d == null) o.remove(album) else o.put(album, JSONObject().put("t", d.texture).put("a", d.c1).put("b", d.c2))
            p[VINYLS] = o.toString()
        }
    }
    val noteStyle = ctx.ds.data.map { it[NOTE_STYLE] ?: "theme" }
    val particles = ctx.ds.data.map { it[PARTICLES] ?: "both" }
    val chip = ctx.ds.data.map { it[CHIP] ?: true }
    val textScale = ctx.ds.data.map { it[TEXT_SCALE] ?: 100 }
    val lyricsScale = ctx.ds.data.map { it[LYRICS_SCALE] ?: 100 }
    val shuffleOn = ctx.ds.data.map { it[SHUFFLE] ?: false }
    val hidden = ctx.ds.data.map { p -> (p[HIDDEN] ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet() }

    suspend fun setMode(m: String) { ctx.ds.edit { it[THEME] = m } }
    suspend fun setSeed(i: Int) { ctx.ds.edit { it[SEED] = i } }
    suspend fun setCorner(i: Int) { ctx.ds.edit { it[CORNER] = i } }
    suspend fun setSort(v: String) { ctx.ds.edit { it[SORT] = v } }
    suspend fun setArt(v: Boolean) { ctx.ds.edit { it[ART] = v } }
    suspend fun setMix(v: Boolean) { ctx.ds.edit { it[MIX] = v } }
    suspend fun setSilence(v: Boolean) { ctx.ds.edit { it[SILENCE] = v } }
    suspend fun setCrossfadeOn(v: Boolean) { ctx.ds.edit { it[CF_ON] = v } }
    suspend fun setCrossfadeSec(v: Int) { ctx.ds.edit { it[CF_SEC] = v } }
    suspend fun setNoteStyle(v: String) { ctx.ds.edit { it[NOTE_STYLE] = v } }
    suspend fun setParticles(v: String) { ctx.ds.edit { it[PARTICLES] = v } }
    suspend fun setChip(v: Boolean) { ctx.ds.edit { it[CHIP] = v } }
    suspend fun setTextScale(v: Int) { ctx.ds.edit { it[TEXT_SCALE] = v } }
    suspend fun setLyricsScale(v: Int) { ctx.ds.edit { it[LYRICS_SCALE] = v } }
    suspend fun setShuffle(v: Boolean) { ctx.ds.edit { it[SHUFFLE] = v } }
    /** Para la copia de seguridad: listas, diseños de vinilo y canciones ocultas. */
    suspend fun backupJson(): String {
        val p = ctx.ds.data.first()
        return JSONObject().put("playlists", p[LISTS] ?: "{}").put("vinyls", p[VINYLS] ?: "{}")
            .put("hidden", JSONArray((p[HIDDEN] ?: emptySet()).toList())).put("tags", p[TAGS] ?: "[]").toString()
    }
    suspend fun restoreJson(s: String) {
        val o = JSONObject(s)
        val h = o.optJSONArray("hidden")
        val hid = if (h == null) emptySet() else List(h.length()) { h.getString(it) }.toSet()
        ctx.ds.edit { p ->
            p[LISTS] = o.optString("playlists", "{}")
            p[VINYLS] = o.optString("vinyls", "{}")
            p[HIDDEN] = hid
            if (o.has("tags")) p[TAGS] = o.optString("tags", "[]")
        }
    }
    /** Álbumes y artistas fijados arriba de su pestaña. */
    val pinnedAlbums = ctx.ds.data.map { it[PIN_ALBUMS] ?: emptySet() }
    val pinnedArtists = ctx.ds.data.map { it[PIN_ARTISTS] ?: emptySet() }
    val pinnedLists = ctx.ds.data.map { it[PIN_LISTS] ?: emptySet() }
    suspend fun togglePin(kind: String, key: String) {
        val k = when (kind) { "album" -> PIN_ALBUMS; "list" -> PIN_LISTS; else -> PIN_ARTISTS }
        ctx.ds.edit { val cur = it[k] ?: emptySet(); it[k] = if (key in cur) cur - key else cur + key }
    }
    /** Etiquetas propias (SE = Stem edit, Demo, R = Remix...). Van adelante del título. */
    val tags = ctx.ds.data.map { parseTags(it[TAGS]) }
    suspend fun saveTags(list: List<Tag>) { ctx.ds.edit { it[TAGS] = tagsToJson(list) } }
    suspend fun hide(id: Long) { ctx.ds.edit { it[HIDDEN] = (it[HIDDEN] ?: emptySet()) + id.toString() } }
    suspend fun unhide(id: Long) { ctx.ds.edit { it[HIDDEN] = (it[HIDDEN] ?: emptySet()) - id.toString() } }

    /** Listas de reproducción: nombre -> ids de canciones (guardadas como JSON). */
    val playlists = ctx.ds.data.map { p ->
        val o = JSONObject(p[LISTS] ?: "{}")
        o.keys().asSequence().filter { it.isNotBlank() }.associateWith { k -> o.getJSONArray(k).let { a -> List(a.length()) { a.getLong(it) } } }
    }
    suspend fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        ctx.ds.edit { it[LISTS] = o.toString() }
    }

    /** Listas creadas por etiqueta: nombre de la lista → (texto de la etiqueta, versión o null). Se mantienen solas. */
    val tagLists = ctx.ds.data.map { p ->
        runCatching {
            val o = JSONObject(p[TAG_LISTS] ?: "{}")
            o.keys().asSequence().associateWith { k -> o.getJSONObject(k).let { j -> j.getString("t") to j.optString("v", "").ifBlank { null } } }
        }.getOrDefault(emptyMap())
    }

    suspend fun saveTagList(name: String, tag: String, variant: String?) {
        ctx.ds.edit { p ->
            val o = runCatching { JSONObject(p[TAG_LISTS] ?: "{}") }.getOrDefault(JSONObject())
            o.put(name, JSONObject().put("t", tag).put("v", variant ?: ""))
            p[TAG_LISTS] = o.toString()
        }
    }

    /** Actualiza solo las listas que ya existen, sin tocar las demás: saca lo que ya no cumple y suma lo nuevo al final. */
    suspend fun syncExistingLists(updates: Map<String, List<Long>>) {
        ctx.ds.edit { p ->
            val o = runCatching { JSONObject(p[LISTS] ?: "{}") }.getOrDefault(JSONObject())
            var changed = false
            for ((name, ids) in updates) {
                if (!o.has(name)) continue
                val want = ids.toSet()
                val old = o.getJSONArray(name).let { a -> List(a.length()) { a.getLong(it) } }
                val oldSet = old.toSet()
                val res = old.filter { it in want } + ids.filter { it !in oldSet }
                if (res != old) { o.put(name, JSONArray(res)); changed = true }
            }
            if (changed) p[LISTS] = o.toString()
        }
    }
}

/** "Victoria Justice, Ariana Grande" cuenta como dos artistas: la misma canción aparece en los dos. */
fun splitArtists(s: String): List<String> = s.split(',').map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf(s) }

/** Número de pista cambiado desde la app (se ve al instante, hasta que Android actualice su base). */
object TrackOverrides {
    private fun file(ctx: Context) = java.io.File(ctx.filesDir, "tracks.json")

    fun read(ctx: Context): Map<Long, Int> = runCatching {
        val f = file(ctx)
        if (!f.exists()) return@runCatching emptyMap<Long, Int>()
        val o = JSONObject(f.readText())
        o.keys().asSequence().associate { k -> k.toLong() to o.getInt(k) }
    }.getOrDefault(emptyMap())

    fun write(ctx: Context, m: Map<Long, Int>) {
        runCatching {
            val o = JSONObject()
            m.forEach { (k, v) -> o.put(k.toString(), v) }
            file(ctx).writeText(o.toString())
        }
    }

    fun save(ctx: Context, id: Long, track: Int) { write(ctx, read(ctx) + (id to track)) }
}

/** Una etiqueta: el texto corto que va adelante del título y un nombre completo para entenderla y buscarla. */
class Tag(val short: String, val name: String)

fun parseTags(json: String?): List<Tag> = runCatching {
    val a = JSONArray(json ?: "[]")
    List(a.length()) { i -> a.getJSONObject(i).let { Tag(it.getString("s"), it.optString("n", "")) } }
}.getOrDefault(emptyList())

fun tagsToJson(list: List<Tag>): String {
    val a = JSONArray()
    list.forEach { a.put(JSONObject().put("s", it.short).put("n", it.name)) }
    return a.toString()
}

/** Versiones de una etiqueta: "D-AD-PD" son tres (D, AD y PD); "SE" es una sola. */
fun tagVariants(t: Tag): List<String> = t.short.split('-').filter { it.isNotBlank() }
