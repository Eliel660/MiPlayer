package com.example.miplayer

import android.content.Context
import android.media.audiofx.Equalizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Crossfade, escrito de cero. Ideas clave:
 *  1) Todo el trabajo pesado se hace ANTES (se prepara un segundo reproductor con el final de la canción actual).
 *  2) El segundo reproductor suena en silencio y se corrige de velocidad hasta quedar clavado con el principal.
 *  3) El traspaso entre las dos copias de la MISMA canción es lineal y corto (suma de volúmenes constante, sin salto).
 *  4) La mezcla real (canción 1 que baja, canción 2 que sube) la maneja el reloj de la canción 2, no el reloj de pared:
 *     así la canción nueva siempre entra desde silencio, sin chasquidos, aunque tarde en arrancar.
 *  5) La mezcla dura lo que queda de la canción 1, así termina justo cuando ella termina.
 */
class Crossfader(
    private val ctx: Context,
    private val main: ExoPlayer,
    private val attrs: AudioAttributes,
    private val equalizer: () -> Equalizer?,
    private val seconds: () -> Int,
    private val shuffleOn: () -> Boolean
) {
    private enum class Phase { IDLE, READY, ALIGN, SWAP, MIX }

    private var phase = Phase.IDLE
    private var tail: ExoPlayer? = null
    private var tailEq: Equalizer? = null
    private var itemId = ""
    private var phaseAt = 0L
    private var stable = 0
    private var speed = 1f
    private var mixMs = 1L
    private var mixNextId = ""

    /** Cada cuánto conviene que corra el reloj: más seguido mientras se mezcla. */
    fun interval(): Long = when (phase) {
        Phase.IDLE -> 150L
        Phase.SWAP, Phase.MIX -> 20L
        else -> 40L
    }

    fun tick(now: Long) {
        when (phase) {
            Phase.MIX -> mix(now)
            Phase.SWAP -> swap(now)
            else -> watch(now)
        }
    }

    private fun watch(now: Long) {
        val sec = seconds()
        if (sec <= 0 || main.mediaItemCount < 2 || !main.hasNextMediaItem() || main.repeatMode == Player.REPEAT_MODE_ONE) {
            if (phase != Phase.IDLE) release()
            return
        }
        val ms = sec * 1000L
        val dur = main.duration
        if (dur == C.TIME_UNSET || dur < ms + 9000L) { if (phase != Phase.IDLE) release(); return }
        val left = dur - main.currentPosition
        val id = main.currentMediaItem?.mediaId ?: ""
        // si cambió la canción o movieron la barra, se descarta lo preparado
        if (phase != Phase.IDLE && (id != itemId || left > ms + 9000L)) { release(); return }
        when (phase) {
            Phase.IDLE -> if (main.isPlaying && left in (ms + 4000L)..(ms + 7500L)) prepare(id)
            Phase.READY -> if (left <= ms + 2500L) startAligning(now)
            Phase.ALIGN -> align(now, left, ms)
            else -> {}
        }
    }

    /** Unos segundos antes: deja listo, y ya cargado, el segundo reproductor con la misma canción. */
    private fun prepare(id: String) {
        val item = main.currentMediaItem ?: return
        val t = ExoPlayer.Builder(ctx).setAudioAttributes(attrs, false).build()
        t.volume = 0f
        t.setMediaItem(item)
        t.prepare()
        t.seekTo(main.currentPosition)
        t.playWhenReady = false
        // mismo ecualizador que el principal, para que no se note el cambio
        tailEq = equalizer()?.let { src ->
            runCatching {
                Equalizer(0, t.audioSessionId).also { e2 ->
                    e2.enabled = true
                    for (b in 0 until src.numberOfBands) e2.setBandLevel(b.toShort(), src.getBandLevel(b.toShort()))
                }
            }.getOrNull()
        }
        tail = t; itemId = id; phase = Phase.READY
    }

    /** Lo hace sonar en silencio, un poco adelantado, para que se alinee con el principal. */
    private fun startAligning(now: Long) {
        val t = tail ?: run { phase = Phase.IDLE; return }
        t.seekTo(main.currentPosition + 150)
        t.volume = 0f
        t.playWhenReady = true
        phaseAt = now; phase = Phase.ALIGN; stable = 0; speed = 1f
    }

    /** Corrige su velocidad (en silencio) hasta quedar a pocos milisegundos del principal; recién ahí se hace el traspaso. */
    private fun align(now: Long, left: Long, ms: Long) {
        val t = tail ?: run { release(); return }
        t.playWhenReady = main.playWhenReady
        var aligned = false
        if (t.isPlaying && main.isPlaying) {
            val err = t.currentPosition - main.currentPosition      // positivo: va adelantado
            val target = if (abs(err) <= 8L) 1f else (1f - err / 500f).coerceIn(0.85f, 1.2f)
            if (target != speed) { t.setPlaybackParameters(PlaybackParameters(target)); speed = target }
            if (abs(err) <= 10L && speed == 1f) stable++ else stable = 0
            aligned = stable >= 10
        }
        if ((left <= ms && aligned) || left <= ms - 500L || now - phaseAt > 6000L) {
            mixMs = min(ms, max(left, 1500L))      // la mezcla termina justo cuando termina la canción
            phase = Phase.SWAP; phaseAt = now
        }
    }

    /** Traspaso de 80 ms entre las dos copias de la misma canción. Lineal: la suma de volúmenes no cambia. */
    private fun swap(now: Long) {
        val t = tail ?: run { release(); return }
        val f = ((now - phaseAt) / 80f).coerceIn(0f, 1f)
        main.volume = 1f - f
        t.volume = f
        t.playWhenReady = main.playWhenReady
        if (f >= 1f) beginMix(now)
    }

    private fun beginMix(now: Long) {
        val wasLast = main.currentMediaItemIndex == main.mediaItemCount - 1
        val ni = main.nextMediaItemIndex
        mixNextId = if (ni != C.INDEX_UNSET) main.getMediaItemAt(ni).mediaId else ""
        main.volume = 0f
        main.seekToNextMediaItem()
        if (wasLast && shuffleOn()) shuffleRest(main)
        phase = Phase.MIX; phaseAt = now
    }

    /** La canción nueva sube con su propio reloj, la vieja (en el segundo reproductor) baja. Potencia constante. */
    private fun mix(now: Long) {
        val t = tail ?: run { release(); return }
        t.playWhenReady = main.playWhenReady
        val elapsed = now - phaseAt
        val started = main.currentMediaItem?.mediaId == mixNextId && main.isPlaying && main.currentPosition > 0
        val f = when {
            started -> (main.currentPosition.toFloat() / mixMs).coerceIn(0f, 1f)
            elapsed > 2500L -> ((elapsed - 2500L).toFloat() / mixMs).coerceIn(0f, 1f)
            else -> 0f
        }
        main.volume = sqrt(f)
        t.volume = sqrt(1f - f)
        if (f >= 1f) release()
    }

    private fun release() {
        runCatching { tail?.release() }; tail = null
        runCatching { tailEq?.release() }; tailEq = null
        phase = Phase.IDLE; stable = 0; speed = 1f
        runCatching { main.volume = 1f }
    }
}
