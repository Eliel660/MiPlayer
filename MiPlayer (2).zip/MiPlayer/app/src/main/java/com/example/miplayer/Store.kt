package com.example.miplayer

import android.content.Context
import android.net.Uri
import java.io.DataInputStream
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

/** Letras y anotaciones guardadas por la persona (un archivo de texto por canción). */
object Store {
    private fun f(ctx: Context, dir: String, id: Long): File = File(File(ctx.filesDir, dir).apply { mkdirs() }, "$id.txt")
    fun read(ctx: Context, dir: String, id: Long): String =
        runCatching { f(ctx, dir, id).takeIf { it.exists() }?.readText() ?: "" }.getOrDefault("")
    /** Cuándo se hizo la nota (se guarda la primera vez); si no hay dato, la fecha del archivo. */
    fun noteTime(ctx: Context, id: Long): Long =
        read(ctx, "notets", id).trim().toLongOrNull() ?: maxOf(f(ctx, "notes", id).lastModified(), f(ctx, "status", id).lastModified())

    /** Ids de canciones que tienen archivo (no vacío) en esa carpeta: notas, estados, letras. */
    fun idsWith(ctx: Context, dir: String): Set<Long> =
        File(ctx.filesDir, dir).listFiles()?.mapNotNull { f -> if (f.length() > 0) f.nameWithoutExtension.toLongOrNull() else null }?.toSet() ?: emptySet()

    fun write(ctx: Context, dir: String, id: Long, text: String) {
        runCatching { val file = f(ctx, dir, id); if (text.isBlank()) file.delete() else file.writeText(text) }
    }
}

private val tsRegex = Regex("""\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\]""")
private val tagRegex = Regex("""^\[[A-Za-z]+:[^\]]*\]\s*$""")

/** Saca las marcas de tiempo de un .lrc para dejar solo el texto. */
fun cleanLyrics(raw: String): String = raw.replace("\r\n", "\n").replace('\r', '\n').lines()
    .filterNot { tagRegex.matches(it.trim()) }
    .joinToString("\n") { tsRegex.replace(it, "").trim() }
    .trim()

/** Primero la letra guardada por la persona; si no hay, la que trae el archivo (MP3). */
fun loadLyrics(ctx: Context, s: Song): String {
    val saved = Store.read(ctx, "lyrics", s.id)
    if (saved.isNotBlank()) return cleanLyrics(saved)
    return cleanLyrics(id3Lyrics(ctx, s.uri) ?: "")
}

internal fun synch(b: ByteArray, o: Int) = ((b[o].toInt() and 0x7F) shl 21) or ((b[o + 1].toInt() and 0x7F) shl 14) or
    ((b[o + 2].toInt() and 0x7F) shl 7) or (b[o + 3].toInt() and 0x7F)
internal fun be32(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or
    ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)

fun id3Lyrics(ctx: Context, uri: Uri): String? = runCatching {
    ctx.contentResolver.openInputStream(uri)?.use { raw ->
        val din = DataInputStream(raw.buffered())
        val h = ByteArray(10); din.readFully(h)
        if (String(h, 0, 3, Charsets.ISO_8859_1) != "ID3") return@use null
        val ver = h[3].toInt()
        if (ver < 3) return@use null
        val size = synch(h, 6).coerceIn(0, 8_000_000)
        val tag = ByteArray(size); din.readFully(tag)
        var p = 0
        if ((h[5].toInt() and 0x40) != 0 && tag.size >= 4) p = if (ver == 4) synch(tag, 0) else be32(tag, 0) + 4
        while (p + 10 <= tag.size) {
            if (tag[p].toInt() == 0) break
            val id = String(tag, p, 4, Charsets.ISO_8859_1)
            val fs = if (ver == 4) synch(tag, p + 4) else be32(tag, p + 4)
            if (fs <= 0 || p + 10 + fs > tag.size) break
            if (id == "USLT") return@use decodeUslt(tag, p + 10, p + 10 + fs)
            p += 10 + fs
        }
        null
    }
}.getOrNull()

private fun decodeUslt(t: ByteArray, s: Int, e: Int): String? {
    if (e - s < 5) return null
    val enc = t[s].toInt()
    var i = s + 4
    val start: Int
    if (enc == 0 || enc == 3) { while (i < e && t[i].toInt() != 0) i++; start = i + 1 }
    else { while (i + 1 < e && !(t[i].toInt() == 0 && t[i + 1].toInt() == 0)) i += 2; start = i + 2 }
    if (start >= e) return null
    val cs = when (enc) { 0 -> Charsets.ISO_8859_1; 1 -> Charsets.UTF_16; 2 -> Charsets.UTF_16BE; else -> Charsets.UTF_8 }
    return String(t, start, e - start, cs).trim('\u0000', ' ', '\n', '\r').ifBlank { null }
}

private fun skipFully(i: java.io.InputStream, n: Long): Boolean {
    var left = n
    while (left > 0) {
        val s = i.skip(left)
        if (s <= 0) { if (i.read() < 0) return false; left-- } else left -= s
    }
    return true
}

fun hasSavedLyrics(ctx: Context, id: Long): Boolean = Store.read(ctx, "lyrics", id).isNotBlank()

/** Recorre solo los encabezados de la etiqueta ID3 (salteando el contenido) para ver si hay un cuadro de letra. */
fun hasEmbeddedLyrics(ctx: Context, uri: Uri): Boolean = runCatching {
    ctx.contentResolver.openInputStream(uri)?.use { raw ->
        val din = DataInputStream(raw)
        val h = ByteArray(10); din.readFully(h)
        if (String(h, 0, 3, Charsets.ISO_8859_1) != "ID3") return@use false
        val ver = h[3].toInt()
        if (ver < 3) return@use false
        val total = synch(h, 6)
        var pos = 0
        if ((h[5].toInt() and 0x40) != 0) {
            val eh = ByteArray(4); din.readFully(eh)
            val sz = if (ver == 4) synch(eh, 0) else be32(eh, 0) + 4
            if (!skipFully(din, (sz - 4).toLong())) return@use false
            pos = sz
        }
        val fh = ByteArray(10)
        while (pos + 10 <= total) {
            din.readFully(fh)
            if (fh[0].toInt() == 0) return@use false
            val id = String(fh, 0, 4, Charsets.ISO_8859_1)
            val fs = if (ver == 4) synch(fh, 4) else be32(fh, 4)
            if (id == "USLT") return@use fs > 6
            if (fs < 0 || !skipFully(din, fs.toLong())) return@use false
            pos += 10 + fs
        }
        false
    } ?: false
}.getOrDefault(false)

/** Nombre, artista y álbum cambiados desde la app. Se muestran enseguida aunque Android tarde en enterarse. */
object Overrides {
    private fun file(ctx: Context) = File(ctx.filesDir, "overrides.json")

    fun read(ctx: Context): Map<Long, Triple<String, String, String>> = runCatching {
        val f = file(ctx)
        if (!f.exists()) return@runCatching emptyMap<Long, Triple<String, String, String>>()
        val o = JSONObject(f.readText())
        o.keys().asSequence().associate { k ->
            val a = o.getJSONArray(k)
            k.toLong() to Triple(a.getString(0), a.getString(1), a.getString(2))
        }
    }.getOrDefault(emptyMap())

    fun write(ctx: Context, m: Map<Long, Triple<String, String, String>>) {
        runCatching {
            val o = JSONObject()
            m.forEach { (k, v) -> o.put(k.toString(), JSONArray(listOf(v.first, v.second, v.third))) }
            file(ctx).writeText(o.toString())
        }
    }

    fun save(ctx: Context, id: Long, title: String, artist: String, album: String) {
        write(ctx, read(ctx) + (id to Triple(title, artist, album)))
    }
}

private val diac = Regex("\\p{InCombiningDiacriticalMarks}+")
private fun nk(s: String): String =
    diac.replace(java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD), "").lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()

/**
 * Recorre una carpeta elegida por la persona, busca archivos .lrc y .txt y los asigna a las canciones por nombre
 * ("Título", "Artista - Título" o "Título - Artista"). No pisa letras que ya existen. Devuelve cuántas importó.
 */
fun importLyrics(ctx: Context, tree: Uri, songs: List<Song>): Int {
    val files = mutableListOf<Pair<String, Uri>>()
    fun walk(docId: String, depth: Int) {
        if (depth > 6) return
        val kids = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        ctx.contentResolver.query(
            kids,
            arrayOf(
                android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE
            ), null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val name = c.getString(1) ?: ""
                val mime = c.getString(2) ?: ""
                if (mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) walk(id, depth + 1)
                else if (name.endsWith(".lrc", true) || name.endsWith(".txt", true)) {
                    files += name to android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id)
                }
            }
        }
    }
    runCatching { walk(android.provider.DocumentsContract.getTreeDocumentId(tree), 0) }
    val keys = songs.map { s -> s to setOf(nk(s.title), nk("${s.artist} ${s.title}"), nk("${s.title} ${s.artist}")) }
    var n = 0
    for ((name, uri) in files) {
        val base = nk(name.substringBeforeLast('.'))
        if (base.isBlank()) continue
        val hit = keys.firstOrNull { (_, ks) -> base in ks }
            ?: keys.firstOrNull { (s, _) -> val t = nk(s.title); t.length >= 5 && base.contains(t) }
        if (hit != null && !hasSavedLyrics(ctx, hit.first.id)) {
            val text = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
            if (!text.isNullOrBlank()) { Store.write(ctx, "lyrics", hit.first.id, text); n++ }
        }
    }
    return n
}

/** Cuántas veces se escuchó cada canción (se cuenta al pasar 20 segundos de reproducción). */
object Plays {
    private var cache: HashMap<Long, Int>? = null
    private fun file(ctx: Context) = File(ctx.filesDir, "plays.json")

    private fun ensure(ctx: Context): HashMap<Long, Int> {
        cache?.let { return it }
        val m = HashMap<Long, Int>()
        runCatching {
            val f = file(ctx)
            if (f.exists()) {
                val o = JSONObject(f.readText())
                o.keys().forEach { k -> m[k.toLong()] = o.getInt(k) }
            }
        }
        cache = m
        return m
    }

    @Synchronized fun all(ctx: Context): Map<Long, Int> = HashMap(ensure(ctx))

    @Synchronized fun inc(ctx: Context, id: Long) {
        val m = ensure(ctx)
        m[id] = (m[id] ?: 0) + 1
        runCatching {
            val o = JSONObject()
            m.forEach { (k, v) -> o.put(k.toString(), v) }
            file(ctx).writeText(o.toString())
        }
    }
}
