@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
package com.example.miplayer

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import java.util.Calendar
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.core.app.NotificationManagerCompat
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import android.content.res.Configuration
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.ensureActive
import kotlin.random.Random
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

object LocalContextHolder { lateinit var ctx: android.content.Context }

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        LocalContextHolder.ctx = applicationContext
        startService(Intent(this, PlaybackService::class.java))
        // Un control conectado asegura que la notificación del reproductor aparezca siempre.
        runCatching {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerFuture = MediaController.Builder(this, token).buildAsync()
        }
        setContent {
            val prefs = remember { Prefs(this) }
            val mode by prefs.mode.collectAsState("system")
            val seed by prefs.seed.collectAsState(-2)
            val corner by prefs.corner.collectAsState(50)
            val artTheme by prefs.artTheme.collectAsState(true)
            val textScale by prefs.textScale.collectAsState(100)
            val lyricsScale by prefs.lyricsScale.collectAsState(100)
            val noteStyle by prefs.noteStyle.collectAsState("theme")
            val particles by prefs.particles.collectAsState("both")
            val d = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * textScale / 100f)) {
                MiPlayerTheme(mode, seed) {
                    CompositionLocalProvider(LocalCorner provides corner, LocalArtTheme provides artTheme, LocalLyricsScale provides lyricsScale,
                        LocalNoteStyle provides noteStyle, LocalParticles provides particles, LocalThemeSeed provides seed) {
                        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Root(prefs, mode, seed) }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

// ───────────── estado del reproductor ─────────────

private class PState(val playing: Boolean, val mediaId: String, val title: String, val artist: String, val repeat: Int)
private class QState(val items: List<MediaItem>, val index: Int)

@Composable
private fun rememberPState(p: Player): State<PState> {
    fun snap(): PState {
        val cv = CrossView.item   // durante la mezcla se muestra la canción nueva
        return if (cv != null) PState(p.isPlaying, cv.mediaId, cv.mediaMetadata.title?.toString() ?: "", cv.mediaMetadata.artist?.toString() ?: "", p.repeatMode)
        else PState(p.isPlaying, p.currentMediaItem?.mediaId ?: "", p.mediaMetadata.title?.toString() ?: "",
            p.mediaMetadata.artist?.toString() ?: "", p.repeatMode)
    }
    val st = remember { mutableStateOf(snap()) }
    LaunchedEffect(Unit) {
        var v = CrossView.version
        while (true) { delay(100); if (CrossView.version != v) { v = CrossView.version; st.value = snap() } }
    }
    DisposableEffect(p) {
        val l = object : Player.Listener { override fun onEvents(pl: Player, e: Player.Events) { st.value = snap() } }
        p.addListener(l); onDispose { p.removeListener(l) }
    }
    return st
}

@Composable
private fun rememberQueue(p: Player): State<QState> {
    fun snap() = QState(List(p.mediaItemCount) { p.getMediaItemAt(it) }, p.currentMediaItemIndex)
    val st = remember { mutableStateOf(snap()) }
    DisposableEffect(p) {
        val l = object : Player.Listener {
            override fun onEvents(pl: Player, e: Player.Events) {
                if (e.containsAny(Player.EVENT_TIMELINE_CHANGED, Player.EVENT_MEDIA_ITEM_TRANSITION)) st.value = snap()
            }
        }
        p.addListener(l); onDispose { p.removeListener(l) }
    }
    return st
}

@Composable
private fun rememberPos(p: Player): State<Long> = produceState(p.currentPosition) {
    while (true) { value = if (CrossView.item != null) CrossView.posMs else p.currentPosition; delay(250) }
}

private fun toItem(s: Song): MediaItem = MediaItem.Builder().setMediaId(s.id.toString()).setUri(s.uri).setMediaMetadata(
    MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album)
        .setArtworkUri(Uri.parse("content://media/external/audio/albumart/${s.albumId}")).build()
).build()

/** Arma la fila: en orden tal cual la lista, o en aleatorio con la canción elegida primero. */
private fun playList(p: Player, list: List<Song>, start: Int, shuffle: Boolean) {
    val l = list.distinctBy { it.id }
    if (l.isEmpty()) return
    val startId = list.getOrNull(start)?.id
    val first = l.firstOrNull { it.id == startId } ?: l.first()
    val ordered = if (shuffle) listOf(first) + l.filter { it.id != first.id }.shuffled() else l
    val idx = ordered.indexOfFirst { it.id == first.id }
    p.setMediaItems(ordered.map { toItem(it) }, idx, 0)
    p.repeatMode = Player.REPEAT_MODE_ALL
    p.prepare(); p.play()
}

private fun indexOfId(p: Player, id: String): Int {
    for (i in 0 until p.mediaItemCount) if (p.getMediaItemAt(i).mediaId == id) return i
    return -1
}

private fun playNext(p: Player, s: Song) {
    if (p.mediaItemCount == 0) { playList(p, listOf(s), 0, false); return }
    val cur = p.currentMediaItemIndex
    val ex = indexOfId(p, s.id.toString())
    when {
        ex == cur -> {}
        ex < 0 -> p.addMediaItem(cur + 1, toItem(s))
        ex < cur -> p.moveMediaItem(ex, cur)
        else -> p.moveMediaItem(ex, cur + 1)
    }
}

private fun addToQueue(p: Player, s: Song) {
    if (p.mediaItemCount == 0) { playList(p, listOf(s), 0, false); return }
    if (indexOfId(p, s.id.toString()) < 0) p.addMediaItem(toItem(s))
}

private fun clearQueue(p: Player) {
    val n = p.mediaItemCount
    val cur = p.currentMediaItemIndex
    p.removeMediaItems(cur + 1, n)
    p.removeMediaItems(0, cur)
}

private val diacritics = Regex("\\p{InCombiningDiacriticalMarks}+")
/** Texto sin tildes ni mayúsculas, para que la búsqueda no sea estricta. */
private fun norm(s: String): String = diacritics.replace(java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD), "").lowercase()

// ───────────── piezas reutilizables ─────────────

@Composable
private fun Art(song: Song?, size: Int, modifier: Modifier, corner: Dp? = null) {
    val ctx = LocalContext.current
    val rad = corner ?: cr(LocalCorner.current, 24)
    val ver = ArtState.version
    val bmp by produceState<Bitmap?>(if (song != null) peekArt(song.uri, size) else null, song?.id, size, ver) {
        value = if (song == null) null else withContext(Dispatchers.IO) { loadArtBitmap(ctx, song.uri, song.albumId, size) }
    }
    Box(modifier.clip(RoundedCornerShape(rad)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
    }
}

/** Barra de progreso gruesa y redondeada, se toca o se arrastra. */
@Composable
private fun SeekBar(pos: Long, dur: Long, onSeek: (Long) -> Unit, modifier: Modifier, height: Dp, track: Color, fill: Color) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = drag ?: (pos.toFloat() / dur.coerceAtLeast(1L)).coerceIn(0f, 1f)
    val dragging = drag != null
    // las barritas aparecen solo mientras se arrastra la barra
    val show = remember { Animatable(0f) }
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(dragging) {
        if (dragging) {
            launch { show.animateTo(1f, tween(160)) }
            while (true) withFrameNanos { phase = (it / 1_000_000L % 1200L) / 1200f * 6.2832f }
        } else show.animateTo(0f, tween(220))
    }
    Box(
        modifier.height(height + 18.dp)
            .drawWithContent {
                drawContent()
                val a = show.value
                if (a > 0.01f) {
                    val n = 13
                    val bw = 3.dp.toPx()
                    val gap = 3.dp.toPx()
                    val total = n * bw + (n - 1) * gap
                    val x0 = (frac * size.width - total / 2f).coerceIn(0f, (size.width - total).coerceAtLeast(0f))
                    val bottom = size.height / 2f - height.toPx() / 2f - 6.dp.toPx()
                    val maxH = 34.dp.toPx()
                    for (i in 0 until n) {
                        val wave = abs(sin(phase * (1f + (i % 3) * 0.5f) + i * 0.9f))
                        val bh = maxH * (0.22f + 0.78f * wave) * a
                        drawRoundRect(fill.copy(alpha = 0.9f * a), Offset(x0 + i * (bw + gap), bottom - bh), Size(bw, bh), CornerRadius(bw / 2f))
                    }
                }
            }
            .pointerInput(dur) { detectTapGestures { o -> onSeek((o.x / size.width * dur).toLong()) } }
            .pointerInput(dur) {
                detectHorizontalDragGestures(
                    onDragStart = { drag = (it.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { drag?.let { f -> onSeek((f * dur).toLong()) }; drag = null },
                    onDragCancel = { drag = null },
                    onHorizontalDrag = { change, _ -> change.consume(); drag = (change.position.x / size.width).coerceIn(0f, 1f) }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(track)) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(RoundedCornerShape(50)).background(fill))
        }
    }
}

/** Barra fina para subir y bajar rápido por listas largas. Se mueve de forma continua. */
@Composable
private fun FastScroller(state: LazyListState, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    var dragging by remember { mutableStateOf(false) }
    var visible by remember { mutableStateOf(false) }
    var dragFrac by remember { mutableFloatStateOf(0f) }
    val info = state.layoutInfo
    val total = info.totalItemsCount
    val itemSize = (info.visibleItemsInfo.firstOrNull()?.size ?: 1).coerceAtLeast(1)
    val viewport = (info.viewportEndOffset - info.viewportStartOffset).coerceAtLeast(1)
    val scrollable = (itemSize.toFloat() * total - viewport).coerceAtLeast(1f)
    val scrolled = state.firstVisibleItemIndex * itemSize.toFloat() + state.firstVisibleItemScrollOffset
    val computed = (scrolled / scrollable).coerceIn(0f, 1f)
    val smooth by animateFloatAsState(computed, tween(90), label = "fsfrac")
    LaunchedEffect(state.isScrollInProgress, dragging) {
        if (state.isScrollInProgress || dragging) visible = true else { delay(1400); visible = false }
    }
    val a by animateFloatAsState(if (visible && total > 25) 1f else 0f, tween(260), label = "fastscroll")
    if (a < 0.01f) return
    BoxWithConstraints(modifier.fillMaxHeight().width(44.dp)) {
        val handleH = 46.dp
        val trackPx = with(LocalDensity.current) { (maxHeight - handleH).toPx() }.coerceAtLeast(1f)
        val f = if (dragging) dragFrac else smooth
        Box(
            Modifier.align(Alignment.TopEnd)
                .offset { IntOffset(0, (f * trackPx).roundToInt()) }
                .padding(end = 4.dp)
                .size(30.dp, handleH)
                .graphicsLayer { alpha = a }
                .clip(RoundedCornerShape(50))
                .background(cs.primary.copy(alpha = .30f))
                .pointerInput(trackPx, scrollable) {
                    detectDragGestures(
                        onDragStart = { dragging = true; dragFrac = smooth },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                        onDrag = { change, amount ->
                            change.consume()
                            dragFrac = (dragFrac + amount.y / trackPx).coerceIn(0f, 1f)
                            state.dispatchRawDelta(amount.y / trackPx * scrollable)
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.DragHandle, null, Modifier.size(20.dp), tint = cs.onSurface) }
    }
}

/** Círculo con una L: la canción tiene letra. */
@Composable
private fun LyricBadge() {
    val col = MaterialTheme.colorScheme.onSurfaceVariant
    Box(Modifier.size(15.dp).border(1.3.dp, col, CircleShape), contentAlignment = Alignment.Center) {
        Text("L", fontSize = 8.sp, lineHeight = 8.sp, fontWeight = FontWeight.Bold, color = col)
    }
}

@Composable
private fun ItemRow(title: String, sub: String, art: Song?, hasLyrics: Boolean = false, current: Boolean = false, playing: Boolean = false,
                    selecting: Boolean = false, checked: Boolean = false,
                    trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (selecting) Checkbox(checked, null, Modifier.padding(end = 6.dp))
        Box(contentAlignment = Alignment.Center) {
            Art(art, 256, Modifier.size(64.dp))
            if (current) Box(Modifier.size(64.dp).clip(RoundedCornerShape(cr(LocalCorner.current, 24))).background(Color.Black.copy(alpha = .38f)),
                contentAlignment = Alignment.Center) { EqBars(playing, Color.White, Modifier.size(26.dp)) }
        }
        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                color = if (current) (if (cs.background.luminance() > 0.5f) cs.onSurface else cs.primary) else Color.Unspecified, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (hasLyrics) { LyricBadge(); Spacer(Modifier.width(5.dp)) }
                Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        trailing?.invoke()
    }
}

@Composable
private fun SongMenu(onNext: () -> Unit, onQueue: () -> Unit, onAdd: () -> Unit, onEdit: () -> Unit, onRemove: (() -> Unit)? = null) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.padding(end = 4.dp)) {
        IconButton({ open = true }) { Icon(Icons.Rounded.MoreVert, "Más") }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem({ Text("Reproducir a continuación") }, { open = false; onNext() })
            DropdownMenuItem({ Text("Agregar a la fila") }, { open = false; onQueue() })
            DropdownMenuItem({ Text("Agregar a lista") }, { open = false; onAdd() })
            DropdownMenuItem({ Text("Editar canción") }, { open = false; onEdit() })
            if (onRemove != null) DropdownMenuItem({ Text("Quitar de la lista") }, { open = false; onRemove() })
        }
    }
}

@Composable
private fun SwitchRow(icon: ImageVector, title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(30.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun PillButton(icon: ImageVector, label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val fg = if (selected) cs.onPrimary else cs.onPrimaryContainer
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(cr(LocalCorner.current, 32)),
        color = if (selected) cs.primary else cs.onPrimaryContainer.copy(alpha = .10f)) {
        Row(Modifier.height(64.dp).fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, Modifier.size(26.dp), tint = fg)
            Text(label, Modifier.padding(start = 10.dp), fontWeight = FontWeight.Bold, color = fg)
        }
    }
}

// ───────────── raíz y navegación ─────────────

/** Una pantalla de detalle: un álbum, un artista o una lista de reproducción. */
private class Group(val kind: String, val key: String)

/** Tema elegido en este momento (para mostrar su símbolo). */
private val LocalThemeSeed = compositionLocalOf { 0 }

/** Símbolo propio de cada tema especial (los que tienen un solo modo). Los temas clásicos no tienen: devuelven null. */
private fun themeSymbol(seed: Int): ImageVector? = when (seed) {
    -3 -> Icons.Rounded.DarkMode              // Halloween: luna
    -5 -> Icons.Rounded.Icecream              // Chocolate
    -6 -> Icons.Rounded.Cake                  // Pastel de cumpleaños
    -7 -> Icons.Rounded.GraphicEq             // Spotify: rayas
    -10 -> Icons.Rounded.HistoryEdu           // Tinta y pergamino: pluma
    -11 -> Icons.Rounded.WbSunny              // Limonada de Amalfi: sol
    -12 -> Icons.Rounded.Cloud                // Cielo de lima: nube
    -13 -> Icons.Rounded.WineBar              // Burdeos y mostaza: copa
    -14 -> Icons.Rounded.Pool                 // Fiesta en la pileta
    -15 -> Icons.Rounded.Air                  // Humo y ballet
    -16 -> Icons.Rounded.Coffee               // Lila espresso: taza
    -17 -> Icons.Rounded.Waves                // Chispa marina: ola
    -18 -> Icons.Rounded.LocalDrink           // Arándano con leche: vaso
    -19 -> Icons.Rounded.Cake                 // Fresa y espresso
    -20 -> Icons.Rounded.NightsStay           // Índigo vainilla: luna y estrellas
    -21 -> Icons.Rounded.LocalBar             // Cidra y vino
    -22 -> Icons.Rounded.LocalFlorist         // Ponche de bayas: flor
    -23 -> Icons.Rounded.BeachAccess          // Vintage costero: sombrilla
    -24 -> Icons.Rounded.Bolt                 // Pop eléctrico: rayo
    -25 -> Icons.Rounded.BakeryDining         // Manteca y café: pan
    -26 -> Icons.Rounded.Eco                  // Oliva: hoja
    else -> null
}

/** Lista ya hecha: el puesto 1 es tu mejor canción. Las canciones nuevas entran en el puesto 1 y las acomodás a gusto. */
private const val TOP_LIST = "Top canciones"

@Composable
private fun Root(prefs: Prefs, mode: String, seed: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { PlayerHolder.get(ctx) }
    val ps by rememberPState(player)
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("lib") }
    var detail by remember { mutableStateOf<Group?>(null) }
    var libTab by remember { mutableIntStateOf(0) }
    var sub by remember { mutableStateOf("") }
    var sleepMin by remember { mutableIntStateOf(0) }
    var lyricsVersion by remember { mutableIntStateOf(0) }
    var lyricIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var miniHpx by remember { mutableIntStateOf(0) }
    var noteFor by remember { mutableStateOf<Song?>(null) }
    var editFor by remember { mutableStateOf<Song?>(null) }
    var addFor by remember { mutableStateOf<List<Song>>(emptyList()) }
    var delListFor by remember { mutableStateOf<String?>(null) }
    var vinylFor by remember { mutableStateOf<String?>(null) }
    var notesVersion by remember { mutableIntStateOf(0) }
    var selecting by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var playCounts by remember { mutableStateOf<Map<Long, Int>>(emptyMap()) }
    var coverTarget by remember { mutableStateOf<List<Song>>(emptyList()) }
    var pendingCover by remember { mutableStateOf<Pair<List<Song>, ByteArray>?>(null) }
    var pendingDelete by remember { mutableStateOf<List<Song>>(emptyList()) }
    var pendingEdit by remember { mutableStateOf<TagEdit?>(null) }
    var askNotif by remember { mutableStateOf(false) }
    val expand = remember { Animatable(0f) }
    val expanded by remember { derivedStateOf { expand.value > 0.005f } }
    val lists by prefs.playlists.collectAsState(emptyMap())
    val sort by prefs.sort.collectAsState("new")
    val hidden by prefs.hidden.collectAsState(emptySet<Long>())
    val mix by prefs.mix.collectAsState(false)
    val silence by prefs.silence.collectAsState(false)
    val cfOn by prefs.crossfadeOn.collectAsState(false)
    val cfSec by prefs.crossfadeSec.collectAsState(6)
    val shuffleOn by prefs.shuffleOn.collectAsState(false)
    val textScale by prefs.textScale.collectAsState(100)
    val lyricsScale by prefs.lyricsScale.collectAsState(100)
    val chipOn by prefs.chip.collectAsState(true)
    val vinyls by prefs.vinyls.collectAsState(emptyMap<String, VinylDesign>())
    val artEnabled = LocalArtTheme.current
    val base = MaterialTheme.colorScheme
    val dark = if (seed == -6) false else base.background.luminance() < 0.5f

    LaunchedEffect(mix) { PlayerHolder.applyMix(mix) }
    val resumeHs by prefs.resumeHeadset.collectAsState(true)
    LaunchedEffect(resumeHs) { PlayerHolder.applyResume(resumeHs) }
    val slowMixOn by prefs.slowMix.collectAsState(true)
    LaunchedEffect(slowMixOn) { PlayerHolder.applySlow(slowMixOn) }
    LaunchedEffect(Unit) { PlayerHolder.applySilence(false) }
    LaunchedEffect(cfOn, cfSec) { PlayerHolder.crossfadeSec = if (cfOn) cfSec else 0 }
    LaunchedEffect(shuffleOn) { PlayerHolder.shuffleMode = shuffleOn }
    LaunchedEffect(artEnabled) { ArtColors.enabled = artEnabled }
    LaunchedEffect(Unit) {
        playCounts = withContext(Dispatchers.IO) { Plays.all(ctx) }
        PlayerHolder.onCounted = { playCounts = Plays.all(ctx) }
    }
    LaunchedEffect(sleepMin) { if (sleepMin > 0) { delay(sleepMin * 60_000L); player.pause(); sleepMin = 0 } }

    val perms = buildList {
        add(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r[perms[0]] == true; if (granted) songs = loadSongs(ctx)
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) askNotif = true
    }
    LaunchedEffect(Unit) { launcher.launch(perms) }

    // ----- abrir / cerrar el reproductor grande con animación -----
    fun settle(v: Float) {
        scope.launch {
            val target = when { v < -900f -> 1f; v > 900f -> 0f; expand.value > 0.5f -> 1f; else -> 0f }
            expand.animateTo(target, tween(320, easing = FastOutSlowInEasing))
            if (target == 0f) sub = ""
        }
    }
    fun openPlayer() { if (player.mediaItemCount > 0) scope.launch { expand.animateTo(1f, tween(380, easing = FastOutSlowInEasing)) } }
    fun closePlayer() { scope.launch { expand.animateTo(0f, tween(320, easing = FastOutSlowInEasing)); sub = "" } }
    BackHandler(selecting || sub.isNotEmpty() || expanded || detail != null || page != "lib") {
        when { selecting -> { selecting = false; selected = emptySet() }; sub.isNotEmpty() -> sub = ""; expanded -> closePlayer(); detail != null -> detail = null; else -> page = if (page == "summary" || page == "dups") "settings" else "lib" }
    }

    // ----- eliminar -----
    fun afterDelete(list: List<Song>) {
        list.forEach { s -> val i = indexOfId(player, s.id.toString()); if (i >= 0) player.removeMediaItem(i) }
        songs = loadSongs(ctx)
    }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && pendingDelete.isNotEmpty()) afterDelete(pendingDelete)
        pendingDelete = emptyList()
    }
    fun requestDelete(list: List<Song>) {
        if (list.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 30) {
            pendingDelete = list
            val pi = MediaStore.createDeleteRequest(ctx.contentResolver, list.map { it.uri })
            deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            val ok = runCatching { list.all { ctx.contentResolver.delete(it.uri, null, null) > 0 } }.getOrDefault(false)
            if (ok) afterDelete(list) else Toast.makeText(ctx, "No se pudo eliminar", Toast.LENGTH_SHORT).show()
        }
    }

    // ----- editar (nombre, artista, álbum y portada dentro del archivo) -----
    suspend fun applyEdit(e: TagEdit) {
        val res = withContext(Dispatchers.IO) {
            val mp3 = isMp3(ctx, e.song.uri)
            val ok = if (mp3) writeMp3Tags(ctx, e.song.uri, e.title, e.artist, e.album, e.cover, e.track) else true
            if (ok) {
                Overrides.save(ctx, e.song.id, e.title, e.artist, e.album)   // se ve al instante
                if (e.track > 0) TrackOverrides.save(ctx, e.song.id, (e.song.track / 1000) * 1000 + e.track)
            }
            updateMediaStore(ctx, e.song.uri, e.title, e.artist, e.album, e.track)
            Pair(mp3, ok)
        }
        if (res.first && res.second && e.cover != null) overrideArt(e.song.uri, e.cover)
        ArtColors.forget(e.song.id.toString())
        songs = loadSongs(ctx)
        val msg = when {
            !res.first -> "Cambiado dentro de la app. Este formato no permite escribir en el archivo."
            res.second -> "Canción actualizada"
            else -> "No se pudo escribir en el archivo"
        }
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
    }
    val writeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val e = pendingEdit; pendingEdit = null
        if (r.resultCode == Activity.RESULT_OK && e != null) scope.launch { applyEdit(e) }
    }
    fun startEdit(e: TagEdit) {
        if (Build.VERSION.SDK_INT >= 30) {
            pendingEdit = e
            val pi = MediaStore.createWriteRequest(ctx.contentResolver, listOf(e.song.uri))
            writeLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else scope.launch { applyEdit(e) }
    }

    // ----- guardar el orden de las pistas de un álbum: en la app y dentro de los MP3 -----
    var pendingTracks by remember { mutableStateOf<List<Pair<Song, Int>>>(emptyList()) }
    suspend fun writeTracks(pairs: List<Pair<Song, Int>>) {
        val n = withContext(Dispatchers.IO) {
            var ok = 0
            for ((s, tn) in pairs) {
                if (writeMp3Tags(ctx, s.uri, s.title, s.artist, s.album, null, tn)) ok++
                updateMediaStore(ctx, s.uri, s.title, s.artist, s.album, tn)
            }
            ok
        }
        Toast.makeText(ctx, "Pistas escritas en $n de ${pairs.size} archivos", Toast.LENGTH_LONG).show()
    }
    val trackWriteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val p = pendingTracks
        pendingTracks = emptyList()
        if (r.resultCode == Activity.RESULT_OK && p.isNotEmpty()) scope.launch { writeTracks(p) }
        else if (p.isNotEmpty()) Toast.makeText(ctx, "Las pistas quedaron guardadas solo en la app", Toast.LENGTH_LONG).show()
    }
    fun saveTracks(ordered: List<Song>) {
        val pairs = ordered.mapIndexed { i, s -> s to (i + 1) }
        TrackOverrides.write(ctx, TrackOverrides.read(ctx) + pairs.associate { (s, n) -> s.id to n })
        songs = loadSongs(ctx)
        scope.launch {
            val mp3 = withContext(Dispatchers.IO) { pairs.filter { isMp3(ctx, it.first.uri) } }
            when {
                mp3.isEmpty() -> Toast.makeText(ctx, "Pistas guardadas en la app (estos archivos no son MP3)", Toast.LENGTH_LONG).show()
                Build.VERSION.SDK_INT >= 30 -> {
                    pendingTracks = mp3
                    val pi = MediaStore.createWriteRequest(ctx.contentResolver, mp3.map { it.first.uri })
                    trackWriteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                }
                else -> writeTracks(mp3)
            }
        }
    }

    // ----- cambiar la portada de todo un álbum -----
    val coverWriteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        val pc = pendingCover
        pendingCover = null
        if (r.resultCode == Activity.RESULT_OK && pc != null) scope.launch {
            val list = pc.first
            val bytes = pc.second
            val n = withContext(Dispatchers.IO) {
                var ok = 0
                for (s in list) if (isMp3(ctx, s.uri) && writeMp3Tags(ctx, s.uri, s.title, s.artist, s.album, bytes)) ok++
                ok
            }
            list.forEach { overrideArt(it.uri, bytes); ArtColors.forget(it.id.toString()) }
            Toast.makeText(ctx, "Portada cambiada en $n de ${list.size} canciones", Toast.LENGTH_LONG).show()
        }
    }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val list = coverTarget
        if (uri != null && list.isNotEmpty()) {
            val bytes = scaleCover(ctx, uri)
            if (bytes == null) Toast.makeText(ctx, "No pude leer esa imagen", Toast.LENGTH_SHORT).show()
            else if (Build.VERSION.SDK_INT >= 30) {
                pendingCover = Pair(list, bytes)
                val pi = MediaStore.createWriteRequest(ctx.contentResolver, list.map { it.uri })
                coverWriteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } else Toast.makeText(ctx, "Esto necesita Android 11 o más nuevo", Toast.LENGTH_SHORT).show()
        }
    }
    fun refreshLibrary() {
        scope.launch {
            songs = withContext(Dispatchers.IO) { loadSongs(ctx) }
            Toast.makeText(ctx, "Biblioteca actualizada: ${songs.size} canciones", Toast.LENGTH_SHORT).show()
        }
    }
    fun exitSelection() { selecting = false; selected = emptySet() }
    fun toggleSel(id: Long) { selected = if (id in selected) selected - id else selected + id }

    val visible = songs.filter { it.id !in hidden }
    val sorted = when (sort) { "old" -> visible.reversed(); "az" -> visible.sortedBy { it.title.lowercase() }
        "artist" -> visible.sortedWith(compareBy<Song>({ it.artist.lowercase() }, { it.album.lowercase() }, { it.track }, { it.title.lowercase() }))
        else -> visible }
    val byId = songs.associateBy { it.id }
    val current = byId[ps.mediaId.toLongOrNull()]
    fun groupSongs(g: Group): List<Song> = when (g.kind) {
        "album" -> visible.filter { it.album == g.key }
        "artist" -> visible.filter { g.key in splitArtists(it.artist) }
        "lyrics" -> visible.filter { it.id in lyricIds }
        "plays" -> visible.filter { (playCounts[it.id] ?: 0) > 0 }
        else -> (lists[g.key] ?: emptyList()).mapNotNull { id -> byId[id] }
    }
    fun selSongs(): List<Song> = songs.filter { it.id in selected }

    fun setShuffle(on: Boolean) {
        scope.launch { prefs.setShuffle(on) }
        PlayerHolder.shuffleMode = on
        if (on) shuffleRest(player) else orderQueue(player, sorted)
    }
    fun playGroup(list: List<Song>, shuffle: Boolean) {
        if (list.isEmpty()) return
        scope.launch { prefs.setShuffle(shuffle) }
        PlayerHolder.shuffleMode = shuffle
        playList(player, list, if (shuffle) Random.nextInt(list.size) else 0, shuffle)
    }
    fun importLyricsFrom(tree: Uri) {
        scope.launch {
            val n = withContext(Dispatchers.IO) { importLyrics(ctx, tree, songs) }
            Toast.makeText(ctx, if (n > 0) "Se importaron $n letras" else "No encontré letras que coincidan con tus canciones", Toast.LENGTH_LONG).show()
            songs = loadSongs(ctx)
            lyricsVersion++
        }
    }

    // Colores de la portada para la pantalla de reproducción, el mini reproductor y la fila
    val artSeed by produceState<Int?>(null, current?.id, artEnabled) {
        val c = current
        value = if (c == null || !artEnabled) null else withContext(Dispatchers.IO) { ArtColors.compute(ctx, c.id.toString(), c.uri, c.albumId) }
    }
    val artCs = remember(artSeed, dark, base) { artSeed?.let { schemeFromSeed(Color(it), dark) } ?: base }

    val lyrics by produceState("", current?.id, lyricsVersion) {
        val c = current
        value = if (c == null) "" else withContext(Dispatchers.IO) { loadLyrics(ctx, c) }
    }
    val firstLine = lyrics.lineSequence().firstOrNull { it.isNotBlank() }

    // Qué canciones tienen letra (para el símbolo de la biblioteca). Se revisa de a poco, en segundo plano.
    LaunchedEffect(songs) {
        if (songs.isNotEmpty()) withContext(Dispatchers.IO) {
            val found = HashSet<Long>()
            var n = 0
            for (s in songs) {
                ensureActive()
                if (hasSavedLyrics(ctx, s.id) || hasEmbeddedLyrics(ctx, s.uri)) found.add(s.id)
                if (++n % 40 == 0) { val snap = HashSet(found); withContext(Dispatchers.Main) { lyricIds = snap } }
            }
            val snap = HashSet(found)
            withContext(Dispatchers.Main) { lyricIds = snap }
        }
    }
    LaunchedEffect(lyricsVersion, current?.id) {
        val c = current
        if (c != null) {
            val has = withContext(Dispatchers.IO) { hasSavedLyrics(ctx, c.id) || hasEmbeddedLyrics(ctx, c.uri) }
            lyricIds = if (has) lyricIds + c.id else lyricIds - c.id
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val h = constraints.maxHeight.toFloat()
        val dragState = rememberDraggableState { dy -> scope.launch { expand.snapTo((expand.value - dy / h).coerceIn(0f, 1f)) } }
        val dragMod = Modifier.draggable(dragState, Orientation.Vertical, onDragStopped = { v -> settle(v) })
        val showMini = ps.title.isNotEmpty() && page == "lib"
        val miniDp = if (selecting) 140.dp else if (showMini) with(LocalDensity.current) { miniHpx.toDp() } else 0.dp

        AnimatedContent(
            targetState = page,
            transitionSpec = {
                val dir = if (targetState == "lib") -1 else 1
                val enter = fadeIn(tween(240)) + slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { dir * it / 8 }
                val exit = fadeOut(tween(180)) + slideOutHorizontally(tween(300, easing = FastOutSlowInEasing)) { -dir * it / 8 }
                enter togetherWith exit
            },
            label = "pages"
        ) { p ->
            when (p) {
                "theme" -> ThemeScreen(prefs, mode, seed) { page = "lib" }
                "summary" -> SummaryScreen(songs, lists, { notesVersion++ }) { page = "settings" }
                "dups" -> DuplicatesScreen(songs.filter { it.id !in hidden }, { s -> scope.launch { prefs.hide(s.id) } }, { s -> requestDelete(listOf(s)) }) { page = "settings" }
                "settings" -> SettingsScreen(prefs, mix, cfOn, cfSec, sleepMin, { sleepMin = it },
                    songs.filter { it.id in hidden }, textScale, lyricsScale, chipOn, { uri -> importLyricsFrom(uri) }, { refreshLibrary() }, { page = "summary" }, { page = "dups" }) { page = "lib" }
                else -> Library(sorted, lists, prefs, ps, player, granted, sort, shuffleOn, lyricIds, playCounts, libTab, { libTab = it }, miniDp,
                    selecting, selected, { toggleSel(it) }, { selecting = !selecting; selected = emptySet() }, { refreshLibrary() }, notesVersion, { noteFor = it },
                    { detail = it }, { addFor = listOf(it) }, { editFor = it }, { page = "settings" }, { page = "theme" }, { openPlayer() })
            }
        }

        // Álbum, artista o lista: se desliza por encima de la biblioteca (que queda como estaba)
        val holder = remember { arrayOfNulls<Group>(1) }
        if (detail != null) holder[0] = detail
        AnimatedVisibility(
            visible = detail != null && page == "lib",
            enter = slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { it / 3 } + fadeIn(tween(240)),
            exit = slideOutHorizontally(tween(280, easing = FastOutSlowInEasing)) { it / 3 } + fadeOut(tween(200))
        ) {
            val g = detail ?: holder[0]
            if (g != null) DetailScreen(g, visible, lists, ps, player, shuffleOn, lyricIds, playCounts, miniDp,
                { detail = null }, { l, sh -> playGroup(l, sh) }, { addFor = listOf(it) }, { editFor = it },
                { s -> scope.launch { prefs.savePlaylists(lists + (g.key to ((lists[g.key] ?: emptyList()) - s.id))) } },
                { delListFor = g.key }, { vinylFor = g.key }, { l -> coverTarget = l; coverPicker.launch("image/*") },
                selecting, selected, { toggleSel(it) }, { selecting = !selecting; selected = emptySet() },
                { ids -> scope.launch { prefs.savePlaylists(lists + (g.key to ids)) } },
                { ordered -> saveTracks(ordered) })
        }

        if (showMini && !selecting) Box(Modifier.align(Alignment.BottomCenter).onSizeChanged { miniHpx = it.height }) {
            MaterialTheme(colorScheme = artCs) { MiniPlayer(player, ps, current, shuffleOn, dragMod, { setShuffle(!shuffleOn) }, { openPlayer() }) }
        }
        if (selecting) Box(Modifier.align(Alignment.BottomCenter)) {
            SelectionBar(selected.size,
                onAll = { selected = (detail?.let { groupSongs(it) } ?: sorted).map { it.id }.toSet() },
                onCancel = { exitSelection() },
                onNext = { selSongs().asReversed().forEach { playNext(player, it) }; exitSelection() },
                onQueue = { selSongs().forEach { addToQueue(player, it) }; exitSelection() },
                onList = { addFor = selSongs(); exitSelection() },
                onHide = { val l = selSongs(); scope.launch { l.forEach { prefs.hide(it.id) } }; exitSelection() },
                onDelete = { val l = selSongs(); exitSelection(); requestDelete(l) })
        }

        val showPlayer by remember { derivedStateOf { expand.value > 0.002f } }
        if (showPlayer) {
            Box(Modifier.fillMaxSize().graphicsLayer { translationY = (1f - expand.value) * h }) {
                MaterialTheme(colorScheme = artCs) {
                    NowPlaying(player, ps, current, lists, prefs, firstLine, lyrics, vinyls[current?.album ?: ""], dragMod,
                        onLyrics = { sub = "lyrics" }, onQueue = { sub = "queue" },
                        onDelete = { current?.let { requestDelete(listOf(it)) } },
                        onHide = { current?.let { s -> scope.launch { prefs.hide(s.id) }; Toast.makeText(ctx, "Canción oculta", Toast.LENGTH_SHORT).show() } },
                        onNote = { noteFor = current })
                    AnimatedVisibility(
                        visible = sub == "queue",
                        enter = slideInVertically(tween(340, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(220)),
                        exit = slideOutVertically(tween(300, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(200))
                    ) {
                        QueueScreen(player, ps, byId, current, shuffleOn, { setShuffle(false) }, { setShuffle(true) }) { sub = "" }
                    }
                    AnimatedVisibility(
                        visible = sub == "lyrics",
                        enter = slideInVertically(tween(340, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(220)),
                        exit = slideOutVertically(tween(300, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(200))
                    ) {
                        LyricsScreen(current, lyrics, { sub = "" }, { lyricsVersion++ })
                    }
                }
            }
        }
    }

    noteFor?.let { s ->
        NoteDialog(Store.read(ctx, "notes", s.id), Store.read(ctx, "status", s.id), { noteFor = null }) { txt, est ->
            Store.write(ctx, "notes", s.id, txt); Store.write(ctx, "status", s.id, est)
            if (txt.isBlank() && est.isBlank()) Store.write(ctx, "notets", s.id, "")
            else if (Store.read(ctx, "notets", s.id).isBlank()) Store.write(ctx, "notets", s.id, System.currentTimeMillis().toString())
            notesVersion++; noteFor = null
        }
    }
    vinylFor?.let { al ->
        VinylEditorDialog(al, songs.firstOrNull { it.album == al }, vinyls[al], { d -> scope.launch { prefs.saveVinyl(al, d); WidgetUpdater.request(ctx, player, true) }; vinylFor = null }, { vinylFor = null })
    }
    editFor?.let { s -> EditSongDialog(s, { editFor = null }) { e -> editFor = null; startEdit(e) } }
    if (addFor.isNotEmpty()) {
        val targets = addFor
        AlertDialog({ addFor = emptyList() }, confirmButton = {}, title = { Text("Agregar a lista") }, text = {
            Column {
                if (lists.keys.none { it != TOP_LIST }) Text("Podés crear más listas en la pestaña Listas.")
                (listOf(TOP_LIST) + lists.keys.filter { it != TOP_LIST }).forEach { n ->
                    TextButton({
                        val ids = targets.map { it.id }
                        val old = lists[n] ?: emptyList()
                        val merged = if (n == TOP_LIST) (ids + old).distinct() else (old + ids).distinct()   // en el Top entra en el puesto 1
                        scope.launch { prefs.savePlaylists(lists + (n to merged)) }
                        addFor = emptyList()
                    }) { Text(if (n == TOP_LIST) "$n (puesto 1)" else n) }
                }
            }
        })
    }
    delListFor?.let { n ->
        AlertDialog(
            onDismissRequest = { delListFor = null },
            confirmButton = { TextButton({ scope.launch { prefs.savePlaylists(lists - n) }; detail = null; delListFor = null }) { Text("Eliminar") } },
            dismissButton = { TextButton({ delListFor = null }) { Text("Cancelar") } },
            title = { Text("Eliminar lista") },
            text = { Text("¿Eliminar la lista “$n”? Las canciones no se borran.") }
        )
    }
    if (askNotif) AlertDialog(
        onDismissRequest = { askNotif = false },
        confirmButton = {
            TextButton({
                askNotif = false
                ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("Abrir ajustes") }
        },
        dismissButton = { TextButton({ askNotif = false }) { Text("Ahora no") } },
        title = { Text("Activá las notificaciones") },
        text = { Text("Sin notificaciones no aparece el reproductor en la barra ni en la pantalla de bloqueo.") }
    )
}

@Composable
private fun EditSongDialog(song: Song, onDismiss: () -> Unit, onSave: (TagEdit) -> Unit) {
    val ctx = LocalContext.current
    var title by remember(song.id) { mutableStateOf(song.title) }
    var artist by remember(song.id) { mutableStateOf(song.artist) }
    var album by remember(song.id) { mutableStateOf(song.album) }
    var track by remember(song.id) { mutableStateOf((song.track % 1000).takeIf { it > 0 }?.toString() ?: "") }
    var cover by remember(song.id) { mutableStateOf<ByteArray?>(null) }
    val coverBmp = remember(cover) { cover?.let { BitmapFactory.decodeByteArray(it, 0, it.size) } }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) cover = scaleCover(ctx, uri)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton({
                onSave(TagEdit(song, title.trim().ifBlank { song.title }, artist.trim().ifBlank { song.artist }, album.trim().ifBlank { song.album }, cover, track.toIntOrNull() ?: 0))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } },
        title = { Text("Editar canción") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (coverBmp != null) Image(coverBmp.asImageBitmap(), null,
                        Modifier.size(88.dp).clip(RoundedCornerShape(cr(LocalCorner.current, 24))), contentScale = ContentScale.Crop)
                    else Art(song, 256, Modifier.size(88.dp))
                    OutlinedButton({ picker.launch("image/*") }, Modifier.padding(start = 14.dp)) { Text("Cambiar portada") }
                }
                OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Nombre") }, singleLine = true)
                OutlinedTextField(artist, { artist = it }, Modifier.fillMaxWidth(), label = { Text("Artista") }, singleLine = true)
                OutlinedTextField(album, { album = it }, Modifier.fillMaxWidth(), label = { Text("Álbum") }, singleLine = true)
                OutlinedTextField(track, { track = it.filter { ch -> ch.isDigit() }.take(3) }, Modifier.fillMaxWidth(),
                    label = { Text("Número de pista") }, singleLine = true,
                    supportingText = { Text("1 = primera canción del álbum, 2 = segunda...") },
                    keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number))
                Text("Android va a pedir confirmación para modificar el archivo. En MP3 se guarda dentro del archivo.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}

// ───────────── nota (tarjeta con esquina doblada) ─────────────

/** Rectángulo con las esquinas redondeadas del tema y la esquina de abajo a la derecha cortada en diagonal. */
private class FoldedCardShape(private val r: Float, private val fold: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val w = size.width
        val h = size.height
        val rr = r.coerceIn(0f, minOf(w, h) / 2f)
        val f = fold.coerceAtMost(minOf(w, h) / 2f)
        val p = Path()
        p.moveTo(rr, 0f)
        p.lineTo(w - rr, 0f)
        if (rr > 0.5f) p.arcTo(Rect(w - 2 * rr, 0f, w, 2 * rr), -90f, 90f, false) else p.lineTo(w, 0f)
        p.lineTo(w, h - f)
        p.lineTo(w - f, h)
        p.lineTo(rr, h)
        if (rr > 0.5f) p.arcTo(Rect(0f, h - 2 * rr, 2 * rr, h), 90f, 90f, false) else p.lineTo(0f, h)
        p.lineTo(0f, rr)
        if (rr > 0.5f) p.arcTo(Rect(0f, 0f, 2 * rr, 2 * rr), 180f, 90f, false) else p.lineTo(0f, 0f)
        p.close()
        return Outline.Generic(p)
    }
}

private class NoteColors(val card: Color, val fg: Color, val flap: Color, val rPx: Float, val foldPx: Float, val outline: Color?)

/** Colores de la tarjeta según el estilo elegido en Tema: según el tema, sticker (gris y redondeado) o post-it (amarillo, esquinas rectas). */
@Composable
private fun noteColors(smallFold: Boolean = false): NoteColors {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val style = LocalNoteStyle.current
    val density = LocalDensity.current
    val blackCard = style == "theme" && cs.background.luminance() < 0.01f
    val fold = with(density) { (if (smallFold) 40.dp else 58.dp).toPx() }
    return when (style) {
        "sticker" -> NoteColors(Color(0xFFE6E7E9), Color(0xFF1B1C1E), Color(0xFF9E9E9E), with(density) { 40.dp.toPx() }, fold, null)
        "postit" -> NoteColors(Color(0xFFE7BA2F), Color(0xFF3A2A05), Color(0xFF935811), 0f, fold, null)
        else -> NoteColors(
            if (blackCard) Color.Black else cs.secondaryContainer, if (blackCard) cs.onSurface else cs.onSecondaryContainer,
            cs.primary, with(density) { cr(c, 44).toPx() }, fold, if (blackCard) cs.primary.copy(alpha = .35f) else null
        )
    }
}

private fun Modifier.noteCard(n: NoteColors): Modifier = this
    .clip(FoldedCardShape(n.rPx, n.foldPx))
    .background(n.card)
    .then(n.outline?.let { Modifier.border(1.dp, it, FoldedCardShape(n.rPx, n.foldPx)) } ?: Modifier)
    .drawWithContent {
        drawContent()
        val w = size.width
        val h = size.height
        val f = n.foldPx
        val rf = (n.rPx * 0.55f).coerceAtMost(f / 2f)
        val flapPath = Path()
        flapPath.moveTo(w - f + rf, h - f)
        flapPath.lineTo(w, h - f)
        flapPath.lineTo(w - f, h)
        flapPath.lineTo(w - f, h - f + rf)
        if (rf > 0.5f) flapPath.arcTo(Rect(w - f, h - f, w - f + 2 * rf, h - f + 2 * rf), 180f, 90f, false)
        flapPath.close()
        drawPath(flapPath, n.flap)
    }

@Composable
private fun noteFieldColors(fg: Color) = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    focusedTextColor = fg, unfocusedTextColor = fg,
    focusedPlaceholderColor = fg.copy(alpha = .55f), unfocusedPlaceholderColor = fg.copy(alpha = .55f), cursorColor = fg
)

/** Nota de una canción, con su "Estado" (cómo te sentías). Los colores siguen el estilo elegido en Tema. */
@Composable
private fun NoteDialog(initial: String, initialStatus: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    val c = LocalCorner.current
    val style = LocalNoteStyle.current
    var text by remember { mutableStateOf(initial) }
    var status by remember { mutableStateOf(initialStatus) }
    val nc = noteColors()
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 20.dp).imePadding().heightIn(min = 500.dp).noteCard(nc)) {
            Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 22.dp, bottom = 200.dp)) {
                Text("Nota:", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = nc.fg)
                Spacer(Modifier.height(6.dp))
                TextField(text, { text = it }, Modifier.fillMaxWidth(), minLines = 9,
                    placeholder = { Text("Escribí lo que quieras recordar de esta canción") }, colors = noteFieldColors(nc.fg),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences))
            }
            Column(Modifier.align(Alignment.BottomStart).padding(start = 22.dp, end = 22.dp, bottom = 74.dp)) {
                Text("Estado:", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = nc.fg)
                TextField(status, { status = it }, Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Escribí cómo te sentís") }, colors = noteFieldColors(nc.fg),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences))
            }
            Text(
                "GUARDAR",
                Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp).clip(RoundedCornerShape(if (style == "postit") 0.dp else cr(c, 20)))
                    .clickable { onSave(text.trim(), status.trim()) }.padding(horizontal = 18.dp, vertical = 12.dp),
                fontWeight = FontWeight.Bold, color = nc.fg, letterSpacing = 2.sp
            )
        }
    }
}

/** Una nota en la pestaña Notas: el tamaño de la tarjeta depende de lo que se escribió. */
@Composable
private fun NoteCard(title: String, note: String, status: String, icon: ImageVector, iconDesc: String, onEdit: () -> Unit) {
    val nc = noteColors(smallFold = true)
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).noteCard(nc)) {
        Column(Modifier.fillMaxWidth().padding(start = 18.dp, end = 52.dp, top = 16.dp, bottom = if (status.isNotBlank()) 74.dp else 46.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = nc.fg, textDecoration = TextDecoration.Underline, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (note.isNotBlank()) Text(note, Modifier.padding(top = 8.dp), color = nc.fg)
        }
        if (status.isNotBlank()) Text("Estado: $status", Modifier.align(Alignment.BottomStart).padding(start = 18.dp, end = 60.dp, bottom = 16.dp), fontWeight = FontWeight.Bold, color = nc.fg)
        IconButton(onEdit, Modifier.align(Alignment.TopEnd)) { Icon(icon, iconDesc, tint = nc.fg) }
    }
}

private class NoteRow(val id: Long, val song: Song?, val title: String, val note: String, val status: String)

/** Todas las notas que escribiste (una tarjeta por canción) y los resúmenes del mes que guardaste. */
@Composable
private fun NotesTab(songs: List<Song>, version: Int, bottomPad: Dp, onEdit: (Song) -> Unit) {
    val ctx = LocalContext.current
    var bump by remember { mutableIntStateOf(0) }
    var delId by remember { mutableStateOf<Long?>(null) }
    val notes = remember(songs, version, bump) {
        val ids = Store.idsWith(ctx, "notes") + Store.idsWith(ctx, "status")
        val byId = songs.associateBy { it.id }
        ids.mapNotNull { id ->
            val note = Store.read(ctx, "notes", id)
            val status = Store.read(ctx, "status", id)
            if (note.isBlank() && status.isBlank()) return@mapNotNull null
            if (id < 0) {
                val ym = -id
                NoteRow(id, null, "Resumen de ${monthNames[((ym % 100).toInt() - 1).coerceIn(0, 11)]} ${ym / 100}", note, status)
            } else byId[id]?.let { NoteRow(id, it, it.title, note, status) }
        }.sortedByDescending { Store.noteTime(ctx, it.id) }
    }
    if (notes.isEmpty()) Text("Todavía no hay notas. Abrí una canción y tocá ⋮ → Nota.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyColumn {
        items(notes, key = { it.id }) { r ->
            val song = r.song
            NoteCard(r.title, r.note, r.status, if (song != null) Icons.Rounded.Edit else Icons.Rounded.Delete,
                if (song != null) "Editar nota" else "Borrar resumen") { if (song != null) onEdit(song) else delId = r.id }
        }
        item { BottomSpace(bottomPad) }
    }
    delId?.let { id ->
        AlertDialog(
            onDismissRequest = { delId = null },
            confirmButton = { TextButton({ Store.write(ctx, "notes", id, ""); Store.write(ctx, "notets", id, ""); delId = null; bump++ }) { Text("Borrar") } },
            dismissButton = { TextButton({ delId = null }) { Text("Cancelar") } },
            title = { Text("Borrar resumen") },
            text = { Text("¿Borrar este resumen de tus notas?") }
        )
    }
}

// ───────────── biblioteca ─────────────

@Composable
private fun BottomSpace(pad: Dp) {
    if (pad > 0.dp) Spacer(Modifier.height(pad + 8.dp)) else Spacer(Modifier.navigationBarsPadding())
}

@Composable
private fun Library(songs: List<Song>, lists: Map<String, List<Long>>, prefs: Prefs, ps: PState, player: Player,
                    granted: Boolean, sort: String, shuffleOn: Boolean, lyricIds: Set<Long>, playCounts: Map<Long, Int>, tab: Int, onTab: (Int) -> Unit,
                    bottomPad: Dp, selecting: Boolean, selected: Set<Long>, onToggle: (Long) -> Unit, onSelectMode: () -> Unit,
                    onRefresh: () -> Unit, notesVersion: Int, onNote: (Song) -> Unit, onOpen: (Group) -> Unit, onAdd: (Song) -> Unit, onEdit: (Song) -> Unit,
                    onSettings: () -> Unit, onTheme: () -> Unit, onNow: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val scope = rememberCoroutineScope()
    var sortMenu by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(search) { if (search) { delay(150); runCatching { focus.requestFocus() } } }
    val index = remember(songs) { songs.map { it to norm("${it.title} ${it.artist} ${it.album}") } }
    val words = norm(query).split(' ').filter { it.isNotBlank() }
    val shown = if (words.isEmpty()) songs else index.filter { (_, hay) -> words.all { hay.contains(it) } }.map { it.first }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("M!Perla", Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            IconButton({ search = !search; if (!search) query = "" }) { Icon(Icons.Rounded.Search, "Buscar") }
            Box {
                IconButton({ sortMenu = true }) { Icon(Icons.Rounded.SwapVert, "Ordenar") }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf("new" to "Más nuevas primero", "old" to "Más viejas primero", "az" to "A–Z", "artist" to "Artista A–Z (por álbum)").forEach { (k, l) ->
                        DropdownMenuItem({ Text(l + if (k == sort) "  ✓" else "") }, { sortMenu = false; scope.launch { prefs.setSort(k) } })
                    }
                    DropdownMenuItem({ Text("Actualizar biblioteca") }, { sortMenu = false; onRefresh() })
                }
            }
            IconButton(onSelectMode) { Icon(Icons.Rounded.CheckCircle, "Seleccionar", tint = if (selecting) cs.primary else LocalContentColor.current) }
            IconButton(onSettings) { Icon(Icons.Rounded.Settings, "Ajustes") }
            IconButton(onTheme) { Icon(themeSymbol(LocalThemeSeed.current) ?: Icons.Rounded.Palette, "Tema") }
        }
        AnimatedVisibility(search) {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).focusRequester(focus),
                singleLine = true, placeholder = { Text("Buscar canciones, artistas o álbumes") },
                shape = RoundedCornerShape(cr(c, 24)), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Rounded.Close, "Borrar") } })
        }
        LazyRow(contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(listOf("Canciones", "Listas", "Álbumes", "Artistas", "Notas")) { i, t ->
                val sel = tab == i
                Surface(onClick = { onTab(i) }, shape = RoundedCornerShape(cr(c, 24)), color = if (sel) cs.primary else cs.secondaryContainer) {
                    Text(t, Modifier.padding(horizontal = 20.dp, vertical = 10.dp), fontWeight = FontWeight.Bold,
                        color = if (sel) cs.onPrimary else cs.onSecondaryContainer)
                }
            }
        }
        Box(Modifier.weight(1f)) {
            if (!granted) Text("Falta el permiso de audio.", Modifier.padding(20.dp))
            if (granted && shown.isEmpty() && query.isNotBlank()) Text("No se encontró nada para “$query”", Modifier.padding(20.dp),
                color = cs.onSurfaceVariant)
            when (tab) {
                0 -> Box(Modifier.fillMaxSize()) {
                    val st = rememberLazyListState()
                    LazyColumn(state = st) {
                        items(shown, key = { it.id }) { s ->
                            ItemRow(s.title, "${s.artist} - ${s.album}", s, hasLyrics = s.id in lyricIds, current = ps.mediaId == s.id.toString(), playing = ps.playing,
                                selecting = selecting, checked = s.id in selected,
                                trailing = if (selecting) null else ({ SongMenu({ playNext(player, s) }, { addToQueue(player, s) }, { onAdd(s) }, { onEdit(s) }) })
                            ) { if (selecting) onToggle(s.id) else { playList(player, shown, shown.indexOf(s), shuffleOn); onNow() } }
                        }
                        item { BottomSpace(bottomPad) }
                    }
                    FastScroller(st, Modifier.align(Alignment.CenterEnd))
                }
                1 -> PlaylistsTab(songs, lists, prefs, bottomPad, lyricIds, playCounts) { onOpen(it) }
                4 -> NotesTab(songs, notesVersion, bottomPad, onNote)
                else -> Box(Modifier.fillMaxSize()) {
                    val st = rememberLazyListState()
                    val byAlbum = tab == 2
                    val groups = (if (byAlbum) shown.groupBy { it.album } else shown.flatMap { s -> splitArtists(s.artist).map { a -> a to s } }.groupBy({ it.first }, { it.second })).entries.toList()
                    LazyColumn(state = st) {
                        items(groups, key = { it.key }) { g ->
                            val n = g.value.size
                            val sub = (if (byAlbum) "${g.value.first().artist} - " else "") + "$n ${if (n == 1) "canción" else "canciones"}"
                            ItemRow(g.key.ifBlank { "Desconocido" }, sub, g.value.first()) { onOpen(Group(if (byAlbum) "album" else "artist", g.key)) }
                        }
                        item { BottomSpace(bottomPad) }
                    }
                    FastScroller(st, Modifier.align(Alignment.CenterEnd))
                }
            }
        }
    }
}

/** Pantalla de un álbum, un artista o una lista: portada, título, botones y sus canciones. */
@Composable
private fun DetailScreen(group: Group, all: List<Song>, lists: Map<String, List<Long>>, ps: PState, player: Player, shuffleOn: Boolean,
                         lyricIds: Set<Long>, playCounts: Map<Long, Int>, bottomPad: Dp, onBack: () -> Unit, onPlayAll: (List<Song>, Boolean) -> Unit,
                         onAdd: (Song) -> Unit, onEdit: (Song) -> Unit, onRemove: (Song) -> Unit, onDeleteList: () -> Unit, onVinyl: () -> Unit, onAlbumCover: (List<Song>) -> Unit,
                         selecting: Boolean, selected: Set<Long>, onToggle: (Long) -> Unit, onSelectMode: () -> Unit, onReorder: (List<Long>) -> Unit, onTracks: (List<Song>) -> Unit) {
    val ctx = LocalContext.current
    val base = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val artEnabled = LocalArtTheme.current
    var order by remember { mutableStateOf("orig") }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    val byId = remember(all) { all.associateBy { it.id } }
    val raw = remember(group, all, lists, lyricIds, playCounts) {
        when (group.kind) {
            "album" -> all.filter { it.album == group.key }.sortedBy { it.track }
            "artist" -> all.filter { group.key in splitArtists(it.artist) }.sortedWith(compareBy({ it.album }, { it.track }))
            "lyrics" -> all.filter { it.id in lyricIds }
            "plays" -> all.filter { (playCounts[it.id] ?: 0) > 0 }.sortedByDescending { playCounts[it.id] ?: 0 }
            else -> (lists[group.key] ?: emptyList()).mapNotNull { byId[it] }
        }
    }
    val isTop = group.kind == "list" && group.key == TOP_LIST
    val list = if (isTop) raw else when (order) {
        "az" -> raw.sortedBy { it.title.lowercase() }
        "za" -> raw.sortedByDescending { it.title.lowercase() }
        "track" -> raw.sortedWith(compareBy<Song>({ it.track }, { it.title.lowercase() }))
        else -> raw
    }
    val first = raw.firstOrNull()
    var arranging by remember(group.key) { mutableStateOf(false) }   // acomodar las pistas de un álbum arrastrando
    val reorderMode = isTop || arranging
    // Top: se reordena una copia mientras se arrastra y se guarda al soltar
    val listState = rememberLazyListState()
    var dragKey by remember { mutableStateOf<Long?>(null) }
    var localTop by remember { mutableStateOf<List<Song>?>(null) }
    val shown = if (reorderMode) (localTop ?: raw) else list
    // la librería se ocupa del arrastre, las animaciones y del desplazamiento en los bordes
    val reorderState = rememberReorderableLazyListState(listState) { from, to ->
        val cur = localTop ?: raw
        val f = cur.indexOfFirst { it.id == from.key }
        val tt = cur.indexOfFirst { it.id == to.key }
        if (f >= 0 && tt >= 0 && f != tt) localTop = cur.toMutableList().apply { add(tt, removeAt(f)) }
    }
    LaunchedEffect(raw, dragKey) {
        val l = localTop
        if (!arranging && dragKey == null && l != null && raw.map { it.id } == l.map { it.id }) localTop = null
    }
    LaunchedEffect(dragKey) { if (!arranging && dragKey == null && localTop != null) { delay(900); localTop = null } }
    fun topFinish() {
        if (isTop) localTop?.let { l -> onReorder(l.map { it.id }) }
        dragKey = null
    }
    val dark = base.background.luminance() < 0.5f
    val seedC by produceState<Int?>(null, first?.id, artEnabled) {
        val f = first
        value = if (f == null || !artEnabled) null else withContext(Dispatchers.IO) { ArtColors.compute(ctx, f.id.toString(), f.uri, f.albumId) }
    }
    val cs = remember(seedC, dark, base) { seedC?.let { schemeFromSeed(Color(it), dark) } ?: base }
    val tint = cs.onPrimaryContainer.copy(alpha = .10f)

    MaterialTheme(colorScheme = cs) {
        Surface(Modifier.fillMaxSize(), color = cs.background) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(cs.primaryContainer, cs.background), endY = 1400f))) {
                LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = WindowInsets.statusBars.asPaddingValues()) {
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(onClick = onBack, shape = CircleShape, color = tint) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver", Modifier.padding(14.dp).size(24.dp))
                            }
                            Spacer(Modifier.weight(1f))
                            Surface(shape = RoundedCornerShape(50), color = tint) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onSelectMode) { Icon(Icons.Rounded.CheckCircle, "Seleccionar", tint = if (selecting) cs.primary else LocalContentColor.current) }
                                    if (!reorderMode) Box {
                                        IconButton({ sortMenu = true }) { Icon(Icons.Rounded.SwapVert, "Ordenar") }
                                        DropdownMenu(sortMenu, { sortMenu = false }) {
                                            (listOf("orig" to "Orden original") + (if (group.kind == "album") listOf("track" to "Por número de pista") else emptyList()) + listOf("az" to "A–Z", "za" to "Z–A")).forEach { (k, l) ->
                                                DropdownMenuItem({ Text(l + if (k == order) "  ✓" else "") }, { sortMenu = false; order = k })
                                            }
                                        }
                                    }
                                    Box {
                                        IconButton({ moreMenu = true }) { Icon(Icons.Rounded.MoreVert, "Más") }
                                        DropdownMenu(moreMenu, { moreMenu = false }) {
                                            DropdownMenuItem({ Text("Reproducir a continuación") }, { moreMenu = false; list.asReversed().forEach { playNext(player, it) } })
                                            DropdownMenuItem({ Text("Agregar a la fila") }, { moreMenu = false; list.forEach { addToQueue(player, it) } })
                                            if (group.kind == "list" && !isTop) DropdownMenuItem({ Text("Eliminar lista") }, { moreMenu = false; onDeleteList() })
                                            if (group.kind == "album") DropdownMenuItem({ Text("Acomodar pistas") }, { moreMenu = false; localTop = raw; arranging = true })
                                            if (group.kind == "list" && !isTop) DropdownMenuItem({ Text("Ordenar a mano") }, { moreMenu = false; localTop = raw; arranging = true })
                                            if (group.kind == "album") DropdownMenuItem({ Text("Diseño del vinilo") }, { moreMenu = false; onVinyl() })
                                            if (group.kind == "album") DropdownMenuItem({ Text("Cambiar portada del álbum") }, { moreMenu = false; onAlbumCover(raw) })
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Box(Modifier.fillMaxWidth(0.62f).aspectRatio(1f).clip(RoundedCornerShape(cr(c, 44)))
                                .background(cs.primary.copy(alpha = .16f)).padding(18.dp)) {
                                Art(first, 800, Modifier.fillMaxSize(), cr(c, 34))
                            }
                        }
                    }
                    item {
                        Column(Modifier.fillMaxWidth().padding(top = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(group.key.ifBlank { "Desconocido" }, Modifier.padding(horizontal = 24.dp), style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${raw.size} ${if (raw.size == 1) "canción" else "canciones"}", Modifier.padding(top = 6.dp),
                                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant)
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 22.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Surface(onClick = { onPlayAll(list, false) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(cr(c, 32)),
                                color = cs.primary.copy(alpha = .16f)) {
                                Row(Modifier.height(64.dp).fillMaxWidth(), Arrangement.Center, Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(28.dp), tint = cs.primary)
                                    Text("Reproducir", Modifier.padding(start = 8.dp), fontWeight = FontWeight.Bold, color = cs.primary, maxLines = 1)
                                }
                            }
                            Surface(onClick = { onPlayAll(list, true) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(cr(c, 32)),
                                color = cs.primary.copy(alpha = .16f)) {
                                Row(Modifier.height(64.dp).fillMaxWidth(), Arrangement.Center, Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(26.dp), tint = cs.primary)
                                    Text("Mezclar todo", Modifier.padding(start = 8.dp), fontWeight = FontWeight.Bold, color = cs.primary, maxLines = 1,
                                        overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                    if (raw.isEmpty()) item {
                        Text(if (isTop) "Tu Top está vacío. Agregá canciones desde el menú ⋮ de cualquier canción: la última que agregues queda en el puesto 1."
                        else if (group.kind == "list") "La lista está vacía. Agregá canciones desde el menú ⋮ de cualquier canción."
                        else "No hay canciones.", Modifier.padding(horizontal = 24.dp, vertical = 8.dp), color = cs.onSurfaceVariant)
                    }
                    if (arranging) item {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                            Text(if (group.kind == "album") "Arrastrá las canciones con las rayitas: la de arriba queda como pista 1, la siguiente como pista 2, y así." else "Arrastrá las canciones con las rayitas para ordenar la lista a tu gusto. Esto no cambia el número de pista.",
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedButton({ arranging = false; localTop = null }, Modifier.weight(1f)) { Text("Cancelar") }
                                Button({ if (group.kind == "album") onTracks(localTop ?: raw) else onReorder((localTop ?: raw).map { it.id }); arranging = false; localTop = null }, Modifier.weight(1f)) { Text("Guardar orden") }
                            }
                        }
                    }
                    itemsIndexed(shown, key = { _, s -> s.id }) { idx, s ->
                        if (reorderMode && !selecting) {
                            ReorderableItem(reorderState, key = s.id) { dragging ->
                                val isCur = ps.mediaId == s.id.toString()
                                Row(
                                    Modifier.fillMaxWidth().height(72.dp)
                                        .background(if (dragging) cs.primary.copy(alpha = .12f) else Color.Transparent)
                                        .clickable { playList(player, shown, idx, shuffleOn) }
                                        .padding(start = 16.dp, end = 0.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${idx + 1}", Modifier.width(44.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                                        color = if (idx < 3) cs.primary else cs.onSurfaceVariant)
                                    Art(s, 256, Modifier.size(56.dp))
                                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                                        Text(s.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                                            color = if (isCur) cs.primary else cs.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${s.artist} - ${s.album}", color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Icon(Icons.Rounded.DragHandle, "Mover", Modifier.size(48.dp).padding(10.dp).draggableHandle(
                                        onDragStarted = { localTop = localTop ?: raw; dragKey = s.id },
                                        onDragStopped = { topFinish() }
                                    ), tint = cs.onSurfaceVariant)
                                    SongMenu({ playNext(player, s) }, { addToQueue(player, s) }, { onAdd(s) }, { onEdit(s) }, onRemove = if (isTop) ({ onRemove(s) }) else null)
                                }
                            }
                        } else {
                            val n = playCounts[s.id] ?: 0
                            val sub = if (group.kind == "plays") "$n ${if (n == 1) "reproducción" else "reproducciones"} | ${s.artist}" else "${s.artist} - ${s.album}"
                            ItemRow(s.title, sub, s, hasLyrics = s.id in lyricIds, current = ps.mediaId == s.id.toString(), playing = ps.playing,
                                selecting = selecting, checked = s.id in selected,
                                trailing = if (selecting) null else ({
                                    SongMenu({ playNext(player, s) }, { addToQueue(player, s) }, { onAdd(s) }, { onEdit(s) },
                                        onRemove = if (group.kind == "list") ({ onRemove(s) }) else null)
                                })
                            ) { if (selecting) onToggle(s.id) else playList(player, list, list.indexOf(s), shuffleOn) }
                        }
                    }
                    item { BottomSpace(bottomPad) }
                }
            }
        }
    }
}

/** Llega hasta el borde de abajo. Se desliza hacia arriba para abrir el reproductor grande. */
@Composable
private fun MiniPlayer(player: Player, ps: PState, current: Song?, shuffleOn: Boolean, dragMod: Modifier,
                       onToggleShuffle: () -> Unit, onNow: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val pos by rememberPos(player)
    val dur = (if (CrossView.item != null) CrossView.durMs else player.duration).coerceAtLeast(1L)
    val accent = if (cs.background.luminance() > 0.5f) cs.onPrimaryContainer else cs.primary
    Surface(onClick = onNow, modifier = dragMod, color = cs.primaryContainer,
        shape = RoundedCornerShape(topStart = cr(c, 32), topEnd = cr(c, 32))) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Art(current, 256, Modifier.size(56.dp))
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(current?.title ?: ps.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(current?.artist ?: ps.artist, style = MaterialTheme.typography.bodyMedium, maxLines = 1, color = cs.onPrimaryContainer.copy(alpha = .7f))
                }
                IconButton(onToggleShuffle) {
                    Icon(Icons.Rounded.Shuffle, "Aleatorio", tint = if (shuffleOn) cs.primary else cs.onPrimaryContainer.copy(alpha = .75f))
                }
                PlayPauseButton(ps.playing, 52.dp, 36.dp, accent) { if (ps.playing) player.pause() else player.play() }
            }
            SeekBar(pos, dur, { player.seekTo(it) }, Modifier.fillMaxWidth(), 6.dp, cs.onPrimaryContainer.copy(alpha = .15f), cs.primary)
        }
    }
}

/** Listas: dos automáticas arriba (más reproducido y con letras) y las tuyas, que se crean con el campo. */
@Composable
private fun PlaylistsTab(songs: List<Song>, lists: Map<String, List<Long>>, prefs: Prefs, bottomPad: Dp,
                         lyricIds: Set<Long>, playCounts: Map<Long, Int>, onOpen: (Group) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    val byId = remember(songs) { songs.associateBy { it.id } }
    val withLyrics = remember(songs, lyricIds) { songs.filter { it.id in lyricIds } }
    val played = remember(songs, playCounts) { songs.filter { (playCounts[it.id] ?: 0) > 0 }.sortedByDescending { playCounts[it.id] ?: 0 } }
    fun create() {
        val n = name.trim()                       // se copia ANTES de lanzar: si no, el campo ya está vacío cuando se guarda
        if (n.isEmpty()) return
        if (n == TOP_LIST || lists.containsKey(n)) { Toast.makeText(ctx, "Ya existe una lista con ese nombre", Toast.LENGTH_SHORT).show(); return }
        scope.launch { prefs.savePlaylists(lists + (n to emptyList())) }
        name = ""
    }
    Column(Modifier.padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(name, { name = it }, Modifier.weight(1f), placeholder = { Text("Nueva lista") }, singleLine = true,
                shape = RoundedCornerShape(cr(LocalCorner.current, 24)),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { create() }))
            IconButton({ create() }) { Icon(Icons.Rounded.Add, "Crear") }
        }
        LazyColumn {
            item { ItemRow("Más reproducido", "${played.size} canciones", played.firstOrNull()) { onOpen(Group("plays", "Más reproducido")) } }
            item { ItemRow("Con letras", "${withLyrics.size} canciones", withLyrics.firstOrNull()) { onOpen(Group("lyrics", "Con letras")) } }
            item {
                val topIds = lists[TOP_LIST] ?: emptyList()
                ItemRow(TOP_LIST, "${topIds.size} ${if (topIds.size == 1) "canción" else "canciones"}", topIds.firstNotNullOfOrNull { byId[it] }) { onOpen(Group("list", TOP_LIST)) }
            }
            items(lists.keys.filter { it.isNotBlank() && it != TOP_LIST }.toList(), key = { it }) { n ->
                val ids = lists[n] ?: emptyList()
                ItemRow(n, "${ids.size} ${if (ids.size == 1) "canción" else "canciones"}", ids.firstNotNullOfOrNull { byId[it] }) { onOpen(Group("list", n)) }
            }
            item { BottomSpace(bottomPad) }
        }
    }
}

@Composable
private fun SelAction(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
        .padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = LocalContentColor.current.copy(alpha = if (enabled) 1f else .38f))
        Text(label, style = MaterialTheme.typography.labelSmall, color = LocalContentColor.current.copy(alpha = if (enabled) 1f else .38f))
    }
}

/** Barra de abajo de la selección múltiple. */
@Composable
private fun SelectionBar(count: Int, onAll: () -> Unit, onCancel: () -> Unit, onNext: () -> Unit, onQueue: () -> Unit,
                         onList: () -> Unit, onHide: () -> Unit, onDelete: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(topStart = cr(c, 32), topEnd = cr(c, 32)), color = cs.secondaryContainer) {
        Column(Modifier.navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$count seleccionadas", Modifier.weight(1f).padding(start = 8.dp), fontWeight = FontWeight.Bold)
                TextButton(onAll) { Text("Todo") }
                TextButton(onCancel) { Text("Cancelar") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                SelAction(Icons.Rounded.PlayArrow, "Siguiente", count > 0, onNext)
                SelAction(Icons.Default.QueueMusic, "Fila", count > 0, onQueue)
                SelAction(Icons.Rounded.Add, "Lista", count > 0, onList)
                SelAction(Icons.Rounded.VisibilityOff, "Ocultar", count > 0, onHide)
                SelAction(Icons.Rounded.Delete, "Eliminar", count > 0, onDelete)
            }
        }
    }
}

// ───────────── reproducción ─────────────

@Composable
private fun NowPlaying(player: Player, ps: PState, song: Song?, lists: Map<String, List<Long>>, prefs: Prefs, firstLine: String?,
                       lyrics: String, vinyl: VinylDesign?, dragMod: Modifier, onLyrics: () -> Unit, onQueue: () -> Unit, onDelete: () -> Unit, onHide: () -> Unit, onNote: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val scope = rememberCoroutineScope()
    val pos by rememberPos(player)
    var menu by remember { mutableStateOf(false) }
    var eqOpen by remember { mutableStateOf(false) }
    val dragX = remember { Animatable(0f) }
    // en temas claros el acento es muy pálido para texto: se usa el color más oscuro del tema
    val accent = if (cs.background.luminance() > 0.5f) cs.onPrimaryContainer else cs.primary
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val favs = lists["Favoritas"] ?: emptyList()
    val fav = song != null && song.id in favs
    val topIds = lists[TOP_LIST] ?: emptyList()
    val inTop = song != null && song.id in topIds
    val vinylMode by prefs.vinylPortrait.collectAsState(false)
    val topCtx = LocalContext.current
    // estrella: si no está en el Top entra en el puesto 1; si ya está, se saca
    fun toggleTop() {
        val s = song ?: return
        val was = s.id in topIds
        scope.launch { prefs.savePlaylists(lists + (TOP_LIST to (if (was) topIds - s.id else listOf(s.id) + topIds))) }
        Toast.makeText(topCtx, if (was) "Sacada del Top" else "Agregada al Top, puesto 1", Toast.LENGTH_SHORT).show()
    }
    val dur = (if (CrossView.item != null) CrossView.durMs else player.duration).coerceAtLeast(1L)
    val title = song?.title ?: ps.title
    val artist = song?.artist ?: ps.artist
    fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)
    // doble toque en la portada = favorita (sale un corazón)
    var heartKey by remember { mutableIntStateOf(0) }
    var heartOn by remember { mutableStateOf(true) }
    val heartAnim = remember { Animatable(0f) }
    LaunchedEffect(heartKey) { if (heartKey > 0) { heartAnim.snapTo(1f); heartAnim.animateTo(0f, tween(800)) } }
    fun doubleTapFav() {
        val s = song ?: return
        heartOn = s.id !in favs
        heartKey++
        scope.launch { prefs.savePlaylists(lists + ("Favoritas" to (if (s.id in favs) favs - s.id else favs + s.id))) }
    }

    Surface(Modifier.fillMaxSize().then(dragMod), color = cs.primaryContainer) {
        if (landscape) NowLandscape(player, ps, song, title, artist, lyrics, fav, vinyl,
            { song?.let { s -> scope.launch { prefs.savePlaylists(lists + ("Favoritas" to (if (s.id in favs) favs - s.id else favs + s.id))) } } },
            inTop, { toggleTop() },
            pos, dur, onLyrics, onQueue, { eqOpen = true }, onDelete, onHide, onNote)
        else Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp)) {
            Spacer(Modifier.height(24.dp))
            // Portada sin marco: se desliza a un lado para cambiar de canción
            Box(
                Modifier.fillMaxWidth().aspectRatio(1f)
                    .graphicsLayer { translationX = dragX.value; alpha = 1f - (abs(dragX.value) / 1000f).coerceIn(0f, .45f) }
                    .pointerInput(song?.id) { detectTapGestures(onDoubleTap = { doubleTapFav() }) }
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                scope.launch {
                                    val v = dragX.value
                                    if (v < -140f) player.seekToNextMediaItem() else if (v > 140f) player.seekToPreviousMediaItem()
                                    dragX.animateTo(0f, spring())
                                }
                            },
                            onDragCancel = { scope.launch { dragX.animateTo(0f, spring()) } },
                            onHorizontalDrag = { change, amount -> change.consume(); scope.launch { dragX.snapTo(dragX.value + amount * 0.85f) } }
                        )
                    }
            ) {
                if (vinylMode) BoxWithConstraints(Modifier.fillMaxSize()) {
                    // el mismo disco del modo horizontal: textura del álbum, portada de etiqueta y brazo
                    val s = minOf(maxWidth, maxHeight) / 1.15f
                    Box(Modifier.size(s * 1.15f).align(Alignment.Center)) {
                        VinylDisc(song, ps.playing, vinyl, Modifier.fillMaxSize())
                        Tonearm(Modifier.size(s).offset(x = s * 0.175f, y = s * 0.195f), ps.playing)
                    }
                } else Crossfade(targetState = song, animationSpec = tween(320), label = "cover") { s ->
                    Art(s, 800, Modifier.fillMaxSize(), cr(c, 56))
                }
                if (heartAnim.value > 0.01f) Icon(if (heartOn) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null,
                    Modifier.align(Alignment.Center).size(110.dp).graphicsLayer { alpha = heartAnim.value; scaleX = 1.3f - 0.3f * heartAnim.value; scaleY = 1.3f - 0.3f * heartAnim.value },
                    tint = Color.White)
            }
            Spacer(Modifier.height(22.dp))
            Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = accent,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(artist, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    color = cs.onPrimaryContainer.copy(alpha = .6f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                IconButton({
                    song?.let { s -> scope.launch { prefs.savePlaylists(lists + ("Favoritas" to (if (s.id in favs) favs - s.id else favs + s.id))) } }
                }) {
                    Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorita",
                        tint = if (fav) cs.primary else cs.onPrimaryContainer.copy(alpha = .7f))
                }
                IconButton({ toggleTop() }) {
                    Icon(if (inTop) Icons.Rounded.Star else Icons.Rounded.StarBorder, "Top canciones",
                        tint = if (inTop) cs.primary else cs.onPrimaryContainer.copy(alpha = .7f))
                }
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "Más") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Eliminar canción") }, { menu = false; onDelete() }, leadingIcon = { Icon(Icons.Rounded.Delete, null) })
                        DropdownMenuItem({ Text("Ocultar") }, { menu = false; onHide() }, leadingIcon = { Icon(Icons.Rounded.VisibilityOff, null) })
                        DropdownMenuItem({ Text("Nota") }, { menu = false; onNote() }, leadingIcon = { Icon(Icons.Rounded.Edit, null) })
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            SeekBar(pos, dur, { player.seekTo(it) }, Modifier.fillMaxWidth(), 14.dp, cs.onPrimaryContainer.copy(alpha = .18f), cs.onPrimaryContainer.copy(alpha = .75f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(pos), color = cs.onPrimaryContainer.copy(alpha = .6f)); Text(fmt(dur), color = cs.onPrimaryContainer.copy(alpha = .6f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton({ player.seekToPrevious() }, Modifier.size(76.dp)) { Icon(Icons.Rounded.FastRewind, "Anterior", Modifier.size(52.dp), tint = accent) }
                PlayPauseButton(ps.playing, 108.dp, 88.dp, accent) { if (ps.playing) player.pause() else player.play() }
                IconButton({ player.seekToNext() }, Modifier.size(76.dp)) { Icon(Icons.Rounded.FastForward, "Siguiente", Modifier.size(52.dp), tint = accent) }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ eqOpen = true }) { Icon(Icons.Rounded.Tune, "Ecualizador", tint = cs.onPrimaryContainer.copy(alpha = .7f)) }
                Surface(onClick = onLyrics, modifier = Modifier.weight(1f).padding(horizontal = 8.dp), shape = RoundedCornerShape(cr(c, 24)),
                    color = cs.onPrimaryContainer.copy(alpha = .08f)) {
                    Text(firstLine ?: "Letra", Modifier.padding(horizontal = 18.dp, vertical = 16.dp), fontWeight = FontWeight.Bold,
                        color = accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onQueue) { Icon(Icons.Default.QueueMusic, "Fila", tint = cs.onPrimaryContainer.copy(alpha = .7f)) }
            }
        }
    }

    if (eqOpen) {
        val eq = remember { PlayerHolder.equalizer(LocalContextHolder.ctx) }
        AlertDialog({ eqOpen = false }, confirmButton = { TextButton({ eqOpen = false }) { Text("Listo") } }, title = { Text("Ecualizador") }, text = {
            Column {
                val range = eq.bandLevelRange
                for (b in 0 until eq.numberOfBands) {
                    var lvl by remember { mutableFloatStateOf(eq.getBandLevel(b.toShort()).toFloat()) }
                    Text("${eq.getCenterFreq(b.toShort()) / 1000} Hz")
                    Slider(lvl, { lvl = it; eq.setBandLevel(b.toShort(), it.toInt().toShort()) }, valueRange = range[0].toFloat()..range[1].toFloat())
                }
            }
        })
    }
}

@Composable
private fun QueueScreen(player: Player, ps: PState, byId: Map<Long, Song>, cur: Song?, shuffleOn: Boolean,
                        onOrder: () -> Unit, onShuffle: () -> Unit, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val scope = rememberCoroutineScope()
    val pos by rememberPos(player)
    val q by rememberQueue(player)
    val listState = rememberLazyListState()
    var dragId by remember { mutableStateOf<String?>(null) }
    // Mientras se arrastra se reordena una copia local; el reproductor se actualiza una sola vez al soltar.
    var local by remember { mutableStateOf<List<MediaItem>?>(null) }
    val items = local ?: q.items
    val sheet = cs.onPrimaryContainer.copy(alpha = .07f).compositeOver(cs.primaryContainer)
    val dur = (if (CrossView.item != null) CrossView.durMs else player.duration).coerceAtLeast(1L)

    LaunchedEffect(q.items, dragId) {
        val l = local
        if (dragId == null && l != null && q.items.map { it.mediaId } == l.map { it.mediaId }) local = null
    }
    LaunchedEffect(dragId) { if (dragId == null && local != null) { delay(500); local = null } }

    // la librería se ocupa del arrastre, las animaciones y del desplazamiento en los bordes
    val reorderState = rememberReorderableLazyListState(listState) { from, to ->
        val cur = local ?: q.items
        val f = cur.indexOfFirst { it.mediaId == from.key }
        val tt = cur.indexOfFirst { it.mediaId == to.key }
        if (f >= 0 && tt >= 0 && f != tt) local = cur.toMutableList().apply { add(tt, removeAt(f)) }
    }

    fun finishDrag(id: String) {
        val list = local
        val orig = indexOfId(player, id)
        if (list != null && orig >= 0) {
            val fin = list.indexOfFirst { it.mediaId == id }
            if (fin >= 0 && fin != orig) player.moveMediaItem(orig, fin)
        }
        dragId = null
    }

    Surface(Modifier.fillMaxSize(), color = cs.primaryContainer) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(cur, 256, Modifier.size(64.dp))
                Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                    Text(cur?.title ?: ps.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(cur?.artist ?: ps.artist, color = cs.onPrimaryContainer.copy(alpha = .65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton({ if (ps.playing) player.pause() else player.play() }, Modifier.size(56.dp)) {
                    Icon(if (ps.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(40.dp))
                }
            }
            SeekBar(pos, dur, { player.seekTo(it) }, Modifier.fillMaxWidth().padding(horizontal = 20.dp), 8.dp,
                cs.onPrimaryContainer.copy(alpha = .15f), cs.onPrimaryContainer.copy(alpha = .7f))
            Spacer(Modifier.height(8.dp))
            Surface(Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(topStart = cr(c, 36), topEnd = cr(c, 36)), color = sheet) {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxWidth().clickable(onClick = onBack).padding(top = 8.dp), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "Cerrar", Modifier.size(32.dp), tint = cs.onPrimaryContainer.copy(alpha = .6f))
                    }
                    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Fila", Modifier.weight(1f), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        IconButton({ if (q.index >= 0) scope.launch { listState.animateScrollToItem(q.index) } }) {
                            Icon(Icons.Rounded.CenterFocusStrong, "Ir a la actual")
                        }
                        IconButton({ clearQueue(player) }) { Icon(Icons.Rounded.DeleteSweep, "Vaciar fila") }
                    }
                    LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
                        itemsIndexed(items, key = { _, m -> m.mediaId }) { _, item ->
                            ReorderableItem(reorderState, key = item.mediaId) { dragging ->
                                val s = byId[item.mediaId.toLongOrNull()]
                                val isCur = item.mediaId == ps.mediaId
                                Row(
                                    Modifier.fillMaxWidth().height(80.dp)
                                        .background(if (dragging) cs.onPrimaryContainer.copy(alpha = .10f) else Color.Transparent)
                                        .clickable { val i = indexOfId(player, item.mediaId); if (i >= 0) { player.seekTo(i, 0L); player.play() } }
                                        .padding(start = 16.dp, end = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Art(s, 256, Modifier.size(64.dp))
                                        if (isCur) Box(Modifier.size(64.dp).clip(RoundedCornerShape(cr(c, 24))).background(Color.Black.copy(alpha = .38f)),
                                            contentAlignment = Alignment.Center) { EqBars(ps.playing, Color.White, Modifier.size(26.dp)) }
                                    }
                                    Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                                        Text(s?.title ?: (item.mediaMetadata.title?.toString() ?: ""), style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold, color = if (isCur) cs.primary else cs.onPrimaryContainer,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(if (s != null) "${s.artist} - ${s.album}" else "", color = cs.onPrimaryContainer.copy(alpha = .6f),
                                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Icon(Icons.Rounded.DragHandle, "Mover", Modifier.size(48.dp).padding(10.dp).draggableHandle(
                                        onDragStarted = { local = local ?: q.items; dragId = item.mediaId },
                                        onDragStopped = { finishDrag(item.mediaId) }
                                    ), tint = cs.onPrimaryContainer.copy(alpha = .7f))
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        PillButton(Icons.Rounded.Repeat, "En orden", !shuffleOn, Modifier.weight(1f), onOrder)
                        PillButton(Icons.Rounded.Shuffle, "Aleatorio", shuffleOn, Modifier.weight(1f), onShuffle)
                    }
                }
            }
        }
    }
}

@Composable
private fun LyricsScreen(song: Song?, lyrics: String, onBack: () -> Unit, onChanged: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val scale = LocalLyricsScale.current
    val ctx = LocalContext.current
    var editing by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    val note = remember(song?.id, editing) { if (song == null) "" else Store.read(ctx, "notes", song.id) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && song != null) {
            val txt = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
            if (!txt.isNullOrBlank()) { Store.write(ctx, "lyrics", song.id, txt); onChanged() }
        }
    }
    Surface(Modifier.fillMaxSize(), color = cs.primaryContainer) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Rounded.KeyboardArrowDown, "Volver", Modifier.size(30.dp)) }
                Column(Modifier.weight(1f)) {
                    Text(song?.title ?: "", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song?.artist ?: "", color = cs.onPrimaryContainer.copy(alpha = .65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton({ picker.launch(arrayOf("*/*")) }) { Icon(Icons.Rounded.Description, "Importar archivo") }
                IconButton({ draft = lyrics; editing = true }) { Icon(Icons.Rounded.Edit, "Editar letra") }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 8.dp)) {
                if (note.isNotBlank()) {
                    Surface(shape = RoundedCornerShape(cr(c, 20)), color = cs.onPrimaryContainer.copy(alpha = .10f)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Rounded.Edit, null, Modifier.size(20.dp), tint = cs.primary)
                            Text(note, Modifier.padding(start = 10.dp))
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }
                if (lyrics.isBlank()) Text(
                    "No hay letra para esta canción. Tocá el lápiz para pegarla o el ícono de archivo para importar un .lrc o .txt.",
                    color = cs.onPrimaryContainer.copy(alpha = .7f)
                ) else Text(
                    lyrics,
                    style = MaterialTheme.typography.headlineSmall.copy(fontSize = (24f * scale / 100f).sp, lineHeight = (32f * scale / 100f).sp),
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(64.dp))
            }
        }
    }
    if (editing) Dialog(onDismissRequest = { editing = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxWidth().imePadding().padding(horizontal = 16.dp, vertical = 24.dp).heightIn(max = 600.dp),
            shape = RoundedCornerShape(cr(LocalCorner.current, 28)), color = MaterialTheme.colorScheme.surfaceContainerHigh
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Letra", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(draft, { draft = it }, Modifier.fillMaxWidth().weight(1f), placeholder = { Text("Pegá la letra acá") })
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                    TextButton({ editing = false }) { Text("Cancelar") }
                    TextButton({ if (song != null) Store.write(ctx, "lyrics", song.id, draft); editing = false; onChanged() }) { Text("Guardar") }
                }
            }
        }
    }
}


// ───────────── resumen del mes ─────────────

private val monthNames = listOf("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre")

private class Summary(val total: Int, val minutes: Int, val songs: List<Pair<Song, Int>>, val artists: List<Pair<String, Int>>,
                      val album: Pair<String, Int>?, val top5: List<Song>)

private fun summaryOf(ctx: Context, byId: Map<Long, Song>, lists: Map<String, List<Long>>, year: Int, month: Int): Summary {
    val ids = Plays.inMonth(ctx, year, month).filter { byId.containsKey(it) }
    val topSongs = ids.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(5)
        .mapNotNull { e -> byId[e.key]?.let { it to e.value } }
    val artistCount = HashMap<String, Int>()
    val albumCount = HashMap<String, Int>()
    for (id in ids) {
        val s = byId[id] ?: continue
        splitArtists(s.artist).forEach { a -> artistCount[a] = (artistCount[a] ?: 0) + 1 }
        if (s.album.isNotBlank()) albumCount[s.album] = (albumCount[s.album] ?: 0) + 1
    }
    val topArtists = artistCount.entries.sortedByDescending { it.value }.take(3).map { it.key to it.value }
    val topAlbum = albumCount.entries.maxByOrNull { it.value }?.let { it.key to it.value }
    val minutes = (ids.sumOf { byId[it]?.durationMs ?: 0L } / 60000L).toInt()
    val top5 = (lists[TOP_LIST] ?: emptyList()).mapNotNull { byId[it] }.take(5)
    return Summary(ids.size, minutes, topSongs, topArtists, topAlbum, top5)
}

private fun summaryText(s: Summary): String = buildString {
    if (s.songs.isNotEmpty()) {
        appendLine("Canciones más escuchadas")
        s.songs.forEachIndexed { i, (song, n) -> appendLine("${i + 1}. ${song.title} - ${song.artist} ($n)") }
        appendLine()
    }
    if (s.artists.isNotEmpty()) {
        appendLine("Artistas más escuchados")
        s.artists.forEachIndexed { i, (a, n) -> appendLine("${i + 1}. $a ($n)") }
        appendLine()
    }
    s.album?.let { appendLine("Álbum del mes: ${it.first}"); appendLine() }
    appendLine("Reproducciones: ${s.total}, unos ${s.minutes} minutos")
    if (s.top5.isNotEmpty()) {
        appendLine()
        appendLine("Mi Top 5")
        s.top5.forEachIndexed { i, song -> appendLine("${i + 1}. ${song.title} - ${song.artist}") }
    }
}.trim()

@Composable
private fun SummarySection(title: String, lines: List<String>) {
    val cs = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxWidth().padding(vertical = 6.dp), shape = RoundedCornerShape(cr(LocalCorner.current, 24)), color = cs.primary.copy(alpha = .10f)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = cs.primary)
            lines.forEach { Text(it, Modifier.padding(top = 6.dp)) }
        }
    }
}

/** Lo que más escuchaste en un mes. Se cuenta desde que se instaló esta versión. Se puede guardar como nota. */
@Composable
private fun SummaryScreen(songs: List<Song>, lists: Map<String, List<Long>>, onSaved: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val now = remember { Calendar.getInstance() }
    val curYear = now.get(Calendar.YEAR)
    val curMonth = now.get(Calendar.MONTH)
    var year by remember { mutableIntStateOf(curYear) }
    var month by remember { mutableIntStateOf(curMonth) }
    val byId = remember(songs) { songs.associateBy { it.id } }
    val data = remember(year, month, byId, lists) { summaryOf(ctx, byId, lists, year, month) }
    val isCurrent = year == curYear && month == curMonth
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") }
            Text("Resumen del mes", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            IconButton({ if (month == 0) { month = 11; year-- } else month-- }) { Icon(Icons.Rounded.ChevronLeft, "Mes anterior") }
            Text("${monthNames[month].replaceFirstChar { it.uppercase() }} $year", Modifier.widthIn(min = 170.dp), style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            IconButton({ if (month == 11) { month = 0; year++ } else month++ }, enabled = !isCurrent) { Icon(Icons.Rounded.ChevronRight, "Mes siguiente") }
        }
        Spacer(Modifier.height(8.dp))
        if (data.total == 0) {
            Text("Todavía no hay reproducciones guardadas en este mes. El conteo por mes empieza desde que instalaste esta versión.",
                Modifier.padding(vertical = 12.dp), color = cs.onSurfaceVariant)
        } else {
            SummarySection("Canciones más escuchadas", data.songs.mapIndexed { i, (s, n) -> "${i + 1}. ${s.title} - ${s.artist} ($n)" })
            SummarySection("Artistas más escuchados", data.artists.mapIndexed { i, (a, n) -> "${i + 1}. $a ($n)" })
            data.album?.let { SummarySection("Álbum del mes", listOf(it.first)) }
            SummarySection("En total", listOf("${data.total} reproducciones, unos ${data.minutes} minutos"))
        }
        if (data.top5.isNotEmpty()) SummarySection("Mi Top 5", data.top5.mapIndexed { i, s -> "${i + 1}. ${s.title} - ${s.artist}" })
        Spacer(Modifier.height(12.dp))
        Button({
            val id = -(year * 100L + (month + 1))
            Store.write(ctx, "notes", id, summaryText(data))
            if (Store.read(ctx, "notets", id).isBlank()) Store.write(ctx, "notets", id, System.currentTimeMillis().toString())
            Toast.makeText(ctx, "Guardado en Notas", Toast.LENGTH_SHORT).show()
            onSaved()
        }, Modifier.fillMaxWidth().height(52.dp), enabled = data.total > 0 || data.top5.isNotEmpty()) {
            Icon(Icons.Rounded.Edit, null, Modifier.padding(end = 8.dp))
            Text("Guardar como nota", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
    }
}


// ───────────── canciones duplicadas ─────────────

private fun dupKey(s: Song): String =
    s.title.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim() + "|" + (splitArtists(s.artist).firstOrNull() ?: "").lowercase().trim()

/** Canciones con el mismo nombre y artista. Ocultar las saca de la biblioteca sin borrar el archivo. */
@Composable
private fun DuplicatesScreen(songs: List<Song>, onHide: (Song) -> Unit, onDelete: (Song) -> Unit, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val groups = remember(songs) { songs.groupBy { dupKey(it) }.values.filter { it.size > 1 }.sortedBy { it[0].title.lowercase() } }
    var confirm by remember { mutableStateOf<Song?>(null) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)) {
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") }
            Text("Canciones duplicadas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        if (groups.isEmpty()) {
            Text("No encontré canciones repetidas (mismo nombre y mismo artista).", Modifier.padding(vertical = 12.dp), color = cs.onSurfaceVariant)
        } else {
            Text("${groups.size} ${if (groups.size == 1) "canción repetida" else "canciones repetidas"}. Ocultar la saca de la biblioteca sin borrar el archivo; Eliminar sí lo borra del celu.",
                Modifier.padding(bottom = 8.dp), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            LazyColumn(Modifier.weight(1f)) {
                items(groups, key = { it[0].id }) { g ->
                    Surface(Modifier.fillMaxWidth().padding(vertical = 6.dp), shape = RoundedCornerShape(cr(LocalCorner.current, 24)),
                        color = cs.primary.copy(alpha = .10f)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(g[0].title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            g.forEach { s ->
                                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Art(s, 128, Modifier.size(44.dp))
                                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                        Text("${s.artist} - ${s.album}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("%d:%02d".format(s.durationMs / 60000, (s.durationMs / 1000) % 60), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                    }
                                    TextButton({ onHide(s) }) { Text("Ocultar") }
                                    TextButton({ confirm = s }) { Text("Eliminar") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    confirm?.let { s ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            confirmButton = { TextButton({ onDelete(s); confirm = null }) { Text("Eliminar") } },
            dismissButton = { TextButton({ confirm = null }) { Text("Cancelar") } },
            title = { Text("Eliminar canción") },
            text = { Text("¿Eliminar “${s.title}” del celu? Esto borra el archivo.") }
        )
    }
}

// ───────────── ajustes y tema ─────────────

@Composable
private fun SettingsScreen(prefs: Prefs, mix: Boolean, cfOn: Boolean, cfSec: Int, sleepMin: Int,
                           onSleep: (Int) -> Unit, hiddenSongs: List<Song>, textScale: Int, lyricsScale: Int, chipOn: Boolean, onImportLyrics: (Uri) -> Unit, onRefresh: () -> Unit, onSummary: () -> Unit, onDups: () -> Unit, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val sctx = LocalContext.current
    var confirmRestore by remember { mutableStateOf<Uri?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { Backup.export(sctx, uri, prefs) }
            Toast.makeText(sctx, if (ok) "Copia de seguridad guardada" else "No se pudo guardar la copia", Toast.LENGTH_LONG).show()
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) confirmRestore = uri }
    val resumeHs by prefs.resumeHeadset.collectAsState(true)
    val slowMix by prefs.slowMix.collectAsState(true)
    val vinylPortrait by prefs.vinylPortrait.collectAsState(false)
    var showHidden by remember { mutableStateOf(false) }
    var tv by remember { mutableFloatStateOf(textScale.toFloat()) }
    var lv by remember { mutableFloatStateOf(lyricsScale.toFloat()) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") }
            Text("Ajustes", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onSummary).padding(vertical = 12.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.BarChart, null, Modifier.padding(end = 16.dp))
            Column(Modifier.weight(1f)) {
                Text("Resumen del mes", fontWeight = FontWeight.Bold)
                Text("Lo que más escuchaste. Se puede guardar como nota.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onDups).padding(vertical = 12.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.ContentCopy, null, Modifier.padding(end = 16.dp))
            Column(Modifier.weight(1f)) {
                Text("Canciones duplicadas", fontWeight = FontWeight.Bold)
                Text("Busca canciones repetidas para ocultarlas o borrarlas.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Texto", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Tamaño del texto de la app", Modifier.weight(1f))
            Text("${tv.roundToInt()}%", fontWeight = FontWeight.Bold)
        }
        Slider(tv, { tv = it }, valueRange = 70f..130f, steps = 11, onValueChangeFinished = { scope.launch { prefs.setTextScale(tv.roundToInt()) } })
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Tamaño de la letra de las canciones", Modifier.weight(1f))
            Text("${lv.roundToInt()}%", fontWeight = FontWeight.Bold)
        }
        Slider(lv, { lv = it }, valueRange = 70f..160f, steps = 17, onValueChangeFinished = { scope.launch { prefs.setLyricsScale(lv.roundToInt()) } })
        Spacer(Modifier.height(12.dp))
        Text("Reproducción", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        SwitchRow(Icons.Rounded.Headphones, "Reproduce junto con otras aplicaciones", null, mix) { scope.launch { prefs.setMix(it) } }
        SwitchRow(Icons.Rounded.Headphones, "Retomar al conectar auriculares", "Si la música se pausó al desconectarlos", resumeHs) { scope.launch { prefs.setResumeHeadset(it) } }
        SwitchRow(Icons.Rounded.Album, "Vinilo en el reproductor vertical", "En lugar de la portada cuadrada, el disco con el brazo", vinylPortrait) { scope.launch { prefs.setVinylPortrait(it) } }
        SwitchRow(Icons.Rounded.SwapHoriz, "Crossfade", "Mezcla el final de una canción con el inicio de la siguiente", cfOn) { scope.launch { prefs.setCrossfadeOn(it) } }
        if (cfOn) Row(Modifier.fillMaxWidth().padding(start = 46.dp), verticalAlignment = Alignment.CenterVertically) {
            Slider(cfSec.toFloat(), { scope.launch { prefs.setCrossfadeSec(it.roundToInt()) } }, Modifier.weight(1f), valueRange = 1f..12f, steps = 10)
            Text("${cfSec}s", Modifier.padding(start = 12.dp), fontWeight = FontWeight.Bold)
        }
        if (cfOn) SwitchRow(Icons.Rounded.SwapHoriz, "Frenar la canción que se va", "Al mezclar, la anterior se ralentiza un poquito", slowMix) { scope.launch { prefs.setSlowMix(it) } }
        SwitchRow(Icons.Rounded.Notifications, "Título en la barra de estado",
            "Muestra una notificación chica con el título de la canción. Si tu sistema lo permite, aparece arriba como cápsula.", chipOn) { scope.launch { prefs.setChip(it) } }
        Spacer(Modifier.height(16.dp))
        Text("Temporizador de apagado", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0, 15, 30, 45, 60).forEach { m ->
                FilterChip(selected = sleepMin == m, onClick = { onSleep(m) }, label = { Text(if (m == 0) "Apagado" else "$m min") })
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().clickable { showHidden = true }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.VisibilityOff, null, Modifier.size(30.dp), tint = cs.onSurfaceVariant)
            Text("Canciones ocultas (${hiddenSongs.size})", Modifier.padding(start = 16.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().clickable { onRefresh() }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Refresh, null, Modifier.size(30.dp), tint = cs.onSurfaceVariant)
            Column(Modifier.padding(start = 16.dp)) {
                Text("Actualizar biblioteca", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Vuelve a leer las canciones del celu.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) onImportLyrics(uri) }
        Row(Modifier.fillMaxWidth().clickable { folderPicker.launch(null) }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Description, null, Modifier.size(30.dp), tint = cs.onSurfaceVariant)
            Column(Modifier.padding(start = 16.dp)) {
                Text("Importar letras desde una carpeta", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Elegí una carpeta con archivos .lrc o .txt y se asignan a las canciones por nombre. No pisa las letras que ya tenés.",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Copia de seguridad", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Solo se hace cuando vos lo pedís. Guarda notas, letras, listas, diseños de vinilo y reproducciones en un archivo. Sirve para reinstalar la app en este mismo celu; en otro celu las canciones pueden no coincidir.",
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton({ exportLauncher.launch("M!Perla-copia.zip") }, Modifier.weight(1f)) { Text("Guardar copia") }
            OutlinedButton({ restoreLauncher.launch(arrayOf("*/*")) }, Modifier.weight(1f)) { Text("Restaurar") }
        }
        Spacer(Modifier.navigationBarsPadding())
    }
    confirmRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { confirmRestore = null },
            confirmButton = {
                TextButton({
                    confirmRestore = null
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { Backup.import(sctx, uri, prefs) }
                        Toast.makeText(sctx, if (ok) "Copia restaurada. Cerrá y abrí la app para ver todo." else "No se pudo leer esa copia", Toast.LENGTH_LONG).show()
                        if (ok) onRefresh()
                    }
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton({ confirmRestore = null }) { Text("Cancelar") } },
            title = { Text("Restaurar copia de seguridad") },
            text = { Text("Se reemplazan tus listas, diseños de vinilo y canciones ocultas por los de la copia, y se suman o pisan notas y letras. ¿Seguir?") }
        )
    }
    if (showHidden) AlertDialog(
        onDismissRequest = { showHidden = false },
        confirmButton = { TextButton({ showHidden = false }) { Text("Cerrar") } },
        title = { Text("Canciones ocultas") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (hiddenSongs.isEmpty()) Text("No hay canciones ocultas.")
                hiddenSongs.forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(s.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        TextButton({ scope.launch { prefs.unhide(s.id) } }) { Text("Mostrar") }
                    }
                }
            }
        }
    )
}

@Composable
private fun ThemeScreen(prefs: Prefs, mode: String, seed: Int, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val artOn = LocalArtTheme.current
    val scope = rememberCoroutineScope()
    val darkNow = cs.background.luminance() < 0.5f
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") }
            Text("Tema", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(36.dp))
        val fixedName = when (seed) { -3 -> "Halloween"; -5 -> "Chocolate"; -7 -> "Spotify"; else -> specialThemes.firstOrNull { it.id == seed }?.name }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(cr(c, 32))).background(cs.secondaryContainer).padding(4.dp)) {
            if (fixedName != null) {
                Row(Modifier.weight(1f).clip(RoundedCornerShape(cr(c, 28))).background(cs.primary).padding(vertical = 14.dp, horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    val sym = themeSymbol(seed)
                    if (sym != null) Icon(sym, null, Modifier.size(22.dp), tint = cs.onPrimary) else Box(Modifier.size(18.dp).background(cs.onPrimary))
                    Text(fixedName, Modifier.padding(start = 10.dp), fontWeight = FontWeight.Bold, color = cs.onPrimary)
                }
            } else listOf(Triple("dark", "Oscuro", Icons.Rounded.DarkMode), Triple("light", "Claro", Icons.Rounded.LightMode),
                Triple("system", "Sistema", Icons.Rounded.BrightnessAuto)).forEach { (k, label, icon) ->
                val sel = mode == k
                Row(Modifier.weight(1f).clip(RoundedCornerShape(cr(c, 28))).background(if (sel) cs.primary else Color.Transparent)
                    .clickable { scope.launch { prefs.setMode(k) } }.padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, Modifier.size(20.dp), tint = if (sel) cs.onPrimary else cs.onSecondaryContainer)
                    Spacer(Modifier.width(6.dp))
                    Text(label, fontWeight = FontWeight.Bold, color = if (sel) cs.onPrimary else cs.onSecondaryContainer)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        // -1 dinámico, -4 monocromo, 0.. colores base (0 verde, 1 violeta, 2 azul, 3 rojo, 4 turquesa, 5 amarillo), -2 naranja,
        // y al final los que solo existen en una versión: -3 Halloween, -5 Chocolate, -6 Pastel de cumpleaños
        val order = (if (Build.VERSION.SDK_INT >= 31) listOf(-1) else emptyList()) + listOf(-4, 6, 7, 1, -2, 2, 3, 4, 5, -3, -5, -7) + specialThemes.map { it.id }
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            order.chunked(5).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            rowItems.forEach { i ->
                val sel = seed == i
                val sp = specialThemes.firstOrNull { it.id == i }
                val fill = when (i) {
                    -1 -> cs.surfaceVariant
                    -2 -> Color(0xFFFF7849)
                    -3 -> Color.Black
                    -4 -> if (darkNow) Color.White else Color.Black
                    -5 -> Color(0xFF45260F)
                    -7 -> Color.Black
                    else -> if (sp != null) Color(sp.bg) else seeds[i]
                }
                val ring: Color? = when (i) { -3 -> Color(0xFFFF8800); -5 -> Color(0xFF9F7753); -7 -> Color(0xFF1ED760); else -> sp?.let { Color(it.pri) } }
                val checkTint = when { sp != null -> Color(sp.pri); i == -1 -> cs.onSurface; i == -4 && darkNow -> Color(0xFF111213); else -> Color.White }
                Box(Modifier.weight(1f).aspectRatio(1f).clip(CircleShape).background(fill)
                    .then(if (ring != null) Modifier.border(2.dp, ring, CircleShape) else Modifier)
                    .then(if (sel) Modifier.border(3.dp, cs.onBackground, CircleShape) else Modifier)
                    .clickable { scope.launch { prefs.setSeed(i) } }, contentAlignment = Alignment.Center) {
                    if (sel) Icon(Icons.Rounded.Check, null, tint = checkTint)
                    else if (i == -1) Icon(Icons.Rounded.AutoAwesome, null, tint = cs.onSurface)
                }
            }
            repeat(5 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
            }
        }
        Spacer(Modifier.height(28.dp))
        val startCorner = c
        var v by remember { mutableFloatStateOf(startCorner.toFloat()) }
        Text("Redondeo de esquinas", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Slider(v, { v = it; scope.launch { prefs.setCorner(it.toInt()) } }, Modifier.weight(1f), valueRange = 0f..100f)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(cr(v.toInt(), 28))).background(cs.primary))
        }
        SwitchRow(Icons.Rounded.Palette, "Colores según la portada",
            "La pantalla de reproducción, el mini reproductor y la notificación toman los colores del álbum", artOn) { scope.launch { prefs.setArt(it) } }
        Spacer(Modifier.height(16.dp))
        Text("Notas", fontWeight = FontWeight.Bold)
        val noteSel = LocalNoteStyle.current
        listOf("theme" to "Según el tema", "sticker" to "Sticker", "postit" to "Post-it").forEach { (k, l) ->
            Row(Modifier.fillMaxWidth().clickable { scope.launch { prefs.setNoteStyle(k) } }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(noteSel == k, { scope.launch { prefs.setNoteStyle(k) } })
                Text(l)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Partículas al pausar y reanudar", fontWeight = FontWeight.Bold)
        val partSel = LocalParticles.current
        listOf("none" to "Ninguna", "notes" to "Notas musicales", "sparks" to "Chispas", "both" to "Notas y chispas").forEach { (k, l) ->
            Row(Modifier.fillMaxWidth().clickable { scope.launch { prefs.setParticles(k) } }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(partSel == k, { scope.launch { prefs.setParticles(k) } })
                Text(l)
            }
        }
        Spacer(Modifier.navigationBarsPadding())
        Spacer(Modifier.height(8.dp))
    }
}


// ───────────── modo horizontal: disco que gira ─────────────

/** Disco con la portada de etiqueta. Negro simple, o con el diseño elegido para el álbum. Gira al sonar y se frena al pausar. */
@Composable
private fun VinylDisc(song: Song?, spinning: Boolean, design: VinylDesign?, modifier: Modifier) {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(spinning) {
        if (spinning) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                angle = (angle + (now - last) / 1_000_000_000f * 36f) % 360f   // una vuelta cada 10 segundos
                last = now
            }
        }
    }
    val hole = MaterialTheme.colorScheme.primaryContainer
    Box(modifier.graphicsLayer { rotationZ = angle }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            if (design == null) drawCircle(Color(0xFF141414), r, center) else drawVinylPaint(design, r, center)
            val g = if (design == null) Color.White else Color.Black
            for (i in 0..13) {
                drawCircle(g.copy(alpha = if (i % 3 == 0) 0.07f else 0.035f), radius = r * (0.46f + i * 0.037f), center = center, style = Stroke(width = 1.5f))
            }
            drawCircle(g.copy(alpha = .10f), radius = r * 0.985f, center = center, style = Stroke(width = r * 0.012f))
            drawCircle(Color.White.copy(alpha = .12f), radius = r * 0.43f, center = center)
        }
        Art(song, 800, Modifier.fillMaxWidth(0.40f).aspectRatio(1f), 1000.dp)
    }
}

/** Brazo blanco del tocadiscos: baja sobre el disco al sonar y se levanta un poco al pausar. */
@Composable
private fun Tonearm(modifier: Modifier, playing: Boolean) {
    val lift by animateFloatAsState(if (playing) 0f else -16f, tween(600), label = "arm")
    Canvas(modifier.graphicsLayer { rotationZ = lift; transformOrigin = TransformOrigin(0.787f, 0f) }) {
        val s = size.minDimension
        val arm = Path()
        arm.moveTo(0.787f * s, -0.03f * s)
        arm.cubicTo(0.835f * s, 0.18f * s, 0.85f * s, 0.34f * s, 0.825f * s, 0.455f * s)
        drawPath(arm, Color.White, style = Stroke(width = 0.014f * s, cap = StrokeCap.Round))
        drawRoundRect(Color.White, topLeft = Offset(0.797f * s, 0.43f * s), size = Size(0.056f * s, 0.095f * s), cornerRadius = CornerRadius(0.028f * s))
    }
}

@Composable
private fun NowMenu(onDelete: () -> Unit, onHide: () -> Unit, onNote: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }) { Icon(Icons.Rounded.MoreVert, "Más") }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem({ Text("Eliminar canción") }, { open = false; onDelete() }, leadingIcon = { Icon(Icons.Rounded.Delete, null) })
            DropdownMenuItem({ Text("Ocultar") }, { open = false; onHide() }, leadingIcon = { Icon(Icons.Rounded.VisibilityOff, null) })
            DropdownMenuItem({ Text("Nota") }, { open = false; onNote() }, leadingIcon = { Icon(Icons.Rounded.Edit, null) })
        }
    }
}

/** Reproductor con el cel en horizontal: disco a la izquierda; título, letra y controles a la derecha. */
@Composable
private fun NowLandscape(player: Player, ps: PState, song: Song?, title: String, artist: String, lyrics: String, fav: Boolean, vinyl: VinylDesign?,
                         onFav: () -> Unit, inTop: Boolean, onTop: () -> Unit, pos: Long, dur: Long, onLyrics: () -> Unit, onQueue: () -> Unit, onEq: () -> Unit,
                         onDelete: () -> Unit, onHide: () -> Unit, onNote: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scale = LocalLyricsScale.current
    val strong = cs.onPrimaryContainer
    val soft = cs.onPrimaryContainer.copy(alpha = .55f)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val hDp = maxHeight
        VinylDisc(song, ps.playing, vinyl, Modifier.size(hDp * 1.15f).offset(x = hDp * (-0.175f), y = hDp * (-0.195f)))
        Tonearm(Modifier.size(hDp), ps.playing)
        Row(Modifier.fillMaxSize().systemBarsPadding()) {
            Spacer(Modifier.weight(0.5f))
            Column(Modifier.weight(0.5f).fillMaxHeight().padding(end = 24.dp, top = 4.dp, bottom = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.weight(1f))
                    IconButton(onEq) { Icon(Icons.Rounded.Tune, "Ecualizador", tint = soft) }
                    IconButton(onQueue) { Icon(Icons.Default.QueueMusic, "Fila", tint = soft) }
                    NowMenu(onDelete, onHide, onNote)
                }
                Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = strong, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(artist, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = soft, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                // la letra se desvanece arriba y abajo; se toca para abrirla completa
                Box(
                    Modifier.weight(1f).fillMaxWidth()
                        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                        .drawWithContent {
                            drawContent()
                            drawRect(
                                Brush.verticalGradient(0f to Color.Transparent, 0.10f to Color.Black, 0.78f to Color.Black, 1f to Color.Transparent),
                                blendMode = BlendMode.DstIn
                            )
                        }
                        .clickable(onClick = onLyrics)
                ) {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        if (lyrics.isBlank()) Text("Sin letra. Tocá para agregarla.", color = soft, modifier = Modifier.padding(top = 12.dp))
                        else lyrics.lines().forEach { l ->
                            if (l.isBlank()) Spacer(Modifier.height(14.dp))
                            else Text(l, style = MaterialTheme.typography.titleLarge.copy(fontSize = (20f * scale / 100f).sp),
                                fontWeight = FontWeight.Bold, color = soft, modifier = Modifier.padding(vertical = 5.dp))
                        }
                        Spacer(Modifier.height(60.dp))
                    }
                }
                SeekBar(pos, dur, { player.seekTo(it) }, Modifier.fillMaxWidth(), 8.dp, strong.copy(alpha = .15f), strong.copy(alpha = .7f))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onFav) {
                        Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorita", Modifier.size(32.dp),
                            tint = if (fav) cs.primary else soft)
                    }
                    IconButton(onTop) {
                        Icon(if (inTop) Icons.Rounded.Star else Icons.Rounded.StarBorder, "Top canciones", Modifier.size(32.dp),
                            tint = if (inTop) cs.primary else soft)
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton({ player.seekToPrevious() }, Modifier.size(64.dp)) { Icon(Icons.Rounded.FastRewind, "Anterior", Modifier.size(44.dp), tint = strong) }
                    PlayPauseButton(ps.playing, 76.dp, 60.dp, strong) { if (ps.playing) player.pause() else player.play() }
                    IconButton({ player.seekToNext() }, Modifier.size(64.dp)) { Icon(Icons.Rounded.FastForward, "Siguiente", Modifier.size(44.dp), tint = strong) }
                }
            }
        }
    }
}


// ───────────── editor del diseño del vinilo ─────────────

@Composable
private fun SlotChip(label: String, color: Int, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, shape = RoundedCornerShape(50), color = if (selected) cs.primary.copy(alpha = .2f) else Color.Transparent,
        border = BorderStroke(1.5.dp, if (selected) cs.primary else cs.outline)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(20.dp).clip(CircleShape).background(Color(color)).border(1.dp, cs.outline, CircleShape))
            Text(label, Modifier.padding(start = 8.dp), fontWeight = FontWeight.Bold)
        }
    }
}

/** Elegís textura y hasta dos colores; el disco de arriba gira en vivo. Se aplica a todo el álbum. */
@Composable
private fun VinylEditorDialog(album: String, song: Song?, initial: VinylDesign?, onSave: (VinylDesign?) -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    var texture by remember { mutableStateOf(initial?.texture ?: "solid") }
    var c1 by remember { mutableIntStateOf(initial?.c1 ?: 0xFF2196F3.toInt()) }
    var c2 by remember { mutableIntStateOf(initial?.c2 ?: 0xFFF5F5F5.toInt()) }
    var slot by remember { mutableIntStateOf(0) }
    val two = texture != "solid"
    val editing = if (two && slot == 1) c2 else c1
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(cr(c, 32)), color = cs.surfaceContainerHigh) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Diseño del vinilo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(album, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(14.dp))
                VinylDisc(song, true, VinylDesign(texture, c1, c2), Modifier.size(190.dp))
                Spacer(Modifier.height(14.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vinylTextures) { (id, name) ->
                        FilterChip(selected = texture == id, onClick = { texture = id; if (id == "solid") slot = 0 }, label = { Text(name) })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SlotChip("Color 1", c1, !two || slot == 0) { slot = 0 }
                    if (two) { Spacer(Modifier.width(10.dp)); SlotChip("Color 2", c2, slot == 1) { slot = 1 } }
                }
                Spacer(Modifier.height(10.dp))
                LazyVerticalGrid(GridCells.Fixed(10), Modifier.fillMaxWidth().height(170.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    gridItems(vinylPalette) { col ->
                        Box(Modifier.aspectRatio(1f).clip(CircleShape).background(Color(col))
                            .border(if (col == editing) 3.dp else 1.dp, if (col == editing) cs.onSurface else cs.outline.copy(alpha = .5f), CircleShape)
                            .clickable { if (two && slot == 1) c2 = col else c1 = col }, contentAlignment = Alignment.Center) {
                            if (col == TRANSPARENT_COLOR) Text("T", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ onSave(null) }) { Text("Quitar diseño") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onDismiss) { Text("Cancelar") }
                    TextButton({ onSave(VinylDesign(texture, c1, c2)) }) { Text("Guardar") }
                }
            }
        }
    }
}


// ───────────── partículas, barras animadas y botón de reproducir ─────────────

private class Particle(val ang: Float, val dist: Float, val size: Float, val kind: Int)

private fun DrawScope.drawNote(c: Offset, s: Float, col: Color) {
    drawCircle(col, s * 0.55f, c)
    drawLine(col, Offset(c.x + s * 0.5f, c.y), Offset(c.x + s * 0.5f, c.y - s * 1.9f), strokeWidth = s * 0.22f, cap = StrokeCap.Round)
    drawLine(col, Offset(c.x + s * 0.5f, c.y - s * 1.9f), Offset(c.x + s * 1.2f, c.y - s * 1.2f), strokeWidth = s * 0.22f, cap = StrokeCap.Round)
}

private fun DrawScope.drawSpark(c: Offset, s: Float, col: Color) {
    val p = Path()
    p.moveTo(c.x, c.y - s); p.lineTo(c.x + s * 0.28f, c.y - s * 0.28f)
    p.lineTo(c.x + s, c.y); p.lineTo(c.x + s * 0.28f, c.y + s * 0.28f)
    p.lineTo(c.x, c.y + s); p.lineTo(c.x - s * 0.28f, c.y + s * 0.28f)
    p.lineTo(c.x - s, c.y); p.lineTo(c.x - s * 0.28f, c.y - s * 0.28f)
    p.close()
    drawPath(p, col)
}

/** Notas musicales y chispitas que salen volando y se desvanecen cada vez que cambia el trigger. */
@Composable
private fun ParticleBurst(trigger: Int, style: String, color: Color, modifier: Modifier) {
    if (style == "none") return
    val progress = remember { Animatable(1f) }
    LaunchedEffect(trigger) {
        if (trigger > 0) { progress.snapTo(0f); progress.animateTo(1f, tween(1000, easing = LinearOutSlowInEasing)) }
    }
    val parts = remember(trigger, style) {
        val rnd = Random(trigger * 7919 + 13)
        List(14) { i ->
            val kind = when (style) { "notes" -> 0; "sparks" -> 1; else -> i % 2 }
            Particle(-1.5708f + (rnd.nextFloat() - 0.5f) * 2.6f, 50f + rnd.nextFloat() * 70f, 5f + rnd.nextFloat() * 5f, kind)
        }
    }
    Canvas(modifier) {
        val p = progress.value
        if (p >= 1f) return@Canvas
        val a = 1f - p
        parts.forEach { q ->
            val d = q.dist * p * density
            val x = center.x + cos(q.ang) * d
            val y = center.y + sin(q.ang) * d - 20f * p * density
            val s = q.size * density * (1f - 0.3f * p)
            if (q.kind == 0) drawNote(Offset(x, y), s, color.copy(alpha = a)) else drawSpark(Offset(x, y), s, color.copy(alpha = a))
        }
    }
}

/** Botón de reproducir/pausar: al tocarlo salen las partículas elegidas en Tema. */
@Composable
private fun PlayPauseButton(playing: Boolean, boxSize: Dp, iconSize: Dp, tint: Color, onClick: () -> Unit) {
    val style = LocalParticles.current
    var burst by remember { mutableIntStateOf(0) }
    var primed by remember { mutableStateOf(false) }
    LaunchedEffect(playing) { if (primed) burst++ else primed = true }
    Box(contentAlignment = Alignment.Center) {
        ParticleBurst(burst, style, tint, Modifier.matchParentSize())
        IconButton(onClick, Modifier.size(boxSize)) {
            Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(iconSize), tint = tint)
        }
    }
}

/** Las "rayitas" de la música: suben y bajan mientras suena la canción y se quedan quietas al pausar. */
@Composable
private fun EqBars(playing: Boolean, color: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "eq")
    val hs = List(4) { i ->
        t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(520 + i * 140, easing = LinearEasing), RepeatMode.Reverse), label = "bar$i")
    }
    Canvas(modifier) {
        val n = 4
        val bw = size.width / (n * 2 - 1)
        for (i in 0 until n) {
            val f = if (playing) hs[i].value else 0.3f
            val bh = size.height * f
            drawRoundRect(color, Offset(i * 2 * bw, size.height - bh), Size(bw, bh), CornerRadius(bw / 2))
        }
    }
}
