package com.example.miplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

data class Song(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val durationMs: Long, val albumId: Long)

fun loadSongs(ctx: Context): List<Song> {
    val out = mutableListOf<Song>()
    val cols = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID
    )
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.DATE_ADDED} DESC"
    )?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            out += Song(id, c.getString(1) ?: "Sin título", c.getString(2) ?: "Desconocido", c.getString(3) ?: "",
                ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id), c.getLong(4), c.getLong(5))
        }
    }
    return out
}

private val Context.ds by preferencesDataStore("prefs")
private val THEME = stringPreferencesKey("theme")
private val SEED = intPreferencesKey("seed")
private val CORNER = intPreferencesKey("corner")
private val SORT = stringPreferencesKey("sort")
private val LISTS = stringPreferencesKey("playlists")
private val HIDDEN = stringSetPreferencesKey("hidden")
private val ART = booleanPreferencesKey("arttheme")
private val MIX = booleanPreferencesKey("mix")
private val SILENCE = booleanPreferencesKey("silence")
private val CF_ON = booleanPreferencesKey("cfon")
private val CF_SEC = intPreferencesKey("cfsec")
private val TEXT_SCALE = intPreferencesKey("textscale")
private val LYRICS_SCALE = intPreferencesKey("lyricsscale")
private val SHUFFLE = booleanPreferencesKey("shuffle")

class Prefs(private val ctx: Context) {
    val mode = ctx.ds.data.map { it[THEME] ?: "system" }
    val seed = ctx.ds.data.map { it[SEED] ?: -2 }
    val corner = ctx.ds.data.map { it[CORNER] ?: 50 }
    val sort = ctx.ds.data.map { it[SORT] ?: "new" }
    val artTheme = ctx.ds.data.map { it[ART] ?: true }
    val mix = ctx.ds.data.map { it[MIX] ?: false }
    val silence = ctx.ds.data.map { it[SILENCE] ?: false }
    val crossfadeOn = ctx.ds.data.map { it[CF_ON] ?: false }
    val crossfadeSec = ctx.ds.data.map { it[CF_SEC] ?: 6 }
    val textScale = ctx.ds.data.map { it[TEXT_SCALE] ?: 100 }
    val lyricsScale = ctx.ds.data.map { it[LYRICS_SCALE] ?: 100 }
    val shuffleOn = ctx.ds.data.map { it[SHUFFLE] ?: false }
    val hidden = ctx.ds.data.map { p -> (p[HIDDEN] ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet() }

    suspend fun setMode(m: String) { ctx.ds.edit { it[THEME] = m } }
    suspend fun setSeed(i: Int) { ctx.ds.edit { it[SEED] = i } }
    suspend fun setCorner(i: Int) { ctx.ds.edit { it[CORNER] = i } }
    suspend fun setSort(v: String) { ctx.ds.edit { it[SORT] = v } }
    suspend fun setArt(v: Boolean) { ctx.ds.edit { it[ART] = v } }
    suspend fun setMix(v: Boolean) { ctx.ds.edit { it[MIX] = v } }
    suspend fun setSilence(v: Boolean) { ctx.ds.edit { it[SILENCE] = v } }
    suspend fun setCrossfadeOn(v: Boolean) { ctx.ds.edit { it[CF_ON] = v } }
    suspend fun setCrossfadeSec(v: Int) { ctx.ds.edit { it[CF_SEC] = v } }
    suspend fun setTextScale(v: Int) { ctx.ds.edit { it[TEXT_SCALE] = v } }
    suspend fun setLyricsScale(v: Int) { ctx.ds.edit { it[LYRICS_SCALE] = v } }
    suspend fun setShuffle(v: Boolean) { ctx.ds.edit { it[SHUFFLE] = v } }
    suspend fun hide(id: Long) { ctx.ds.edit { it[HIDDEN] = (it[HIDDEN] ?: emptySet()) + id.toString() } }
    suspend fun unhide(id: Long) { ctx.ds.edit { it[HIDDEN] = (it[HIDDEN] ?: emptySet()) - id.toString() } }

    /** Listas de reproducción: nombre -> ids de canciones (guardadas como JSON). */
    val playlists = ctx.ds.data.map { p ->
        val o = JSONObject(p[LISTS] ?: "{}")
        o.keys().asSequence().associateWith { k -> o.getJSONArray(k).let { a -> List(a.length()) { a.getLong(it) } } }
    }
    suspend fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        ctx.ds.edit { it[LISTS] = o.toString() }
    }
}
