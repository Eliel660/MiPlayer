package com.example.miplayer

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Colores base. Agregar uno nuevo = agregar una línea acá. */
val seeds = listOf(
    Color(0xFF00C46A), Color(0xFFD64FD0), Color(0xFF2196F3),
    Color(0xFFF04E5E), Color(0xFF14B8A6), Color(0xFFEAB308)
)

/** Redondeo de esquinas elegido por la persona (0 = rectas, 100 = lo más redondo). */
val LocalCorner = compositionLocalOf { 50 }
/** Si está activo, la pantalla de reproducción y el mini reproductor toman los colores de la portada. */
val LocalArtTheme = compositionLocalOf { true }
/** Tamaño de la letra de las canciones, en porcentaje. */
val LocalLyricsScale = compositionLocalOf { 100 }
fun cr(pct: Int, maxDp: Int): Dp = (maxDp * pct / 100f).dp

fun schemeFromSeed(seed: Color, dark: Boolean): ColorScheme {
    val hsv = FloatArray(3); android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
    val k = (hsv[1] * 1.6f).coerceIn(0.08f, 1f)
    fun c(s: Float, l: Float) = Color.hsl(hsv[0], (s * k).coerceIn(0f, 1f), l)
    return if (dark) darkColorScheme(
        primary = c(.85f, .72f), onPrimary = c(.6f, .12f),
        primaryContainer = c(.45f, .26f), onPrimaryContainer = c(.9f, .88f),
        secondaryContainer = c(.30f, .20f), onSecondaryContainer = c(.6f, .90f),
        background = c(.25f, .08f), onBackground = c(.2f, .92f),
        surface = c(.25f, .08f), onSurface = c(.2f, .92f),
        surfaceVariant = c(.25f, .16f), onSurfaceVariant = c(.15f, .72f),
        surfaceContainer = c(.25f, .12f), outline = c(.15f, .45f)
    ) else lightColorScheme(
        primary = c(.70f, .40f), onPrimary = Color.White,
        primaryContainer = c(.80f, .88f), onPrimaryContainer = c(.9f, .15f),
        secondaryContainer = c(.40f, .90f), onSecondaryContainer = c(.6f, .15f),
        background = c(.30f, .97f), onBackground = c(.2f, .10f),
        surface = c(.30f, .97f), onSurface = c(.2f, .10f),
        surfaceVariant = c(.35f, .92f), onSurfaceVariant = c(.15f, .35f),
        surfaceContainer = c(.35f, .94f), outline = c(.15f, .55f)
    )
}

/** Tema Naranja: marrón oscuro con naranja vivo. */
fun orangeScheme(dark: Boolean): ColorScheme = if (dark) darkColorScheme(
    primary = Color(0xFFFF7849), onPrimary = Color(0xFF3A1608),
    primaryContainer = Color(0xFF5E3422), onPrimaryContainer = Color(0xFFFFDBCC),
    secondaryContainer = Color(0xFF47211A), onSecondaryContainer = Color(0xFFFFDBCC),
    background = Color(0xFF221713), onBackground = Color(0xFFF1DFD8),
    surface = Color(0xFF221713), onSurface = Color(0xFFF1DFD8),
    surfaceVariant = Color(0xFF47211A), onSurfaceVariant = Color(0xFFD7C1B8),
    surfaceContainer = Color(0xFF2D1C17), outline = Color(0xFF9F8D85)
) else lightColorScheme(
    primary = Color(0xFFC4501B), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDBCC), onPrimaryContainer = Color(0xFF3A1100),
    secondaryContainer = Color(0xFFF7DDD2), onSecondaryContainer = Color(0xFF2B1810),
    background = Color(0xFFFFF8F5), onBackground = Color(0xFF231915),
    surface = Color(0xFFFFF8F5), onSurface = Color(0xFF231915),
    surfaceVariant = Color(0xFFF5DED5), onSurfaceVariant = Color(0xFF53433D),
    surfaceContainer = Color(0xFFFCEAE2), outline = Color(0xFF85736C)
)

/** Tema Halloween: negro puro, naranja fuerte y marrón. Solo existe en oscuro. */
fun halloweenScheme(): ColorScheme = darkColorScheme(
    primary = Color(0xFFFF8800), onPrimary = Color(0xFF3B1D00),
    primaryContainer = Color(0xFF4A2600), onPrimaryContainer = Color(0xFFFFDDB8),
    secondaryContainer = Color(0xFF5C3000), onSecondaryContainer = Color(0xFFFFDDB8),
    background = Color.Black, onBackground = Color(0xFFFFE9D6),
    surface = Color.Black, onSurface = Color(0xFFFFE9D6),
    surfaceVariant = Color(0xFF5C3000), onSurfaceVariant = Color(0xFFFFC48A),
    surfaceContainer = Color(0xFF140A00), outline = Color(0xFFB0753A)
)

/** Monocromo: negro, blanco y grises. Tiene versión oscura y clara. */
fun monoScheme(dark: Boolean): ColorScheme = if (dark) darkColorScheme(
    primary = Color(0xFFFDFDFD), onPrimary = Color(0xFF101114),
    primaryContainer = Color(0xFF26272B), onPrimaryContainer = Color(0xFFF1F1F3),
    secondaryContainer = Color(0xFF1C1D21), onSecondaryContainer = Color(0xFFF1F1F3),
    background = Color(0xFF0A0A0B), onBackground = Color(0xFFF1F1F3),
    surface = Color(0xFF0A0A0B), onSurface = Color(0xFFF1F1F3),
    surfaceVariant = Color(0xFF1E1F23), onSurfaceVariant = Color(0xFFC4C5CA),
    surfaceContainer = Color(0xFF151618), outline = Color(0xFF8A8B90)
) else lightColorScheme(
    primary = Color(0xFF000000), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE6E7E8), onPrimaryContainer = Color(0xFF111213),
    secondaryContainer = Color(0xFFE6E7E8), onSecondaryContainer = Color(0xFF111213),
    background = Color(0xFFFDFDFD), onBackground = Color(0xFF111213),
    surface = Color(0xFFFDFDFD), onSurface = Color(0xFF111213),
    surfaceVariant = Color(0xFFE6E7E8), onSurfaceVariant = Color(0xFF47484B),
    surfaceContainer = Color(0xFFF1F2F3), outline = Color(0xFF767779)
)

/** Chocolate: marrón profundo con tonos café con leche. Solo oscuro. */
fun chocolateScheme(): ColorScheme = darkColorScheme(
    primary = Color(0xFF9F7753), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF5A3A20), onPrimaryContainer = Color(0xFFFFE7D6),
    secondaryContainer = Color(0xFF6E4C2D), onSecondaryContainer = Color(0xFFFFE7D6),
    background = Color(0xFF45260F), onBackground = Color(0xFFFFE7D6),
    surface = Color(0xFF45260F), onSurface = Color(0xFFFFE7D6),
    surfaceVariant = Color(0xFF5A3A20), onSurfaceVariant = Color(0xFFE6CBB5),
    surfaceContainer = Color(0xFF4F2E15), outline = Color(0xFFB08F72)
)

/** Pastel de cumpleaños: rosa pastel sobre un malva suave. Solo existe en esta versión. */
fun pastelScheme(): ColorScheme = lightColorScheme(
    primary = Color(0xFFFFDDF1), onPrimary = Color(0xFF1A0A14),
    primaryContainer = Color(0xFFE6A6CC), onPrimaryContainer = Color(0xFF2B0F20),
    secondaryContainer = Color(0xFFF2B6DB), onSecondaryContainer = Color(0xFF3B1A2E),
    background = Color(0xFFB982A0), onBackground = Color(0xFFFFE9DC),
    surface = Color(0xFFB982A0), onSurface = Color(0xFFFFE9DC),
    surfaceVariant = Color(0xFFA56F8C), onSurfaceVariant = Color(0xFFFFE0EE),
    surfaceContainer = Color(0xFFC58FAD), outline = Color(0xFFF4C5E0)
)

/** Rojo en modo oscuro, corregido. */
fun redDarkScheme(): ColorScheme = darkColorScheme(
    primary = Color(0xFFF45060), onPrimary = Color(0xFF3E0B14),
    primaryContainer = Color(0xFF6B1F2A), onPrimaryContainer = Color(0xFFFFD9DD),
    secondaryContainer = Color(0xFF4A151D), onSecondaryContainer = Color(0xFFFFD9DD),
    background = Color(0xFF2A181B), onBackground = Color(0xFFF2E0E2),
    surface = Color(0xFF2A181B), onSurface = Color(0xFFF2E0E2),
    surfaceVariant = Color(0xFF4A151D), onSurfaceVariant = Color(0xFFD9BFC3),
    surfaceContainer = Color(0xFF331C20), outline = Color(0xFFA08589)
)

/**
 * seedIdx: -6 = Pastel de cumpleaños, -5 = Chocolate, -4 = Monocromo, -3 = Halloween, -2 = Naranja,
 * -1 = colores dinámicos del sistema (Android 12+), 0.. = colores base (3 = rojo).
 */
@Composable
fun MiPlayerTheme(mode: String, seedIdx: Int, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (seedIdx) {
        -3, -5 -> true
        -6 -> false
        else -> when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    }
    val cs = when {
        seedIdx == -6 -> pastelScheme()
        seedIdx == -5 -> chocolateScheme()
        seedIdx == -4 -> monoScheme(dark)
        seedIdx == -3 -> halloweenScheme()
        seedIdx == -1 && Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        seedIdx < 0 -> orangeScheme(dark)
        seedIdx == 3 && dark -> redDarkScheme()
        else -> schemeFromSeed(seeds[seedIdx.coerceIn(0, seeds.lastIndex)], dark)
    }
    MaterialTheme(colorScheme = cs, content = content)
}
