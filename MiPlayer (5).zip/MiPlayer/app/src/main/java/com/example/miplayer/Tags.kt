package com.example.miplayer

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.File

/** Cambios que la persona quiere hacerle a una canción. */
class TagEdit(val song: Song, val title: String, val artist: String, val album: String, val cover: ByteArray?)

fun isMp3(ctx: Context, uri: Uri): Boolean {
    if (ctx.contentResolver.getType(uri) == "audio/mpeg") return true
    return runCatching {
        ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            c.moveToFirst() && (c.getString(0) ?: "").lowercase().endsWith(".mp3")
        } ?: false
    }.getOrDefault(false)
}

/** Achica la imagen elegida y la deja en JPEG, lista para guardar dentro del archivo. */
fun scaleCover(ctx: Context, uri: Uri): ByteArray? = runCatching {
    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    var sample = 1
    while (opts.outWidth / sample > 1600 || opts.outHeight / sample > 1600) sample *= 2
    val bmp = ctx.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
    } ?: return@runCatching null
    val out = ByteArrayOutputStream()
    bmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
    out.toByteArray()
}.getOrNull()

fun updateMediaStore(ctx: Context, uri: Uri, title: String, artist: String, album: String) {
    runCatching {
        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.TITLE, title)
            put(MediaStore.Audio.Media.ARTIST, artist)
            put(MediaStore.Audio.Media.ALBUM, album)
        }
        ctx.contentResolver.update(uri, cv, null, null)
    }
}

private fun be32Bytes(n: Int) = byteArrayOf((n ushr 24).toByte(), (n ushr 16).toByte(), (n ushr 8).toByte(), n.toByte())
private fun synchBytes(n: Int) = byteArrayOf(((n shr 21) and 0x7F).toByte(), ((n shr 14) and 0x7F).toByte(), ((n shr 7) and 0x7F).toByte(), (n and 0x7F).toByte())

private fun frame(id: String, data: ByteArray): ByteArray {
    val o = ByteArrayOutputStream()
    o.write(id.toByteArray(Charsets.ISO_8859_1)); o.write(be32Bytes(data.size)); o.write(0); o.write(0); o.write(data)
    return o.toByteArray()
}

private fun textFrame(id: String, text: String): ByteArray {
    val d = ByteArrayOutputStream()
    d.write(1); d.write(text.toByteArray(Charsets.UTF_16))   // UTF-16 con marca de orden
    return frame(id, d.toByteArray())
}

private fun apicFrame(img: ByteArray): ByteArray {
    val d = ByteArrayOutputStream()
    d.write(0); d.write("image/jpeg".toByteArray(Charsets.ISO_8859_1)); d.write(0); d.write(3); d.write(0); d.write(img)
    return frame("APIC", d.toByteArray())
}

/**
 * Reescribe la etiqueta ID3 de un MP3 con nombre, artista, álbum y (si hay) portada nueva,
 * conservando el resto de los datos de la etiqueta y el audio tal cual. Bloqueante.
 */
fun writeMp3Tags(ctx: Context, uri: Uri, title: String, artist: String, album: String, cover: ByteArray?): Boolean = runCatching {
    val tmpAudio = File(ctx.cacheDir, "audio_body.tmp")
    val tmpOut = File(ctx.cacheDir, "audio_new.tmp")
    val kept = ByteArrayOutputStream()
    ctx.contentResolver.openInputStream(uri)!!.use { raw ->
        val din = DataInputStream(raw.buffered())
        val h = ByteArray(10); din.readFully(h)
        val hasTag = String(h, 0, 3, Charsets.ISO_8859_1) == "ID3" && h[3].toInt() >= 3
        tmpAudio.outputStream().buffered().use { audio ->
            if (hasTag) {
                val ver = h[3].toInt()
                val size = synch(h, 6)
                require(size <= 12_000_000)
                val tag = ByteArray(size); din.readFully(tag)
                val unsyncTag = (h[5].toInt() and 0x80) != 0
                var p = 0
                if ((h[5].toInt() and 0x40) != 0 && tag.size >= 4) p = if (ver == 4) synch(tag, 0) else be32(tag, 0) + 4
                while (!unsyncTag && p + 10 <= tag.size) {
                    if (tag[p].toInt() == 0) break
                    val id = String(tag, p, 4, Charsets.ISO_8859_1)
                    val fs = if (ver == 4) synch(tag, p + 4) else be32(tag, p + 4)
                    if (fs < 0 || p + 10 + fs > tag.size) break
                    val f2 = tag[p + 9].toInt()
                    val bad = if (ver == 4) (f2 and 0x0F) != 0 else (f2 and 0xC0) != 0
                    val replaced = id == "TIT2" || id == "TPE1" || id == "TALB" || (id == "APIC" && cover != null)
                    if (!bad && !replaced) kept.write(frame(id, tag.copyOfRange(p + 10, p + 10 + fs)))
                    p += 10 + fs
                }
            } else audio.write(h)
            din.copyTo(audio)
        }
    }
    val frames = ByteArrayOutputStream()
    frames.write(textFrame("TIT2", title)); frames.write(textFrame("TPE1", artist)); frames.write(textFrame("TALB", album))
    if (cover != null) frames.write(apicFrame(cover))
    frames.write(kept.toByteArray())
    val body = frames.toByteArray()
    tmpOut.outputStream().buffered().use { o ->
        o.write(byteArrayOf('I'.code.toByte(), 'D'.code.toByte(), '3'.code.toByte(), 3, 0, 0))
        o.write(synchBytes(body.size)); o.write(body)
        tmpAudio.inputStream().use { it.copyTo(o) }
    }
    require(tmpOut.length() > body.size)
    ctx.contentResolver.openOutputStream(uri, "wt")!!.use { out -> tmpOut.inputStream().use { it.copyTo(out) } }
    tmpAudio.delete(); tmpOut.delete()
    true
}.getOrDefault(false)
