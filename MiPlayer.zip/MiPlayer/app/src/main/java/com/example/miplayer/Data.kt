package com.example.miplayer

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uri: Uri,
    val albumArtUri: Uri?,
    var lyrics: String = "Letra no disponible",
    var isHidden: Boolean = false,
    var annotation: String = ""
)
