package com.example.miplayer

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocalContextHolder.ctx = applicationContext
        startService(Intent(this, PlaybackService::class.java))
        setContent {
            val prefs = remember { Prefs(this) }
            val theme by prefs.theme.collectAsState("Medianoche")
            MiPlayerTheme(theme) { Root(prefs, theme) }
        }
    }
}

private class PState(val playing: Boolean, val title: String, val artist: String, val shuffle: Boolean, val repeat: Int)

@Composable
private fun rememberPState(p: Player): State<PState> {
    fun snap() = PState(p.isPlaying, p.mediaMetadata.title?.toString() ?: "", p.mediaMetadata.artist?.toString() ?: "",
        p.shuffleModeEnabled, p.repeatMode)
    val st = remember { mutableStateOf(snap()) }
    DisposableEffect(p) {
        val l = object : Player.Listener { override fun onEvents(pl: Player, e: Player.Events) { st.value = snap() } }
        p.addListener(l); onDispose { p.removeListener(l) }
    }
    return st
}

private fun playList(p: Player, list: List<Song>, start: Int) {
    p.setMediaItems(list.map {
        MediaItem.Builder().setMediaId(it.id.toString()).setUri(it.uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).setArtist(it.artist).setAlbumTitle(it.album).build()).build()
    }, start, 0)
    p.prepare(); p.play()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Root(prefs: Prefs, currentTheme: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { PlayerHolder.get(ctx) }
    val ps by rememberPState(player)
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var showNow by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val lists by prefs.playlists.collectAsState(emptyMap())

    val perms = buildList {
        add(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r[perms[0]] == true; if (granted) songs = loadSongs(ctx)
    }
    LaunchedEffect(Unit) { launcher.launch(perms) }

    if (showNow) { NowPlaying(player, ps, songs, lists, prefs) { showNow = false }; return }

    Scaffold(
        bottomBar = {
            Column {
                if (ps.title.isNotEmpty()) ListItem(
                    headlineContent = { Text(ps.title, maxLines = 1) }, supportingContent = { Text(ps.artist, maxLines = 1) },
                    trailingContent = {
                        IconButton({ if (ps.playing) player.pause() else player.play() }) {
                            Icon(if (ps.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                        }
                    }, modifier = Modifier.clickable { showNow = true })
                NavigationBar {
                    listOf("Canciones" to Icons.Default.MusicNote, "Listas" to Icons.Default.QueueMusic, "Temas" to Icons.Default.Palette)
                        .forEachIndexed { i, (n, ic) ->
                            NavigationBarItem(tab == i, { tab = i }, { Icon(ic, n) }, label = { Text(n) })
                        }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> Column {
                    OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(12.dp),
                        placeholder = { Text("Buscar") }, singleLine = true)
                    val shown = songs.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
                    if (!granted) Text("Falta el permiso de audio.", Modifier.padding(16.dp))
                    LazyColumn {
                        items(shown, key = { it.id }) { s ->
                            ListItem(headlineContent = { Text(s.title, maxLines = 1) }, supportingContent = { Text(s.artist, maxLines = 1) },
                                modifier = Modifier.clickable { playList(player, shown, shown.indexOf(s)); showNow = true })
                        }
                    }
                }
                1 -> PlaylistsTab(songs, lists, prefs) { list -> playList(player, list, 0) }
                else -> LazyColumn {
                    items(listOf(DYNAMIC) + themes.map { it.name }) { n ->
                        ListItem(headlineContent = { Text(n) },
                            leadingContent = { RadioButton(currentTheme == n, { scope.launch { prefs.setTheme(n) } }) },
                            modifier = Modifier.clickable { scope.launch { prefs.setTheme(n) } })
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistsTab(songs: List<Song>, lists: Map<String, List<Long>>, prefs: Prefs, onPlay: (List<Song>) -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    Column(Modifier.padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(name, { name = it }, Modifier.weight(1f), placeholder = { Text("Nueva lista") }, singleLine = true)
            IconButton({ if (name.isNotBlank()) { scope.launch { prefs.savePlaylists(lists + (name to emptyList())) }; name = "" } }) {
                Icon(Icons.Default.Add, "Crear")
            }
        }
        LazyColumn {
            items(lists.keys.toList()) { n ->
                ListItem(headlineContent = { Text(n) }, supportingContent = { Text("${lists[n]!!.size} canciones") },
                    trailingContent = { IconButton({ scope.launch { prefs.savePlaylists(lists - n) } }) { Icon(Icons.Default.Delete, "Borrar") } },
                    modifier = Modifier.clickable { onPlay(songs.filter { it.id in lists[n]!! }) })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NowPlaying(player: Player, ps: PState, songs: List<Song>, lists: Map<String, List<Long>>, prefs: Prefs, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var pos by remember { mutableLongStateOf(0L) }
    var sleepMin by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { pos = player.currentPosition; delay(500) } }
    LaunchedEffect(sleepMin) { if (sleepMin > 0) { delay(sleepMin * 60_000L); player.pause(); sleepMin = 0 } }

    Column(Modifier.fillMaxSize().padding(24.dp).systemBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth()) { IconButton(onBack) { Icon(Icons.Default.KeyboardArrowDown, "Volver") } }
        Spacer(Modifier.weight(1f))
        Text(ps.title, style = MaterialTheme.typography.headlineSmall, maxLines = 2)
        Text(ps.artist, style = MaterialTheme.typography.bodyLarge)
        val dur = player.duration.coerceAtLeast(1)
        Slider(pos.toFloat(), { player.seekTo(it.toLong()) }, valueRange = 0f..dur.toFloat())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ player.shuffleModeEnabled = !ps.shuffle }) {
                Icon(Icons.Default.Shuffle, "Mezclar", tint = if (ps.shuffle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            }
            IconButton({ player.seekToPrevious() }) { Icon(Icons.Default.SkipPrevious, "Anterior") }
            FilledIconButton({ if (ps.playing) player.pause() else player.play() }, Modifier.size(64.dp)) {
                Icon(if (ps.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
            }
            IconButton({ player.seekToNext() }) { Icon(Icons.Default.SkipNext, "Siguiente") }
            IconButton({ player.repeatMode = when (ps.repeat) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF } }) {
                Icon(if (ps.repeat == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat, "Repetir",
                    tint = if (ps.repeat != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton({ dialog = "eq" }) { Text("Ecualizador") }
            TextButton({ dialog = "sleep" }) { Text(if (sleepMin > 0) "Apagado: ${sleepMin} min" else "Temporizador") }
            TextButton({ dialog = "list" }) { Text("A lista") }
        }
        Spacer(Modifier.weight(1f))
    }

    when (dialog) {
        "eq" -> {
            val eq = remember { PlayerHolder.equalizer(LocalContextHolder.ctx) }
            AlertDialog({ dialog = "" }, confirmButton = { TextButton({ dialog = "" }) { Text("Listo") } }, title = { Text("Ecualizador") }, text = {
                Column {
                    val range = eq.bandLevelRange
                    for (b in 0 until eq.numberOfBands) {
                        var lvl by remember { mutableFloatStateOf(eq.getBandLevel(b.toShort()).toFloat()) }
                        Text("${eq.getCenterFreq(b.toShort()) / 1000} Hz")
                        Slider(lvl, { lvl = it; eq.setBandLevel(b.toShort(), it.toInt().toShort()) },
                            valueRange = range[0].toFloat()..range[1].toFloat())
                    }
                }
            })
        }
        "sleep" -> AlertDialog({ dialog = "" }, confirmButton = {}, title = { Text("Apagar en…") }, text = {
            Column { listOf(0, 15, 30, 45, 60).forEach { m ->
                TextButton({ sleepMin = m; dialog = "" }) { Text(if (m == 0) "Desactivado" else "$m minutos") } } }
        })
        "list" -> AlertDialog({ dialog = "" }, confirmButton = {}, title = { Text("Agregar a lista") }, text = {
            Column {
                if (lists.isEmpty()) Text("Creá una lista primero en la pestaña Listas.")
                lists.keys.forEach { n ->
                    TextButton({
                        val id = player.currentMediaItem?.mediaId?.toLongOrNull()
                        if (id != null) scope.launch { prefs.savePlaylists(lists + (n to (lists[n]!! + id).distinct())) }
                        dialog = ""
                    }) { Text(n) }
                }
            }
        })
    }
}

/** Evita pasar el contexto por todos lados en el diálogo del ecualizador. */
object LocalContextHolder { lateinit var ctx: android.content.Context }
