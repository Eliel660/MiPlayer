package com.example.miplayer

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configuración de callbacks del reproductor
        PlaybackManager.onSongChanged = { song ->
            // Actualizar interfaz con la nueva canción
        }

        PlaybackManager.onThemeColorExtracted = { color ->
            // Aplicar tema dinámico según la portada a la interfaz, minireproductor y barra
            AppTheme.primaryColor = color
            window.statusBarColor = color
        }
    }

    // Menú contextual simplificado de 3 puntos
    fun showSongOptionsMenu(song: Song) {
        val options = arrayOf("Eliminar canción", "Ocultar", "Crear una anotación")
        AlertDialog.Builder(this)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> deleteSong(song)
                    1 -> hideSong(song)
                    2 -> createAnnotation(song)
                }
            }
            .show()
    }

    private fun deleteSong(song: Song) {
        PlaybackManager.queue.remove(song)
        Toast.makeText(this, "Canción eliminada de la lista", Toast.LENGTH_SHORT).show()
    }

    private fun hideSong(song: Song) {
        song.isHidden = true
        PlaybackManager.queue.remove(song)
        Toast.makeText(this, "Canción ocultada", Toast.LENGTH_SHORT).show()
    }

    private fun createAnnotation(song: Song) {
        // Cuadro de diálogo para agregar nota
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Crear anotación")
        val input = android.widget.EditText(this)
        input.setText(song.annotation)
        builder.setView(input)
        builder.setPositiveButton("Guardar") { _, _ ->
            song.annotation = input.text.toString()
            Toast.makeText(this, "Anotación guardada", Toast.LENGTH_SHORT).show()
        }
        builder.setNegativeButton("Cancelar", null)
        builder.show()
    }
}
