package com.example.miplayer

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

class AppTheme(val name: String, val dark: Boolean, val primary: Color, val bg: Color, val surface: Color)

/** Agregar un tema nuevo = agregar una línea acá. */
val themes = listOf(
    AppTheme("Medianoche", true, Color(0xFFBB86FC), Color(0xFF0E0E14), Color(0xFF1B1B26)),
    AppTheme("Océano", true, Color(0xFF4FC3F7), Color(0xFF0A1822), Color(0xFF12293A)),
    AppTheme("Bosque", true, Color(0xFF81C784), Color(0xFF0C1A12), Color(0xFF173024)),
    AppTheme("Atardecer", true, Color(0xFFFF8A65), Color(0xFF1C1210), Color(0xFF2F1E1A)),
    AppTheme("Rosa", false, Color(0xFFD81B60), Color(0xFFFFF5F8), Color(0xFFFFE0EA)),
    AppTheme("Claro", false, Color(0xFF3F51B5), Color(0xFFFAFAFF), Color(0xFFE8EAF6)),
)
const val DYNAMIC = "Dinámico (Material You)"

@Composable
fun MiPlayerTheme(name: String, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = if (name == DYNAMIC && Build.VERSION.SDK_INT >= 31) {
        if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        val t = themes.firstOrNull { it.name == name } ?: themes[0]
        val base = if (t.dark) darkColorScheme() else lightColorScheme()
        base.copy(primary = t.primary, background = t.bg, surface = t.surface,
            surfaceVariant = t.surface, secondaryContainer = t.surface)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
