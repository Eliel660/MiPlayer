package com.example.miplayer

import android.graphics.Color

object AppTheme {
    var primaryColor: Int = Color.parseColor("#3D2314") // Marrón anaranjado cálido base
    var accentColor: Int = Color.parseColor("#E87A49")
}
