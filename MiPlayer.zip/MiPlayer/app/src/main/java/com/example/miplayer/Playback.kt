package com.example.miplayer

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaPlayer
import androidx.palette.graphics.Palette
import java.util.Collections

object PlaybackManager {
    var queue: MutableList<Song> = mutableListOf()
    var currentIndex: Int = -1
    var isShuffle: Boolean = false
    var isRepeat: Boolean = false
    var crossfadeDuration: Int = 0 // en segundos

    private var mediaPlayer: MediaPlayer? = null
    var onSongChanged: ((Song) -> Unit)? = null
    var onThemeColorExtracted: ((Int) -> Unit)? = null

    fun playSong(song: Song) {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(song.uri.toString())
            prepare()
            start()
        }
        onSongChanged?.invoke(song)
    }

    fun shuffleQueue() {
        if (queue.isNotEmpty()) {
            val current = if (currentIndex in queue.indices) queue[currentIndex] else null
            queue.shuffle()
            if (current != null) {
                currentIndex = queue.indexOf(current)
            } else {
                currentIndex = 0
            }
        }
    }

    fun moveQueueItem(fromPosition: Int, toPosition: Int) {
        if (fromPosition in queue.indices && toPosition in queue.indices) {
            Collections.swap(queue, fromPosition, toPosition)
        }
    }

    fun playNext(song: Song) {
        if (currentIndex in queue.indices) {
            queue.add(currentIndex + 1, song)
        } else {
            queue.add(song)
        }
    }

    fun extractColorFromBitmap(bitmap: Bitmap) {
        Palette.from(bitmap).generate { palette ->
            val dominantColor = palette?.getDominantColor(0xFF3D2314.toInt()) ?: 0xFF3D2314.toInt()
            onThemeColorExtracted?.invoke(dominantColor)
        }
    }
}
