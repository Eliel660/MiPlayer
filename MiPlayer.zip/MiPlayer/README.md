# MiPlayer - Actualización

### Cambios aplicados:
- **UI Suave:** Bordes redondeados en contenedores y carátulas (estilo referencia).
- **Tema Dinámico por Portada:** El reproductor, minireproductor y notificación adaptan su paleta al color dominante de la portada.
- **Tema Base:** Marrón anaranjado cálido.
- **Menú de 3 Puntos:** Reducido a únicamente *Eliminar canción*, *Ocultar*, y *Crear una anotación*.
- **Gestión de Fila:** 
  - Botón aleatorio funcional que rehace la lista de verdad.
  - Reordenamiento manual táctil de canciones.
  - Opción *Reproducir a continuación* en biblioteca y buscador.
- **Letras:** Panel de visualización de letras con desplazamiento manual.
- **Ajustes:** Soporte para Crossfade.
