package com.example.miplayer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.widget.RemoteViews
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.media3.common.Player
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

private class WState(
    val id: String, val title: String, val artist: String, val playing: Boolean,
    val shuffle: Boolean, val uri: Uri?, val albumId: Long
)

/** Pinta el fondo redondeado del widget con el color de la portada (como el mini reproductor de la app). */
private fun roundedBg(w: Int, h: Int, color: Int, r: Float): Bitmap {
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = color
    Canvas(b).drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, p)
    return b
}

/** Portada cuadrada con esquinas redondeadas. */
private fun roundedCover(src: Bitmap, size: Int, r: Float): Bitmap {
    val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val side = minOf(src.width, src.height)
    val from = Rect((src.width - side) / 2, (src.height - side) / 2, (src.width + side) / 2, (src.height + side) / 2)
    c.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, p)
    p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
    c.drawBitmap(src, from, Rect(0, 0, size, size), p)
    return out
}

/** Disco con la portada de etiqueta y la varilla: apoyada sobre el disco si suena, levantada si está en pausa. */
private fun vinylBitmap(size: Int, label: Bitmap?, playing: Boolean): Bitmap {
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val s = size.toFloat()
    val cx = 0.46f * s
    val cy = 0.54f * s
    val r = 0.44f * s
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = 0xFF141414.toInt()
    c.drawCircle(cx, cy, r, p)
    p.style = Paint.Style.STROKE
    for (i in 0..13) {
        p.strokeWidth = 1.5f
        p.color = android.graphics.Color.argb(if (i % 3 == 0) 18 else 9, 255, 255, 255)
        c.drawCircle(cx, cy, r * (0.46f + i * 0.037f), p)
    }
    p.strokeWidth = r * 0.012f
    p.color = android.graphics.Color.argb(26, 255, 255, 255)
    c.drawCircle(cx, cy, r * 0.985f, p)
    p.style = Paint.Style.FILL
    p.color = android.graphics.Color.argb(30, 255, 255, 255)
    c.drawCircle(cx, cy, r * 0.43f, p)
    val lr = r * 0.40f
    if (label != null) {
        val side = minOf(label.width, label.height)
        val from = Rect((label.width - side) / 2, (label.height - side) / 2, (label.width + side) / 2, (label.height + side) / 2)
        val clip = Path()
        clip.addCircle(cx, cy, lr, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawBitmap(label, from, RectF(cx - lr, cy - lr, cx + lr, cy + lr), p)
        c.restore()
    } else {
        p.color = 0xFFC8553D.toInt()
        c.drawCircle(cx, cy, lr, p)
    }
    // varilla
    c.save()
    c.rotate(if (playing) 2f else -20f, 0.86f * s, 0.02f * s)
    val arm = Paint(Paint.ANTI_ALIAS_FLAG)
    arm.color = android.graphics.Color.WHITE
    arm.style = Paint.Style.STROKE
    arm.strokeWidth = 0.022f * s
    arm.strokeCap = Paint.Cap.ROUND
    val path = Path()
    path.moveTo(0.86f * s, 0f)
    path.cubicTo(0.90f * s, 0.18f * s, 0.84f * s, 0.34f * s, 0.74f * s, 0.50f * s)
    c.drawPath(path, arm)
    arm.style = Paint.Style.FILL
    c.save()
    c.rotate(20f, 0.74f * s, 0.50f * s)
    c.drawRoundRect(RectF(0.715f * s, 0.49f * s, 0.775f * s, 0.58f * s), 0.025f * s, 0.025f * s, arm)
    c.restore()
    c.restore()
    return bmp
}

/** Mantiene al día los widgets de la pantalla principal: el mini (como el de la app) y el del vinilo. */
object WidgetUpdater {
    private val exec = Executors.newSingleThreadExecutor()
    private var last = ""

    /** Se llama desde el hilo principal: lee el estado del reproductor y arma los widgets en segundo plano. */
    fun request(ctx: Context, p: Player, force: Boolean = false) {
        val item = p.currentMediaItem
        val st = WState(
            item?.mediaId ?: "", item?.mediaMetadata?.title?.toString() ?: "", item?.mediaMetadata?.artist?.toString() ?: "",
            p.isPlaying, PlayerHolder.shuffleMode, item?.localConfiguration?.uri,
            item?.mediaMetadata?.artworkUri?.lastPathSegment?.toLongOrNull() ?: 0L
        )
        val key = "${st.id}|${st.title}|${st.artist}|${st.playing}|${st.shuffle}"
        if (!force && key == last) return
        last = key
        val app = ctx.applicationContext
        exec.execute { runCatching { push(app, st) } }
    }

    private fun push(ctx: Context, st: WState) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val miniIds = mgr.getAppWidgetIds(ComponentName(ctx, PlayerWidgetMini::class.java))
        val bigIds = mgr.getAppWidgetIds(ComponentName(ctx, PlayerWidget::class.java))
        if (miniIds.isEmpty() && bigIds.isEmpty()) return
        val cover = st.uri?.let { loadArtBitmap(ctx, it, st.albumId, 256) }
        val seed = if (st.uri != null) ArtColors.compute(ctx, st.id, st.uri, st.albumId) else null
        val dark = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val cs = if (seed != null) schemeFromSeed(Color(seed), dark) else orangeScheme(dark)
        val container = cs.primaryContainer.toArgb()
        val text = cs.onPrimaryContainer.toArgb()
        val soft = (text and 0x00FFFFFF) or (0xB3 shl 24)
        val dim = (text and 0x00FFFFFF) or (0x99 shl 24)
        val accent = (if (dark) cs.primary else cs.onPrimaryContainer).toArgb()
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val playIcon = if (st.playing) R.drawable.ic_w_pause else R.drawable.ic_w_play
        val title = st.title.ifBlank { "M!Perla" }

        if (miniIds.isNotEmpty()) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_mini)
            v.setImageViewBitmap(R.id.w_bg, roundedBg(700, 180, container, 50f))
            if (cover != null) v.setImageViewBitmap(R.id.w_cover, roundedCover(cover, 160, 36f)) else v.setImageViewResource(R.id.w_cover, R.drawable.ic_stat)
            v.setTextViewText(R.id.w_title, title); v.setTextColor(R.id.w_title, text)
            v.setTextViewText(R.id.w_artist, st.artist); v.setTextColor(R.id.w_artist, soft)
            v.setImageViewResource(R.id.w_play, playIcon)
            v.setInt(R.id.w_play, "setColorFilter", accent)
            v.setInt(R.id.w_shuffle, "setColorFilter", if (st.shuffle) accent else dim)
            v.setOnClickPendingIntent(R.id.w_play, action(ctx, "TOGGLE"))
            v.setOnClickPendingIntent(R.id.w_shuffle, action(ctx, "SHUFFLE"))
            v.setOnClickPendingIntent(R.id.w_root, open)
            mgr.updateAppWidget(miniIds, v)
        }
        if (bigIds.isNotEmpty()) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_player)
            v.setImageViewBitmap(R.id.w_bg, roundedBg(700, 300, container, 56f))
            v.setImageViewBitmap(R.id.w_vinyl, vinylBitmap(360, cover, st.playing))
            v.setTextViewText(R.id.w_title, title); v.setTextColor(R.id.w_title, text)
            v.setTextViewText(R.id.w_artist, st.artist); v.setTextColor(R.id.w_artist, soft)
            v.setImageViewResource(R.id.w_play, playIcon)
            v.setInt(R.id.w_play, "setColorFilter", accent)
            v.setInt(R.id.w_prev, "setColorFilter", text)
            v.setInt(R.id.w_next, "setColorFilter", text)
            v.setOnClickPendingIntent(R.id.w_prev, action(ctx, "PREV"))
            v.setOnClickPendingIntent(R.id.w_play, action(ctx, "TOGGLE"))
            v.setOnClickPendingIntent(R.id.w_next, action(ctx, "NEXT"))
            v.setOnClickPendingIntent(R.id.w_root, open)
            mgr.updateAppWidget(bigIds, v)
        }
    }

    private fun action(ctx: Context, act: String): PendingIntent = PendingIntent.getBroadcast(
        ctx, act.hashCode(), Intent(ctx, WidgetActionReceiver::class.java).setAction(act),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

class PlayerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.request(context, PlayerHolder.get(context), true)
    }
}

class PlayerWidgetMini : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.request(context, PlayerHolder.get(context), true)
    }
}

/** Botones de los widgets: anterior, reproducir/pausar, siguiente y aleatorio. */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = PlayerHolder.get(context)
        when (intent.action) {
            "PREV" -> p.seekToPrevious()
            "NEXT" -> p.seekToNext()
            "TOGGLE" -> if (p.mediaItemCount > 0) { if (p.isPlaying) p.pause() else p.play() }
            "SHUFFLE" -> {
                val on = !PlayerHolder.shuffleMode
                PlayerHolder.shuffleMode = on
                if (on) shuffleRest(p)
                val pending = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try { Prefs(context.applicationContext).setShuffle(on) } finally { pending.finish() }
                }
                WidgetUpdater.request(context, p, true)
            }
        }
    }
}
