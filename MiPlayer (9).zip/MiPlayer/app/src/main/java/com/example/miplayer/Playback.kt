@file:OptIn(UnstableApi::class)
package com.example.miplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.PlaybackParameters
import kotlin.math.abs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import android.content.Context
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.collect.ImmutableList
import java.util.concurrent.Executors

/** Mezcla al azar todo lo que viene después de la canción que suena, sin cortarla. */
fun shuffleRest(p: Player) {
    val n = p.mediaItemCount
    if (n < 2) return
    val cur = p.currentMediaItemIndex
    val others = (0 until n).filter { it != cur }.map { p.getMediaItemAt(it) }.shuffled()
    p.removeMediaItems(cur + 1, n)
    p.removeMediaItems(0, cur)
    p.addMediaItems(others)
}

/** Deja la fila en el orden de la biblioteca, sin cortar la canción que suena. */
fun orderQueue(p: Player, order: List<Song>) {
    val n = p.mediaItemCount
    if (n < 2) return
    val rank = HashMap<String, Int>()
    order.forEachIndexed { i, s -> rank[s.id.toString()] = i }
    val cur = p.currentMediaItemIndex
    val curId = p.getMediaItemAt(cur).mediaId
    val items = (0 until n).map { p.getMediaItemAt(it) }.sortedBy { rank[it.mediaId] ?: Int.MAX_VALUE }
    val ci = items.indexOfFirst { it.mediaId == curId }
    if (ci < 0) return
    p.removeMediaItems(cur + 1, n)
    p.removeMediaItems(0, cur)
    p.addMediaItems(0, items.subList(0, ci).toList())
    p.addMediaItems(items.subList(ci + 1, items.size).toList())
}

/** Un solo reproductor compartido por la UI, la notificación y el ecualizador. También hace el crossfade. */
object PlayerHolder {
    private var player: ExoPlayer? = null
    private var eq: Equalizer? = null
    private lateinit var app: Context
    private val handler = Handler(Looper.getMainLooper())
    private val attrs = AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()
    private var mixOn = false
    private var silenceOn = false
    private var lastIdx = -1

    /** Segundos de crossfade (0 = apagado). */
    @Volatile var crossfadeSec = 0
    /** Si está en aleatorio, cada vuelta de la fila se vuelve a mezclar. */
    @Volatile var shuffleMode = false

    // Crossfade en fases: 0 libre · 1 segundo reproductor preparado · 2 en silencio, alineándose · 3 mezclando
    private var tail: ExoPlayer? = null
    private var tailEq: Equalizer? = null
    private var phase = 0
    private var phaseStart = 0L
    private var preparedId = ""
    private var fadeStart = 0L
    private var fadeMs = 1L
    private var stable = 0
    private var lastSpeed = 1f
    private var swapStart = 0L

    private val ticker = object : Runnable {
        override fun run() { runCatching { tick() }; handler.postDelayed(this, when (phase) { 0 -> 150L; 3, 4 -> 20L; else -> 40L }) }
    }

    fun get(ctx: Context): ExoPlayer {
        player?.let { return it }
        app = ctx.applicationContext
        val p = ExoPlayer.Builder(app).setAudioAttributes(attrs, !mixOn).setHandleAudioBecomingNoisy(true).build()
        p.setSkipSilenceEnabled(silenceOn)
        p.repeatMode = Player.REPEAT_MODE_ALL   // la fila siempre da la vuelta
        p.addListener(object : Player.Listener {
            override fun onTimelineChanged(timeline: Timeline, reason: Int) { lastIdx = p.currentMediaItemIndex }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val idx = p.currentMediaItemIndex
                val wrapped = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && lastIdx >= 0 &&
                    lastIdx == p.mediaItemCount - 1 && idx == 0 && p.mediaItemCount > 1
                lastIdx = idx
                if (wrapped && shuffleMode) shuffleRest(p)
            }
        })
        player = p
        handler.post(ticker)
        return p
    }

    fun applyMix(mix: Boolean) { mixOn = mix; player?.setAudioAttributes(attrs, !mix) }
    fun applySilence(on: Boolean) { silenceOn = on; player?.setSkipSilenceEnabled(on) }

    fun equalizer(ctx: Context): Equalizer =
        eq ?: Equalizer(0, get(ctx).audioSessionId).apply { enabled = true }.also { eq = it }

    private fun releaseTail() {
        runCatching { tail?.release() }; tail = null
        runCatching { tailEq?.release() }; tailEq = null
        phase = 0
    }

    private fun tick() {
        val p = player ?: return
        val now = SystemClock.elapsedRealtime()
        val t = tail
        if (phase == 4 && t != null) {
            // traspaso corto (120 ms) entre las dos copias de la MISMA canción: evita el chasquido de un corte seco
            val f = ((now - swapStart).toFloat() / 120f).coerceIn(0f, 1f)
            p.volume = kotlin.math.sqrt(1f - f)
            t.volume = kotlin.math.sqrt(f)
            t.playWhenReady = p.playWhenReady
            if (f >= 1f) beginMix(p, now, fadeMs)
            return
        }
        if (phase == 3 && t != null) {
            val f = ((now - fadeStart).toFloat() / fadeMs).coerceIn(0f, 1f)
            p.volume = kotlin.math.sqrt(f)            // curva de potencia constante: la suma suena pareja
            t.volume = kotlin.math.sqrt(1f - f)
            t.playWhenReady = p.playWhenReady
            if (f >= 1f) { releaseTail(); p.volume = 1f }
            return
        }
        val sec = crossfadeSec
        if (sec <= 0 || p.mediaItemCount < 2 || !p.hasNextMediaItem() || p.repeatMode == Player.REPEAT_MODE_ONE) {
            if (phase != 0) releaseTail(); return
        }
        val dur = p.duration
        val ms = sec * 1000L
        if (dur == C.TIME_UNSET || dur < ms + 9000L) { if (phase != 0) releaseTail(); return }
        val left = dur - p.currentPosition
        val id = p.currentMediaItem?.mediaId ?: ""
        if (phase != 0 && (id != preparedId || left > ms + 9000L)) { releaseTail(); return }   // cambió la canción o movieron la barra
        when (phase) {
            0 -> if (p.isPlaying && left in (ms + 4000L)..(ms + 7500L)) prepareTail(p, id)
            1 -> if (left <= ms + 2500L) startTail(p, now)
            2 -> tuneTail(p, t, now, left, ms)
        }
    }

    /** Unos segundos antes: deja listo (y ya cargado) el segundo reproductor con el final de la canción actual. */
    private fun prepareTail(p: ExoPlayer, id: String) {
        val item = p.currentMediaItem ?: return
        val t = ExoPlayer.Builder(app).setAudioAttributes(attrs, false).build()
        t.volume = 0f
        t.setMediaItem(item)
        t.prepare()
        t.seekTo(p.currentPosition)
        t.playWhenReady = false
        // mismo ecualizador que el principal, para que no se note el cambio
        tailEq = eq?.let { src ->
            runCatching {
                Equalizer(0, t.audioSessionId).also { e2 ->
                    e2.enabled = true
                    for (b in 0 until src.numberOfBands) e2.setBandLevel(b.toShort(), src.getBandLevel(b.toShort()))
                }
            }.getOrNull()
        }
        tail = t; preparedId = id; phase = 1
    }

    /** Lo hace sonar en silencio, siguiendo a la canción, para que ya esté andando cuando haga falta. */
    private fun startTail(p: ExoPlayer, now: Long) {
        val t = tail ?: run { phase = 0; return }
        t.seekTo(p.currentPosition + 150)
        t.volume = 0f
        t.playWhenReady = true
        phaseStart = now; phase = 2; stable = 0; lastSpeed = 1f
    }

    /**
     * Mientras suena en silencio, corrige su velocidad hasta quedar clavado con la canción principal
     * (diferencia de pocos milisegundos). Recién ahí se hace el cambio, así no se nota ningún salto.
     */
    private fun tuneTail(p: ExoPlayer, t: ExoPlayer?, now: Long, left: Long, ms: Long) {
        if (t == null) { phase = 0; return }
        t.playWhenReady = p.playWhenReady
        var aligned = false
        if (t.isPlaying && p.isPlaying) {
            val err = t.currentPosition - p.currentPosition      // positivo: la cola va adelantada
            val sp = if (abs(err) <= 12L) 1f else (1f - err / 600f).coerceIn(0.8f, 1.25f)
            if (sp != lastSpeed) { t.setPlaybackParameters(PlaybackParameters(sp)); lastSpeed = sp }
            if (abs(err) <= 15L && lastSpeed == 1f) stable++ else stable = 0
            aligned = stable >= 8
        }
        if ((left <= ms && aligned) || left <= ms - 600L || now - phaseStart > 6000L) beginSwap(p, now, ms)
    }

    private fun beginSwap(p: ExoPlayer, now: Long, ms: Long) {
        if (tail == null) { phase = 0; return }
        fadeMs = ms; swapStart = now; phase = 4
    }

    /** Recién ahora la canción siguiente entra y el segundo reproductor toma el final de la anterior: sin hueco. */
    private fun beginMix(p: ExoPlayer, now: Long, ms: Long) {
        val t = tail ?: run { phase = 0; return }
        val wasLast = p.currentMediaItemIndex == p.mediaItemCount - 1
        if (lastSpeed != 1f) { t.setPlaybackParameters(PlaybackParameters.DEFAULT); lastSpeed = 1f }
        fadeStart = now; fadeMs = ms; phase = 3
        t.volume = 1f
        p.volume = 0f
        p.seekToNextMediaItem()
        if (wasLast && shuffleMode) shuffleRest(p)
    }
}

/** Le pone a la notificación el color de la portada. */
class ArtColorProvider(private val ctx: Context) : MediaNotification.Provider {
    private val inner = DefaultMediaNotificationProvider(ctx).also { it.setSmallIcon(R.drawable.ic_stat) }
    private val worker = Executors.newSingleThreadExecutor()

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        val n = inner.createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
        runCatching {
            val item = mediaSession.player.currentMediaItem
            if (item != null && ArtColors.enabled) {
                val key = item.mediaId
                val c = ArtColors.cached(key)
                if (c != null) {
                    n.notification.color = c
                    n.notification.extras.putBoolean(Notification.EXTRA_COLORIZED, true)
                } else if (!ArtColors.has(key)) {
                    val uri = item.localConfiguration?.uri
                    val albumId = item.mediaMetadata.artworkUri?.lastPathSegment?.toLongOrNull() ?: 0L
                    if (uri != null) worker.execute {
                        if (ArtColors.compute(ctx, key, uri, albumId) != null) {
                            Handler(Looper.getMainLooper()).post {
                                onNotificationChangedCallback.onNotificationChanged(
                                    createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
                                )
                            }
                        }
                    }
                }
            }
        }
        return n
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        inner.handleCustomCommand(session, action, extras)
}

/** Notificación chica con el título de la canción. En Android 16 y en algunos sistemas se muestra como cápsula arriba. */
class ChipNotifier(private val ctx: Context, private val p: Player) : Player.Listener {
    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    @Volatile var enabled = true

    init {
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "Título en la barra de estado", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            )
        }
        p.addListener(this)
    }

    override fun onEvents(player: Player, events: Player.Events) { refresh() }

    fun refresh() {
        runCatching {
            val item = p.currentMediaItem
            if (!enabled || item == null || !p.isPlaying || !NotificationManagerCompat.from(ctx).areNotificationsEnabled()) {
                nm.cancel(ID); return
            }
            val title = item.mediaMetadata.title?.toString() ?: return
            val artist = item.mediaMetadata.artist?.toString() ?: ""
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val extras = Bundle().apply {
                putBoolean("android.requestPromotedOngoing", true)   // pide aparecer como cápsula (Android 16)
                putString("android.shortCriticalText", title)
            }
            val n = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title).setContentText(artist)
                .setColor(ArtColors.cached(item.mediaId) ?: 0xFFFF7849.toInt())
                .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false).setSilent(true)
                .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                .setContentIntent(open)
                .addExtras(extras)
                .build()
            nm.notify(ID, n)
        }
    }

    fun release() { p.removeListener(this); nm.cancel(ID) }

    companion object { const val CH = "titulo_barra"; const val ID = 4242 }
}

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var chip: ChipNotifier? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        setMediaNotificationProvider(ArtColorProvider(this))
        val player = PlayerHolder.get(this)
        session = MediaSession.Builder(this, player).build()
        addSession(session!!)
        val c = ChipNotifier(this, player)
        chip = c
        scope.launch { Prefs(this@PlaybackService).chip.collect { c.enabled = it; c.refresh() } }
    }

    override fun onGetSession(info: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        scope.cancel()
        chip?.release(); chip = null
        session?.release(); session = null
        super.onDestroy()
    }
}
