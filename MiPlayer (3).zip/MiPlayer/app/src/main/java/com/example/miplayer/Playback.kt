package com.example.miplayer

import android.content.Context
import android.media.audiofx.Equalizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Un solo reproductor compartido por la UI, la notificación y el ecualizador. */
object PlayerHolder {
    private var player: ExoPlayer? = null
    private var eq: Equalizer? = null

    fun get(ctx: Context): ExoPlayer = player ?: ExoPlayer.Builder(ctx.applicationContext)
        .setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
        )
        .setHandleAudioBecomingNoisy(true)
        .build().also { player = it }

    fun equalizer(ctx: Context): Equalizer =
        eq ?: Equalizer(0, get(ctx).audioSessionId).apply { enabled = true }.also { eq = it }
}

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        session = MediaSession.Builder(this, PlayerHolder.get(this)).build()
        addSession(session!!)
    }

    override fun onGetSession(info: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        session?.release(); session = null
        super.onDestroy()
    }
}
