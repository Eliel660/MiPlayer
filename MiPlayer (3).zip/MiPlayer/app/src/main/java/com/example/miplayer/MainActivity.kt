@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.miplayer

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object LocalContextHolder { lateinit var ctx: android.content.Context }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        LocalContextHolder.ctx = applicationContext
        startService(Intent(this, PlaybackService::class.java))
        setContent {
            val prefs = remember { Prefs(this) }
            val mode by prefs.mode.collectAsState("system")
            val seed by prefs.seed.collectAsState(3)
            val corner by prefs.corner.collectAsState(50)
            MiPlayerTheme(mode, seed) {
                CompositionLocalProvider(LocalCorner provides corner) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Root(prefs, mode, seed) }
                }
            }
        }
    }
}

private class PState(val playing: Boolean, val mediaId: String, val title: String, val artist: String, val shuffle: Boolean, val repeat: Int)

@Composable
private fun rememberPState(p: Player): State<PState> {
    fun snap() = PState(p.isPlaying, p.currentMediaItem?.mediaId ?: "", p.mediaMetadata.title?.toString() ?: "",
        p.mediaMetadata.artist?.toString() ?: "", p.shuffleModeEnabled, p.repeatMode)
    val st = remember { mutableStateOf(snap()) }
    DisposableEffect(p) {
        val l = object : Player.Listener { override fun onEvents(pl: Player, e: Player.Events) { st.value = snap() } }
        p.addListener(l); onDispose { p.removeListener(l) }
    }
    return st
}

private fun playList(p: Player, list: List<Song>, start: Int) {
    if (list.isEmpty()) return
    p.setMediaItems(list.map {
        MediaItem.Builder().setMediaId(it.id.toString()).setUri(it.uri).setMediaMetadata(
            MediaMetadata.Builder().setTitle(it.title).setArtist(it.artist).setAlbumTitle(it.album)
                .setArtworkUri(Uri.parse("content://media/external/audio/albumart/${it.albumId}")).build()
        ).build()
    }, start, 0)
    p.prepare(); p.play()
}

private val artCache = LruCache<Long, Bitmap>(80)

@Composable
private fun Art(song: Song?, size: Int, modifier: Modifier, corner: Dp? = null) {
    val rad = corner ?: cr(LocalCorner.current, 24)
    val ctx = LocalContext.current
    val key = (song?.id ?: -1L) * 2 + (if (size > 400) 1 else 0)
    val bmp by produceState<Bitmap?>(artCache.get(key), key) {
        if (song == null) return@produceState
        value = artCache.get(key) ?: withContext(Dispatchers.IO) {
            runCatching {
                if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(song.uri, Size(size, size), null)
                else ctx.contentResolver.openInputStream(
                    ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), song.albumId)
                )?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }?.also { artCache.put(key, it) }
    }
    Box(modifier.clip(RoundedCornerShape(rad)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
    }
}

@Composable
private fun Root(prefs: Prefs, mode: String, seed: Int) {
    val ctx = LocalContext.current
    val player = remember { PlayerHolder.get(ctx) }
    val ps by rememberPState(player)
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("lib") }
    val lists by prefs.playlists.collectAsState(emptyMap())
    val sort by prefs.sort.collectAsState("new")
    val sorted = when (sort) { "old" -> songs.reversed(); "az" -> songs.sortedBy { it.title.lowercase() }; else -> songs }

    val perms = buildList {
        add(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r[perms[0]] == true; if (granted) songs = loadSongs(ctx)
    }
    LaunchedEffect(Unit) { launcher.launch(perms) }
    BackHandler(page != "lib") { page = "lib" }

    val current = songs.firstOrNull { it.id.toString() == ps.mediaId }
    when (page) {
        "theme" -> ThemeScreen(prefs, mode, seed) { page = "lib" }
        "now" -> NowPlaying(player, ps, current, lists, prefs) { page = "lib" }
        else -> Library(sorted, lists, prefs, ps, current, player, granted, sort, { page = "theme" }, { page = "now" })
    }
}

@Composable
private fun ItemRow(title: String, sub: String, art: Song?, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Art(art, 256, Modifier.size(64.dp))
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun Library(songs: List<Song>, lists: Map<String, List<Long>>, prefs: Prefs, ps: PState, current: Song?, player: Player,
                    granted: Boolean, sort: String, onTheme: () -> Unit, onNow: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var sortMenu by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val shown = songs.filter { query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true) }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("MiPlayer", Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            IconButton({ search = !search; if (!search) query = "" }) { Icon(Icons.Default.Search, "Buscar") }
            Box {
                IconButton({ sortMenu = true }) { Icon(Icons.Default.SwapVert, "Ordenar") }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf("new" to "Más nuevas primero", "old" to "Más viejas primero", "az" to "A–Z").forEach { (k, l) ->
                        DropdownMenuItem({ Text(l + if (k == sort) "  ✓" else "") }, { sortMenu = false; scope.launch { prefs.setSort(k) } })
                    }
                }
            }
            IconButton(onTheme) { Icon(Icons.Default.Palette, "Tema") }
        }
        if (search) OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            singleLine = true, placeholder = { Text("Buscar") }, shape = RoundedCornerShape(cr(LocalCorner.current, 24)))
        LazyRow(contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(listOf("Canciones", "Álbumes", "Artistas", "Listas")) { i, t ->
                val sel = tab == i
                Surface(onClick = { tab = i }, shape = RoundedCornerShape(cr(LocalCorner.current, 24)), color = if (sel) cs.primary else cs.secondaryContainer) {
                    Text(t, Modifier.padding(horizontal = 20.dp, vertical = 10.dp), fontWeight = FontWeight.Bold,
                        color = if (sel) cs.onPrimary else cs.onSecondaryContainer)
                }
            }
        }
        Box(Modifier.weight(1f)) {
            if (!granted) Text("Falta el permiso de audio.", Modifier.padding(20.dp))
            when (tab) {
                0 -> LazyColumn { items(shown, key = { it.id }) { s ->
                    ItemRow(s.title, "${s.artist} - ${s.album}", s) { playList(player, shown, shown.indexOf(s)); onNow() } } }
                1, 2 -> {
                    val groups = shown.groupBy { if (tab == 1) it.album else it.artist }.entries.toList()
                    LazyColumn { items(groups, key = { it.key }) { g ->
                        ItemRow(g.key.ifBlank { "Desconocido" }, "${g.value.size} canciones", g.value.first()) { playList(player, g.value, 0); onNow() } } }
                }
                else -> PlaylistsTab(songs, lists, prefs) { playList(player, it, 0); onNow() }
            }
        }
        if (ps.title.isNotEmpty()) Surface(onClick = onNow, color = cs.primaryContainer, shape = RoundedCornerShape(topStart = cr(LocalCorner.current, 28), topEnd = cr(LocalCorner.current, 28))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(current, 256, Modifier.size(56.dp))
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(ps.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(ps.artist, style = MaterialTheme.typography.bodyMedium, maxLines = 1, color = cs.onPrimaryContainer.copy(alpha = .7f))
                }
                IconButton({ player.shuffleModeEnabled = !ps.shuffle }) {
                    Icon(Icons.Default.Shuffle, "Mezclar", tint = if (ps.shuffle) cs.primary else cs.onPrimaryContainer)
                }
                OutlinedIconButton({ if (ps.playing) player.pause() else player.play() }, Modifier.size(48.dp)) {
                    Icon(if (ps.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                }
            }
        }
    }
}

@Composable
private fun PlaylistsTab(songs: List<Song>, lists: Map<String, List<Long>>, prefs: Prefs, onPlay: (List<Song>) -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    Column(Modifier.padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(name, { name = it }, Modifier.weight(1f), placeholder = { Text("Nueva lista") }, singleLine = true, shape = RoundedCornerShape(cr(LocalCorner.current, 24)))
            IconButton({ if (name.isNotBlank()) { scope.launch { prefs.savePlaylists(lists + (name to emptyList())) }; name = "" } }) { Icon(Icons.Default.Add, "Crear") }
        }
        LazyColumn {
            items(lists.keys.toList()) { n ->
                ListItem(headlineContent = { Text(n, fontWeight = FontWeight.Bold) }, supportingContent = { Text("${lists[n]!!.size} canciones") },
                    trailingContent = { IconButton({ scope.launch { prefs.savePlaylists(lists - n) } }) { Icon(Icons.Default.Delete, "Borrar") } },
                    modifier = Modifier.clickable { onPlay(songs.filter { it.id in lists[n]!! }) })
            }
        }
    }
}

@Composable
private fun NowPlaying(player: Player, ps: PState, song: Song?, lists: Map<String, List<Long>>, prefs: Prefs, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var pos by remember { mutableLongStateOf(0L) }
    var sleepMin by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { pos = player.currentPosition; delay(400) } }
    LaunchedEffect(sleepMin) { if (sleepMin > 0) { delay(sleepMin * 60_000L); player.pause(); sleepMin = 0 } }
    val favs = lists["Favoritas"] ?: emptyList()
    val fav = song != null && song.id in favs
    val dur = player.duration.coerceAtLeast(1L)
    fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

    Column(Modifier.fillMaxSize().background(cs.primaryContainer).systemBarsPadding().padding(horizontal = 24.dp)) {
        IconButton(onBack) { Icon(Icons.Default.KeyboardArrowDown, "Volver", tint = cs.onPrimaryContainer) }
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(cr(LocalCorner.current, 36))).background(cs.primary.copy(alpha = .3f)).padding(20.dp)) {
            Art(song, 800, Modifier.fillMaxSize(), cr(LocalCorner.current, 20))
        }
        Spacer(Modifier.height(24.dp))
        Text(ps.title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = cs.primary, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(ps.artist, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                color = cs.onPrimaryContainer.copy(alpha = .6f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            IconButton({
                song?.let { s -> scope.launch { prefs.savePlaylists(lists + ("Favoritas" to (if (s.id in favs) favs - s.id else favs + s.id))) } }
            }) { Icon(if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorita", tint = if (fav) cs.primary else cs.onPrimaryContainer.copy(alpha = .7f)) }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "Más", tint = cs.onPrimaryContainer) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Agregar a lista") }, { menu = false; dialog = "list" })
                    DropdownMenuItem({ Text(if (sleepMin > 0) "Temporizador: $sleepMin min" else "Temporizador") }, { menu = false; dialog = "sleep" })
                    DropdownMenuItem({ Text("Repetir: " + when (ps.repeat) { Player.REPEAT_MODE_OFF -> "no"; Player.REPEAT_MODE_ONE -> "una"; else -> "todas" }) }, {
                        player.repeatMode = when (ps.repeat) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                    })
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Slider(pos.toFloat().coerceIn(0f, dur.toFloat()), { player.seekTo(it.toLong()) }, valueRange = 0f..dur.toFloat(),
            colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.onPrimaryContainer.copy(alpha = .7f), inactiveTrackColor = cs.onPrimaryContainer.copy(alpha = .15f)))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(pos), color = cs.onPrimaryContainer.copy(alpha = .6f)); Text(fmt(dur), color = cs.onPrimaryContainer.copy(alpha = .6f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ player.seekToPrevious() }, Modifier.size(72.dp)) { Icon(Icons.Default.FastRewind, "Anterior", Modifier.size(48.dp), tint = cs.primary) }
            IconButton({ if (ps.playing) player.pause() else player.play() }, Modifier.size(104.dp)) {
                Icon(if (ps.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(84.dp), tint = cs.primary)
            }
            IconButton({ player.seekToNext() }, Modifier.size(72.dp)) { Icon(Icons.Default.FastForward, "Siguiente", Modifier.size(48.dp), tint = cs.primary) }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ dialog = "eq" }) { Icon(Icons.Default.Tune, "Ecualizador", tint = cs.onPrimaryContainer.copy(alpha = .7f)) }
            Surface(Modifier.weight(1f).padding(horizontal = 8.dp), shape = RoundedCornerShape(cr(LocalCorner.current, 24)), color = cs.onPrimaryContainer.copy(alpha = .08f)) {
                Text("${ps.artist} · ${song?.album ?: ""}", Modifier.padding(horizontal = 18.dp, vertical = 16.dp), fontWeight = FontWeight.Bold,
                    color = cs.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton({ player.shuffleModeEnabled = !ps.shuffle }) {
                Icon(Icons.Default.Shuffle, "Mezclar", tint = if (ps.shuffle) cs.primary else cs.onPrimaryContainer.copy(alpha = .7f))
            }
        }
    }

    when (dialog) {
        "eq" -> {
            val eq = remember { PlayerHolder.equalizer(LocalContextHolder.ctx) }
            AlertDialog({ dialog = "" }, confirmButton = { TextButton({ dialog = "" }) { Text("Listo") } }, title = { Text("Ecualizador") }, text = {
                Column {
                    val range = eq.bandLevelRange
                    for (b in 0 until eq.numberOfBands) {
                        var lvl by remember { mutableFloatStateOf(eq.getBandLevel(b.toShort()).toFloat()) }
                        Text("${eq.getCenterFreq(b.toShort()) / 1000} Hz")
                        Slider(lvl, { lvl = it; eq.setBandLevel(b.toShort(), it.toInt().toShort()) }, valueRange = range[0].toFloat()..range[1].toFloat())
                    }
                }
            })
        }
        "sleep" -> AlertDialog({ dialog = "" }, confirmButton = {}, title = { Text("Apagar en…") }, text = {
            Column { listOf(0, 15, 30, 45, 60).forEach { m -> TextButton({ sleepMin = m; dialog = "" }) { Text(if (m == 0) "Desactivado" else "$m minutos") } } }
        })
        "list" -> AlertDialog({ dialog = "" }, confirmButton = {}, title = { Text("Agregar a lista") }, text = {
            Column {
                if (lists.isEmpty()) Text("Creá una lista primero en la pestaña Listas.")
                lists.keys.forEach { n ->
                    TextButton({
                        val id = player.currentMediaItem?.mediaId?.toLongOrNull()
                        if (id != null) scope.launch { prefs.savePlaylists(lists + (n to (lists[n]!! + id).distinct())) }
                        dialog = ""
                    }) { Text(n) }
                }
            }
        })
    }
}

@Composable
private fun ThemeScreen(prefs: Prefs, mode: String, seed: Int, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") }
            Text("Tema", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(cr(LocalCorner.current, 32))).background(cs.secondaryContainer).padding(4.dp)) {
            listOf(Triple("dark", "Oscuro", Icons.Default.DarkMode), Triple("light", "Claro", Icons.Default.LightMode),
                Triple("system", "Sistema", Icons.Default.BrightnessAuto)).forEach { (k, label, icon) ->
                val sel = mode == k
                Row(Modifier.weight(1f).clip(RoundedCornerShape(cr(LocalCorner.current, 28))).background(if (sel) cs.primary else Color.Transparent)
                    .clickable { scope.launch { prefs.setMode(k) } }.padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, Modifier.size(20.dp), tint = if (sel) cs.onPrimary else cs.onSecondaryContainer)
                    Spacer(Modifier.width(6.dp))
                    Text(label, fontWeight = FontWeight.Bold, color = if (sel) cs.onPrimary else cs.onSecondaryContainer)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        val all = (if (Build.VERSION.SDK_INT >= 31) listOf(-1) else emptyList()) + seeds.indices.toList()
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(all) { i ->
                val sel = seed == i
                Box(Modifier.size(64.dp).clip(CircleShape).background(if (i < 0) cs.surfaceVariant else seeds[i])
                    .then(if (sel) Modifier.border(3.dp, cs.onBackground, CircleShape) else Modifier)
                    .clickable { scope.launch { prefs.setSeed(i) } }, contentAlignment = Alignment.Center) {
                    if (sel) Icon(Icons.Default.Check, null, tint = if (i < 0) cs.onSurface else Color.White)
                    else if (i < 0) Icon(Icons.Default.AutoAwesome, null, tint = cs.onSurface)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        val startCorner = LocalCorner.current
        var v by remember { mutableFloatStateOf(startCorner.toFloat()) }
        Text("Redondeo de esquinas", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Slider(v, { v = it; scope.launch { prefs.setCorner(it.toInt()) } }, Modifier.weight(1f), valueRange = 0f..100f)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(cr(v.toInt(), 28))).background(cs.primary))
        }
        Spacer(Modifier.height(24.dp))
    }
}
