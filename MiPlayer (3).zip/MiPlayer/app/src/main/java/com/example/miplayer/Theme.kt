package com.example.miplayer

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext

/** Colores base. Agregar uno nuevo = agregar una línea acá. */
val seeds = listOf(
    Color(0xFF2196F3), Color(0xFF00C46A), Color(0xFFD64FD0), Color(0xFFFF7A45),
    Color(0xFFF04E5E), Color(0xFF14B8A6), Color(0xFFEAB308)
)

private fun scheme(seed: Color, dark: Boolean): ColorScheme {
    val hsv = FloatArray(3); android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
    fun c(s: Float, l: Float) = Color.hsl(hsv[0], s, l)
    return if (dark) darkColorScheme(
        primary = c(.85f, .72f), onPrimary = c(.6f, .12f),
        primaryContainer = c(.45f, .26f), onPrimaryContainer = c(.9f, .88f),
        secondaryContainer = c(.30f, .20f), onSecondaryContainer = c(.6f, .90f),
        background = c(.25f, .08f), onBackground = c(.2f, .92f),
        surface = c(.25f, .08f), onSurface = c(.2f, .92f),
        surfaceVariant = c(.25f, .16f), onSurfaceVariant = c(.15f, .72f),
        surfaceContainer = c(.25f, .12f), outline = c(.15f, .45f)
    ) else lightColorScheme(
        primary = c(.70f, .40f), onPrimary = Color.White,
        primaryContainer = c(.80f, .88f), onPrimaryContainer = c(.9f, .15f),
        secondaryContainer = c(.40f, .90f), onSecondaryContainer = c(.6f, .15f),
        background = c(.30f, .97f), onBackground = c(.2f, .10f),
        surface = c(.30f, .97f), onSurface = c(.2f, .10f),
        surfaceVariant = c(.35f, .92f), onSurfaceVariant = c(.15f, .35f),
        surfaceContainer = c(.35f, .94f), outline = c(.15f, .55f)
    )
}

/** seedIdx = -1 → colores dinámicos del sistema (Android 12+). */
@Composable
fun MiPlayerTheme(mode: String, seedIdx: Int, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val cs = if (seedIdx < 0 && Build.VERSION.SDK_INT >= 31)
        (if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx))
    else scheme(seeds[seedIdx.coerceIn(0, seeds.lastIndex)], dark)
    MaterialTheme(colorScheme = cs, content = content)
}

/** Redondeo de esquinas elegido por la persona (0 = rectas, 100 = lo más redondo). */
val LocalCorner = compositionLocalOf { 50 }
fun cr(pct: Int, maxDp: Int): Dp = (maxDp * pct / 100f).dp
