package com.example.miplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

data class Song(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val durationMs: Long, val albumId: Long)

fun loadSongs(ctx: Context): List<Song> {
    val out = mutableListOf<Song>()
    val cols = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID
    )
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.DATE_ADDED} DESC"
    )?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            out += Song(id, c.getString(1) ?: "Sin título", c.getString(2) ?: "Desconocido",
                c.getString(3) ?: "", ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id), c.getLong(4), c.getLong(5))
        }
    }
    return out
}

private val Context.ds by preferencesDataStore("prefs")
private val THEME = stringPreferencesKey("theme")
private val SEED = intPreferencesKey("seed")
private val CORNER = intPreferencesKey("corner")
private val SORT = stringPreferencesKey("sort")
private val LISTS = stringPreferencesKey("playlists")

class Prefs(private val ctx: Context) {
    val mode = ctx.ds.data.map { it[THEME] ?: "system" }
    val seed = ctx.ds.data.map { it[SEED] ?: 3 }
    suspend fun setMode(m: String) { ctx.ds.edit { it[THEME] = m } }
    suspend fun setSeed(i: Int) { ctx.ds.edit { it[SEED] = i } }
    val corner = ctx.ds.data.map { it[CORNER] ?: 50 }
    suspend fun setCorner(i: Int) { ctx.ds.edit { it[CORNER] = i } }
    val sort = ctx.ds.data.map { it[SORT] ?: "new" }
    suspend fun setSort(v: String) { ctx.ds.edit { it[SORT] = v } }

    /** Listas de reproducción: nombre -> ids de canciones (guardadas como JSON). */
    val playlists = ctx.ds.data.map { p ->
        val o = JSONObject(p[LISTS] ?: "{}")
        o.keys().asSequence().associateWith { k -> o.getJSONArray(k).let { a -> List(a.length()) { a.getLong(it) } } }
    }
    suspend fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        ctx.ds.edit { it[LISTS] = o.toString() }
    }
}
