# MiPlayer
Abrir con Android Studio (Ladybug o más nuevo) → Sync → Run.
Agregar temas: editar la lista `themes` en `Theme.kt`.
