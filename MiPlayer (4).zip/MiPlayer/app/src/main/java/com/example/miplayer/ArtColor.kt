package com.example.miplayer

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.palette.graphics.Palette
import java.util.concurrent.ConcurrentHashMap

private val bmpCache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
}

/** Sube cuando se cambia una portada, para que las pantallas la vuelvan a cargar. */
object ArtState { var version by mutableIntStateOf(0) }

/** Deja la portada nueva en la memoria para verla enseguida, sin esperar a que Android la regenere. */
fun overrideArt(uri: Uri, bytes: ByteArray) {
    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return
    val side = minOf(bmp.width, bmp.height)
    val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
    for (s in intArrayOf(128, 256, 800)) bmpCache.put("$uri#$s", Bitmap.createScaledBitmap(square, s, s, true))
    ArtState.version++
}

fun peekArt(uri: Uri, size: Int): Bitmap? = bmpCache.get("$uri#$size")

/** Carátula del archivo de audio (bloqueante: llamar desde un hilo de fondo). */
fun loadArtBitmap(ctx: Context, uri: Uri, albumId: Long, size: Int): Bitmap? {
    val key = "$uri#$size"
    bmpCache.get(key)?.let { return it }
    val raw = runCatching {
        if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
        else ctx.contentResolver.openInputStream(
            ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
        )?.use { BitmapFactory.decodeStream(it) }
    }.getOrNull()
    val b = if (raw != null && raw.config == Bitmap.Config.HARDWARE) raw.copy(Bitmap.Config.ARGB_8888, false) else raw
    if (b != null) bmpCache.put(key, b)
    return b
}

/** Color dominante de cada portada (0 = sin portada). Lo usan la pantalla de reproducción y la notificación. */
object ArtColors {
    @Volatile var enabled = true
    private val cache = ConcurrentHashMap<String, Int>()

    fun cached(key: String): Int? = cache[key]?.takeIf { it != 0 }
    fun has(key: String): Boolean = cache.containsKey(key)
    fun forget(key: String) { cache.remove(key) }

    fun compute(ctx: Context, key: String, uri: Uri, albumId: Long): Int? {
        cache[key]?.let { return it.takeIf { c -> c != 0 } }
        val bmp = loadArtBitmap(ctx, uri, albumId, 128)
        val color = bmp?.let { b ->
            runCatching {
                val p = Palette.from(b).generate()
                (p.vibrantSwatch ?: p.dominantSwatch)?.rgb
            }.getOrNull()
        } ?: 0
        cache[key] = color
        return color.takeIf { it != 0 }
    }
}
