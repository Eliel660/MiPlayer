package com.example.miplayer

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Copia de seguridad manual: notas, letras, listas, diseños de vinilo, reproducciones y cambios de nombre. Solo se hace cuando la persona lo pide. */
object Backup {
    suspend fun export(ctx: Context, uri: Uri, prefs: Prefs): Boolean = runCatching {
        val json = prefs.backupJson()
        val base = ctx.filesDir
        ctx.contentResolver.openOutputStream(uri)!!.use { out ->
            ZipOutputStream(out.buffered()).use { z ->
                z.putNextEntry(ZipEntry("prefs.json")); z.write(json.toByteArray()); z.closeEntry()
                base.walkTopDown().filter { it.isFile }.forEach { f ->
                    val rel = f.relativeTo(base).path.replace('\\', '/')
                    if (!rel.startsWith("datastore/")) {
                        z.putNextEntry(ZipEntry("files/$rel"))
                        f.inputStream().use { it.copyTo(z) }
                        z.closeEntry()
                    }
                }
            }
        }
        true
    }.getOrDefault(false)

    suspend fun import(ctx: Context, uri: Uri, prefs: Prefs): Boolean = runCatching {
        val base = ctx.filesDir.canonicalFile
        var json: String? = null
        val files = ArrayList<Pair<String, ByteArray>>()
        ctx.contentResolver.openInputStream(uri)!!.use { input ->
            ZipInputStream(input.buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    if (!e.isDirectory) {
                        val bytes = z.readBytes()
                        if (e.name == "prefs.json") json = String(bytes)
                        else if (e.name.startsWith("files/")) files.add(e.name.removePrefix("files/") to bytes)
                    }
                    e = z.nextEntry
                }
            }
        }
        val j = json
        if (j == null && files.isEmpty()) return@runCatching false
        for ((rel, bytes) in files) {
            val f = File(base, rel).canonicalFile
            if (!f.path.startsWith(base.path + File.separator)) continue
            f.parentFile?.mkdirs()
            f.writeBytes(bytes)
        }
        if (j != null) prefs.restoreJson(j)
        true
    }.getOrDefault(false)
}
