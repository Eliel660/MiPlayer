package com.example.miplayer

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Colores base. Agregar uno nuevo = agregar una línea acá. */
val seeds = listOf(
    Color(0xFF00C46A), Color(0xFFD64FD0), Color(0xFF2196F3),
    Color(0xFFF04E5E), Color(0xFF14B8A6), Color(0xFFEAB308)
)

/** Redondeo de esquinas elegido por la persona (0 = rectas, 100 = lo más redondo). */
val LocalCorner = compositionLocalOf { 50 }
/** Si está activo, la pantalla de reproducción y el mini reproductor toman los colores de la portada. */
val LocalArtTheme = compositionLocalOf { true }
fun cr(pct: Int, maxDp: Int): Dp = (maxDp * pct / 100f).dp

fun schemeFromSeed(seed: Color, dark: Boolean): ColorScheme {
    val hsv = FloatArray(3); android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
    val k = (hsv[1] * 1.6f).coerceIn(0.08f, 1f)
    fun c(s: Float, l: Float) = Color.hsl(hsv[0], (s * k).coerceIn(0f, 1f), l)
    return if (dark) darkColorScheme(
        primary = c(.85f, .72f), onPrimary = c(.6f, .12f),
        primaryContainer = c(.45f, .26f), onPrimaryContainer = c(.9f, .88f),
        secondaryContainer = c(.30f, .20f), onSecondaryContainer = c(.6f, .90f),
        background = c(.25f, .08f), onBackground = c(.2f, .92f),
        surface = c(.25f, .08f), onSurface = c(.2f, .92f),
        surfaceVariant = c(.25f, .16f), onSurfaceVariant = c(.15f, .72f),
        surfaceContainer = c(.25f, .12f), outline = c(.15f, .45f)
    ) else lightColorScheme(
        primary = c(.70f, .40f), onPrimary = Color.White,
        primaryContainer = c(.80f, .88f), onPrimaryContainer = c(.9f, .15f),
        secondaryContainer = c(.40f, .90f), onSecondaryContainer = c(.6f, .15f),
        background = c(.30f, .97f), onBackground = c(.2f, .10f),
        surface = c(.30f, .97f), onSurface = c(.2f, .10f),
        surfaceVariant = c(.35f, .92f), onSurfaceVariant = c(.15f, .35f),
        surfaceContainer = c(.35f, .94f), outline = c(.15f, .55f)
    )
}

/** Tema Naranja: marrón oscuro con naranja vivo. */
fun orangeScheme(dark: Boolean): ColorScheme = if (dark) darkColorScheme(
    primary = Color(0xFFFF7849), onPrimary = Color(0xFF3A1608),
    primaryContainer = Color(0xFF5E3422), onPrimaryContainer = Color(0xFFFFDBCC),
    secondaryContainer = Color(0xFF47211A), onSecondaryContainer = Color(0xFFFFDBCC),
    background = Color(0xFF221713), onBackground = Color(0xFFF1DFD8),
    surface = Color(0xFF221713), onSurface = Color(0xFFF1DFD8),
    surfaceVariant = Color(0xFF47211A), onSurfaceVariant = Color(0xFFD7C1B8),
    surfaceContainer = Color(0xFF2D1C17), outline = Color(0xFF9F8D85)
) else lightColorScheme(
    primary = Color(0xFFC4501B), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDBCC), onPrimaryContainer = Color(0xFF3A1100),
    secondaryContainer = Color(0xFFF7DDD2), onSecondaryContainer = Color(0xFF2B1810),
    background = Color(0xFFFFF8F5), onBackground = Color(0xFF231915),
    surface = Color(0xFFFFF8F5), onSurface = Color(0xFF231915),
    surfaceVariant = Color(0xFFF5DED5), onSurfaceVariant = Color(0xFF53433D),
    surfaceContainer = Color(0xFFFCEAE2), outline = Color(0xFF85736C)
)

/** Tema Halloween: negro puro, naranja fuerte y marrón. Solo existe en oscuro. */
fun halloweenScheme(): ColorScheme = darkColorScheme(
    primary = Color(0xFFFF8800), onPrimary = Color(0xFF3B1D00),
    primaryContainer = Color(0xFF4A2600), onPrimaryContainer = Color(0xFFFFDDB8),
    secondaryContainer = Color(0xFF5C3000), onSecondaryContainer = Color(0xFFFFDDB8),
    background = Color.Black, onBackground = Color(0xFFFFE9D6),
    surface = Color.Black, onSurface = Color(0xFFFFE9D6),
    surfaceVariant = Color(0xFF5C3000), onSurfaceVariant = Color(0xFFFFC48A),
    surfaceContainer = Color(0xFF140A00), outline = Color(0xFFB0753A)
)

/** seedIdx: -3 = Halloween, -2 = Naranja, -1 = colores dinámicos del sistema (Android 12+), 0.. = colores base. */
@Composable
fun MiPlayerTheme(mode: String, seedIdx: Int, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = if (seedIdx == -3) true else when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val cs = when {
        seedIdx == -3 -> halloweenScheme()
        seedIdx == -1 && Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        seedIdx < 0 -> orangeScheme(dark)
        else -> schemeFromSeed(seeds[seedIdx.coerceIn(0, seeds.lastIndex)], dark)
    }
    MaterialTheme(colorScheme = cs, content = content)
}
