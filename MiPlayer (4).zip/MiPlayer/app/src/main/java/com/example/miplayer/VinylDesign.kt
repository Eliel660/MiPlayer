package com.example.miplayer

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Diseño de un vinilo: una textura y hasta dos colores. Vale para todas las canciones del álbum. */
class VinylDesign(val texture: String, val c1: Int, val c2: Int)

val vinylTextures = listOf(
    "solid" to "Sólido", "half" to "Mitad y mitad", "wave" to "Mitad con ola",
    "splatter" to "Salpicado", "cloud" to "Nube central", "marble" to "Mármol",
    "rings" to "Anillos", "dripcloud" to "Nube con gotas", "blobs" to "Manchas"
)

/** Color "Transparente": plástico claro, se ve el fondo a través del disco. */
const val TRANSPARENT_COLOR = 0x33FFFFFF

/** Paleta: transparente, arcoíris en cinco tonos, grises y marrones. */
val vinylPalette: List<Int> = buildList {
    add(TRANSPARENT_COLOR)
    val tones = listOf(0.30f to 1f, 0.65f to 1f, 1f to 0.85f, 1f to 0.55f, 1f to 0.30f)
    for (h in 0 until 360 step 30) for ((s, v) in tones) add(android.graphics.Color.HSVToColor(floatArrayOf(h.toFloat(), s, v)))
    for (g in listOf(255, 225, 190, 150, 110, 70, 40, 0)) add(android.graphics.Color.rgb(g, g, g))
    for (c in listOf(0xFFF5E6D3, 0xFFD9B99B, 0xFFB08968, 0xFF7B5239, 0xFF4A2F1E)) add(c.toInt())
}

/** Pinta el disco según el diseño, todo dentro del círculo. El dibujo es siempre igual (semilla fija). */
fun DrawScope.drawVinylPaint(d: VinylDesign, r: Float, c: Offset) {
    val a = Color(d.c1)
    val b = Color(d.c2)
    val rnd = Random(7)
    val tau = 2f * PI.toFloat()
    val disc = Path().apply { addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r)) }
    clipPath(disc) {
        drawRect(a, topLeft = Offset(c.x - r, c.y - r), size = Size(2 * r, 2 * r))
        when (d.texture) {
            "rings" -> {
                val ph = rnd.nextFloat() * 6.28f
                var k = 0
                for (frac in listOf(0.94f, 0.74f, 0.54f, 0.34f)) {
                    val p = Path()
                    val n = 90
                    for (i in 0..n) {
                        val t = i / n.toFloat() * tau
                        val rad = r * frac * (1f + 0.05f * sin(t * 3f + ph + k) + 0.03f * sin(t * 5f + ph * 2f + k))
                        val x = c.x + cos(t) * rad
                        val y = c.y + sin(t) * rad
                        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                    }
                    p.close()
                    drawPath(p, if (k % 2 == 0) b else a)
                    k++
                }
            }
            "dripcloud" -> {
                repeat(9) {
                    val ang = rnd.nextFloat() * tau
                    val d0 = r * rnd.nextFloat() * 0.35f
                    drawCircle(b, r * (0.2f + rnd.nextFloat() * 0.18f), Offset(c.x + cos(ang) * d0, c.y + sin(ang) * d0))
                }
                repeat(110) {
                    val ang = rnd.nextFloat() * tau
                    val r0 = r * (0.35f + rnd.nextFloat() * 0.25f)
                    val r1 = r * (0.7f + rnd.nextFloat() * 0.3f)
                    drawLine(b.copy(alpha = b.alpha * 0.8f), Offset(c.x + cos(ang) * r0, c.y + sin(ang) * r0), Offset(c.x + cos(ang) * r1, c.y + sin(ang) * r1),
                        strokeWidth = r * (0.004f + rnd.nextFloat() * 0.01f), cap = StrokeCap.Round)
                }
                repeat(30) {
                    val ang = rnd.nextFloat() * tau
                    val rr = r * (0.6f + rnd.nextFloat() * 0.38f)
                    drawCircle(b, r * (0.006f + rnd.nextFloat() * 0.012f), Offset(c.x + cos(ang) * rr, c.y + sin(ang) * rr))
                }
            }
            "blobs" -> {
                repeat(5) {
                    val ang = rnd.nextFloat() * tau
                    val dist = r * (0.2f + rnd.nextFloat() * 0.4f)
                    val cx = c.x + cos(ang) * dist
                    val cy = c.y + sin(ang) * dist
                    val br = r * (0.17f + rnd.nextFloat() * 0.15f)
                    val ph = rnd.nextFloat() * 6.28f
                    val p = Path()
                    val n = 60
                    for (i in 0..n) {
                        val t = i / n.toFloat() * tau
                        val rad = br * (1f + 0.30f * sin(t * 2f + ph) + 0.18f * sin(t * 3f + ph * 1.7f))
                        val x = cx + cos(t) * rad
                        val y = cy + sin(t) * rad
                        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                    }
                    p.close()
                    drawPath(p, b)
                }
                repeat(26) {
                    val ang = rnd.nextFloat() * tau
                    val rr = r * (0.2f + rnd.nextFloat() * 0.75f)
                    drawCircle(b, r * (0.008f + rnd.nextFloat() * 0.02f), Offset(c.x + cos(ang) * rr, c.y + sin(ang) * rr))
                }
            }
            "half" -> drawRect(b, topLeft = Offset(c.x, c.y - r), size = Size(r, 2 * r))
            "wave" -> {
                val p = Path()
                p.moveTo(c.x - r, c.y)
                val steps = 40
                for (i in 0..steps) {
                    val x = c.x - r + 2f * r * i / steps
                    val y = c.y + sin(i.toFloat() / steps * 3f * PI.toFloat()) * r * 0.10f
                    p.lineTo(x, y)
                }
                p.lineTo(c.x + r, c.y + r)
                p.lineTo(c.x - r, c.y + r)
                p.close()
                drawPath(p, b)
            }
            "splatter" -> {
                repeat(70) {
                    val ang = rnd.nextFloat() * tau
                    val r0 = r * (0.22f + rnd.nextFloat() * 0.35f)
                    val r1 = r * (0.55f + rnd.nextFloat() * 0.45f)
                    val w = r * (0.012f + rnd.nextFloat() * 0.035f)
                    val s = Offset(c.x + cos(ang) * r0, c.y + sin(ang) * r0)
                    val e = Offset(c.x + cos(ang) * r1, c.y + sin(ang) * r1)
                    drawLine(b, s, e, strokeWidth = w, cap = StrokeCap.Round)
                    drawCircle(b, w * 0.9f, e)
                }
                repeat(40) {
                    val ang = rnd.nextFloat() * tau
                    val rr = r * (0.3f + rnd.nextFloat() * 0.7f)
                    drawCircle(b, r * (0.006f + rnd.nextFloat() * 0.012f), Offset(c.x + cos(ang) * rr, c.y + sin(ang) * rr))
                }
            }
            "cloud" -> {
                repeat(9) {
                    val ang = rnd.nextFloat() * tau
                    val d0 = r * rnd.nextFloat() * 0.38f
                    drawCircle(b, r * (0.16f + rnd.nextFloat() * 0.18f), Offset(c.x + cos(ang) * d0, c.y + sin(ang) * d0))
                }
                repeat(26) {
                    val ang = rnd.nextFloat() * tau
                    val d1 = r * (0.55f + rnd.nextFloat() * 0.4f)
                    drawCircle(b, r * (0.01f + rnd.nextFloat() * 0.03f), Offset(c.x + cos(ang) * d1, c.y + sin(ang) * d1))
                }
            }
            "marble" -> {
                for (k in 0 until 7) {
                    val base = r * (0.25f + k * 0.11f)
                    val ph = rnd.nextFloat() * 6.28f
                    val p = Path()
                    val n = 90
                    for (i in 0..n) {
                        val t = i / n.toFloat() * tau
                        val rad = base + sin(t * 3f + ph) * r * 0.07f + sin(t * 5f + ph * 2f) * r * 0.04f
                        val x = c.x + cos(t) * rad
                        val y = c.y + sin(t) * rad
                        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                    }
                    p.close()
                    drawPath(p, b.copy(alpha = b.alpha * 0.55f), style = Stroke(width = r * (0.05f + (k % 3) * 0.03f)))
                }
            }
        }
    }
}
