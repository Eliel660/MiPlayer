@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.miplayer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

object LocalContextHolder { lateinit var ctx: android.content.Context }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        LocalContextHolder.ctx = applicationContext
        startService(Intent(this, PlaybackService::class.java))
        setContent {
            val prefs = remember { Prefs(this) }
            val mode by prefs.mode.collectAsState("system")
            val seed by prefs.seed.collectAsState(-2)
            val corner by prefs.corner.collectAsState(50)
            val artTheme by prefs.artTheme.collectAsState(true)
            MiPlayerTheme(mode, seed) {
                CompositionLocalProvider(LocalCorner provides corner, LocalArtTheme provides artTheme) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Root(prefs, mode, seed) }
                }
            }
        }
    }
}

// ───────────── estado del reproductor ─────────────

private class PState(val playing: Boolean, val mediaId: String, val title: String, val artist: String, val repeat: Int)
private class QState(val items: List<MediaItem>, val index: Int)

@Composable
private fun rememberPState(p: Player): State<PState> {
    fun snap() = PState(p.isPlaying, p.currentMediaItem?.mediaId ?: "", p.mediaMetadata.title?.toString() ?: "",
        p.mediaMetadata.artist?.toString() ?: "", p.repeatMode)
    val st = remember { mutableStateOf(snap()) }
    DisposableEffect(p) {
        val l = object : Player.Listener { override fun onEvents(pl: Player, e: Player.Events) { st.value = snap() } }
        p.addListener(l); onDispose { p.removeListener(l) }
    }
    return st
}

@Composable
private fun rememberQueue(p: Player): State<QState> {
    fun snap() = QState(List(p.mediaItemCount) { p.getMediaItemAt(it) }, p.currentMediaItemIndex)
    val st = remember { mutableStateOf(snap()) }
    DisposableEffect(p) {
        val l = object : Player.Listener {
            override fun onEvents(pl: Player, e: Player.Events) {
                if (e.containsAny(Player.EVENT_TIMELINE_CHANGED, Player.EVENT_MEDIA_ITEM_TRANSITION)) st.value = snap()
            }
        }
        p.addListener(l); onDispose { p.removeListener(l) }
    }
    return st
}

@Composable
private fun rememberPos(p: Player): State<Long> = produceState(p.currentPosition) {
    while (true) { value = p.currentPosition; delay(400) }
}

private fun toItem(s: Song): MediaItem = MediaItem.Builder().setMediaId(s.id.toString()).setUri(s.uri).setMediaMetadata(
    MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album)
        .setArtworkUri(Uri.parse("content://media/external/audio/albumart/${s.albumId}")).build()
).build()

private fun playList(p: Player, list: List<Song>, start: Int) {
    val l = list.distinctBy { it.id }
    if (l.isEmpty()) return
    val startId = list.getOrNull(start)?.id
    val idx = l.indexOfFirst { it.id == startId }.coerceAtLeast(0)
    p.setMediaItems(l.map { toItem(it) }, idx, 0); p.prepare(); p.play()
}

private fun indexOfId(p: Player, id: String): Int {
    for (i in 0 until p.mediaItemCount) if (p.getMediaItemAt(i).mediaId == id) return i
    return -1
}

private fun playNext(p: Player, s: Song) {
    if (p.mediaItemCount == 0) { playList(p, listOf(s), 0); return }
    val cur = p.currentMediaItemIndex
    val ex = indexOfId(p, s.id.toString())
    when {
        ex == cur -> {}
        ex < 0 -> p.addMediaItem(cur + 1, toItem(s))
        ex < cur -> p.moveMediaItem(ex, cur)
        else -> p.moveMediaItem(ex, cur + 1)
    }
}

private fun addToQueue(p: Player, s: Song) {
    if (p.mediaItemCount == 0) { playList(p, listOf(s), 0); return }
    if (indexOfId(p, s.id.toString()) < 0) p.addMediaItem(toItem(s))
}

/** Rehace la fila al azar sin cortar la canción que suena. */
private fun reshuffle(p: Player) {
    val n = p.mediaItemCount
    if (n < 2) return
    val cur = p.currentMediaItemIndex
    val others = (0 until n).filter { it != cur }.map { p.getMediaItemAt(it) }.shuffled()
    p.removeMediaItems(cur + 1, n)
    p.removeMediaItems(0, cur)
    p.addMediaItems(others)
}

private fun clearQueue(p: Player) {
    val n = p.mediaItemCount
    val cur = p.currentMediaItemIndex
    p.removeMediaItems(cur + 1, n)
    p.removeMediaItems(0, cur)
}

// ───────────── piezas reutilizables ─────────────

@Composable
private fun Art(song: Song?, size: Int, modifier: Modifier, corner: Dp? = null) {
    val ctx = LocalContext.current
    val rad = corner ?: cr(LocalCorner.current, 24)
    val bmp by produceState<Bitmap?>(if (song != null) peekArt(song.uri, size) else null, song?.id, size) {
        value = if (song == null) null else withContext(Dispatchers.IO) { loadArtBitmap(ctx, song.uri, song.albumId, size) }
    }
    Box(modifier.clip(RoundedCornerShape(rad)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
    }
}

/** Barra de progreso gruesa y redondeada, se toca o se arrastra. */
@Composable
private fun SeekBar(pos: Long, dur: Long, onSeek: (Long) -> Unit, modifier: Modifier, height: Dp, track: Color, fill: Color) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = drag ?: (pos.toFloat() / dur.coerceAtLeast(1L)).coerceIn(0f, 1f)
    Box(
        modifier.height(height + 18.dp)
            .pointerInput(dur) { detectTapGestures { o -> onSeek((o.x / size.width * dur).toLong()) } }
            .pointerInput(dur) {
                detectHorizontalDragGestures(
                    onDragStart = { drag = (it.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { drag?.let { f -> onSeek((f * dur).toLong()) }; drag = null },
                    onDragCancel = { drag = null },
                    onHorizontalDrag = { change, _ -> change.consume(); drag = (change.position.x / size.width).coerceIn(0f, 1f) }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(track)) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(RoundedCornerShape(50)).background(fill))
        }
    }
}

/** Pastilla para subir y bajar rápido por listas largas. */
@Composable
private fun FastScroller(state: LazyListState, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    var dragging by remember { mutableStateOf(false) }
    var visible by remember { mutableStateOf(false) }
    var dragFrac by remember { mutableFloatStateOf(0f) }
    val total = state.layoutInfo.totalItemsCount
    val vis = state.layoutInfo.visibleItemsInfo.size.coerceAtLeast(1)
    val computed = (state.firstVisibleItemIndex.toFloat() / (total - vis).coerceAtLeast(1)).coerceIn(0f, 1f)
    val latest = rememberUpdatedState(computed)
    LaunchedEffect(state.isScrollInProgress, dragging) {
        if (state.isScrollInProgress || dragging) visible = true else { delay(1500); visible = false }
    }
    val a by animateFloatAsState(if (visible && total > 25) 1f else 0f, label = "fastscroll")
    if (a < 0.01f) return
    BoxWithConstraints(modifier.fillMaxHeight().width(52.dp)) {
        val handleH = 56.dp
        val trackPx = with(LocalDensity.current) { (maxHeight - handleH).toPx() }.coerceAtLeast(1f)
        val f = if (dragging) dragFrac else computed
        Box(
            Modifier.align(Alignment.TopEnd)
                .offset { IntOffset(0, (f * trackPx).roundToInt()) }
                .padding(end = 6.dp)
                .size(40.dp, handleH)
                .graphicsLayer { alpha = a }
                .clip(RoundedCornerShape(50))
                .background(cs.primary.copy(alpha = .28f))
                .pointerInput(total, trackPx) {
                    detectDragGestures(
                        onDragStart = { dragging = true; dragFrac = latest.value },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                        onDrag = { change, amount ->
                            change.consume()
                            dragFrac = (dragFrac + amount.y / trackPx).coerceIn(0f, 1f)
                            scope.launch { state.scrollToItem((dragFrac * (total - 1)).roundToInt()) }
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.DragHandle, null, tint = cs.onSurface) }
    }
}

@Composable
private fun ItemRow(title: String, sub: String, art: Song?, trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Art(art, 256, Modifier.size(64.dp))
        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing?.invoke()
    }
}

@Composable
private fun SongMenu(onNext: () -> Unit, onQueue: () -> Unit, onAdd: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.padding(end = 4.dp)) {
        IconButton({ open = true }) { Icon(Icons.Rounded.MoreVert, "Más") }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem({ Text("Reproducir a continuación") }, { open = false; onNext() })
            DropdownMenuItem({ Text("Agregar a la fila") }, { open = false; onQueue() })
            DropdownMenuItem({ Text("Agregar a lista") }, { open = false; onAdd() })
        }
    }
}

@Composable
private fun SwitchRow(icon: ImageVector, title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(30.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun PillButton(icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(cr(LocalCorner.current, 32)),
        color = if (selected) cs.primary else cs.onPrimaryContainer.copy(alpha = .10f)) {
        Box(Modifier.height(64.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Icon(icon, null, Modifier.size(28.dp), tint = if (selected) cs.onPrimary else cs.onPrimaryContainer)
        }
    }
}

// ───────────── raíz y navegación ─────────────

@Composable
private fun Root(prefs: Prefs, mode: String, seed: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { PlayerHolder.get(ctx) }
    val ps by rememberPState(player)
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var granted by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("lib") }
    var sleepMin by remember { mutableIntStateOf(0) }
    var lyricsVersion by remember { mutableIntStateOf(0) }
    var noteFor by remember { mutableStateOf<Song?>(null) }
    var pendingDelete by remember { mutableStateOf<Song?>(null) }
    val lists by prefs.playlists.collectAsState(emptyMap())
    val sort by prefs.sort.collectAsState("new")
    val hidden by prefs.hidden.collectAsState(emptySet<Long>())
    val mix by prefs.mix.collectAsState(false)
    val silence by prefs.silence.collectAsState(false)
    val cfOn by prefs.crossfadeOn.collectAsState(false)
    val cfSec by prefs.crossfadeSec.collectAsState(6)
    val artEnabled = LocalArtTheme.current
    val base = MaterialTheme.colorScheme
    val dark = base.background.luminance() < 0.5f

    LaunchedEffect(mix) { PlayerHolder.applyMix(mix) }
    LaunchedEffect(silence) { PlayerHolder.applySilence(silence) }
    LaunchedEffect(cfOn, cfSec) { PlayerHolder.crossfadeSec = if (cfOn) cfSec else 0 }
    LaunchedEffect(artEnabled) { ArtColors.enabled = artEnabled }
    LaunchedEffect(sleepMin) { if (sleepMin > 0) { delay(sleepMin * 60_000L); player.pause(); sleepMin = 0 } }

    val perms = buildList {
        add(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r[perms[0]] == true; if (granted) songs = loadSongs(ctx)
    }
    LaunchedEffect(Unit) { launcher.launch(perms) }
    BackHandler(page != "lib") { page = when (page) { "queue", "lyrics" -> "now"; else -> "lib" } }

    fun afterDelete(s: Song) {
        val i = indexOfId(player, s.id.toString())
        if (i >= 0) player.removeMediaItem(i)
        songs = loadSongs(ctx)
    }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) pendingDelete?.let { afterDelete(it) }
        pendingDelete = null
    }
    fun requestDelete(s: Song) {
        if (Build.VERSION.SDK_INT >= 30) {
            pendingDelete = s
            val pi = MediaStore.createDeleteRequest(ctx.contentResolver, listOf(s.uri))
            deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            val ok = runCatching { ctx.contentResolver.delete(s.uri, null, null) > 0 }.getOrDefault(false)
            if (ok) afterDelete(s) else Toast.makeText(ctx, "No se pudo eliminar la canción", Toast.LENGTH_SHORT).show()
        }
    }

    val visible = songs.filter { it.id !in hidden }
    val sorted = when (sort) { "old" -> visible.reversed(); "az" -> visible.sortedBy { it.title.lowercase() }; else -> visible }
    val byId = songs.associateBy { it.id }
    val current = byId[ps.mediaId.toLongOrNull()]

    // Colores de la portada para la pantalla de reproducción, el mini reproductor y la fila
    val artSeed by produceState<Int?>(null, current?.id, artEnabled) {
        val c = current
        value = if (c == null || !artEnabled) null else withContext(Dispatchers.IO) { ArtColors.compute(ctx, c.id.toString(), c.uri, c.albumId) }
    }
    val artCs = remember(artSeed, dark, base) { artSeed?.let { schemeFromSeed(Color(it), dark) } ?: base }

    val lyrics by produceState("", current?.id, lyricsVersion) {
        val c = current
        value = if (c == null) "" else withContext(Dispatchers.IO) { loadLyrics(ctx, c) }
    }
    val firstLine = lyrics.lineSequence().firstOrNull { it.isNotBlank() }

    when (page) {
        "theme" -> ThemeScreen(prefs, mode, seed) { page = "lib" }
        "settings" -> SettingsScreen(prefs, mix, silence, cfOn, cfSec, sleepMin, { sleepMin = it }, songs.filter { it.id in hidden }) { page = "lib" }
        "now" -> MaterialTheme(colorScheme = artCs) {
            NowPlaying(player, ps, current, lists, prefs, firstLine,
                onBack = { page = "lib" }, onLyrics = { page = "lyrics" }, onQueue = { page = "queue" },
                onDelete = { current?.let { requestDelete(it) } },
                onHide = { current?.let { s -> scope.launch { prefs.hide(s.id) }; Toast.makeText(ctx, "Canción oculta", Toast.LENGTH_SHORT).show() } },
                onNote = { noteFor = current })
        }
        "queue" -> MaterialTheme(colorScheme = artCs) { QueueScreen(player, ps, byId, current) { page = "now" } }
        "lyrics" -> MaterialTheme(colorScheme = artCs) { LyricsScreen(current, lyrics, { page = "now" }, { lyricsVersion++ }) }
        else -> Library(sorted, lists, prefs, ps, current, player, granted, sort, artCs,
            { page = "settings" }, { page = "theme" }, { page = "now" })
    }

    noteFor?.let { s ->
        var text by remember(s.id) { mutableStateOf(Store.read(ctx, "notes", s.id)) }
        AlertDialog(
            onDismissRequest = { noteFor = null },
            confirmButton = { TextButton({ Store.write(ctx, "notes", s.id, text); noteFor = null }) { Text("Guardar") } },
            dismissButton = { TextButton({ noteFor = null }) { Text("Cancelar") } },
            title = { Text("Anotación") },
            text = {
                OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), minLines = 4,
                    placeholder = { Text("Escribí lo que quieras recordar de esta canción") })
            }
        )
    }
}

// ───────────── biblioteca ─────────────

@Composable
private fun Library(songs: List<Song>, lists: Map<String, List<Long>>, prefs: Prefs, ps: PState, current: Song?, player: Player,
                    granted: Boolean, sort: String, artCs: ColorScheme, onSettings: () -> Unit, onTheme: () -> Unit, onNow: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val scope = rememberCoroutineScope()
    var sortMenu by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var addFor by remember { mutableStateOf<Song?>(null) }
    val shown = songs.filter { query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("M!Perla", Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            IconButton({ search = !search; if (!search) query = "" }) { Icon(Icons.Rounded.Search, "Buscar") }
            Box {
                IconButton({ sortMenu = true }) { Icon(Icons.Rounded.SwapVert, "Ordenar") }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf("new" to "Más nuevas primero", "old" to "Más viejas primero", "az" to "A–Z").forEach { (k, l) ->
                        DropdownMenuItem({ Text(l + if (k == sort) "  ✓" else "") }, { sortMenu = false; scope.launch { prefs.setSort(k) } })
                    }
                }
            }
            IconButton(onSettings) { Icon(Icons.Rounded.Settings, "Ajustes") }
            IconButton(onTheme) { Icon(Icons.Rounded.Palette, "Tema") }
        }
        if (search) OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            singleLine = true, placeholder = { Text("Buscar") }, shape = RoundedCornerShape(cr(c, 24)))
        LazyRow(contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(listOf("Canciones", "Álbumes", "Artistas", "Listas")) { i, t ->
                val sel = tab == i
                Surface(onClick = { tab = i }, shape = RoundedCornerShape(cr(c, 24)), color = if (sel) cs.primary else cs.secondaryContainer) {
                    Text(t, Modifier.padding(horizontal = 20.dp, vertical = 10.dp), fontWeight = FontWeight.Bold,
                        color = if (sel) cs.onPrimary else cs.onSecondaryContainer)
                }
            }
        }
        Box(Modifier.weight(1f)) {
            if (!granted) Text("Falta el permiso de audio.", Modifier.padding(20.dp))
            when (tab) {
                0 -> Box(Modifier.fillMaxSize()) {
                    val st = rememberLazyListState()
                    LazyColumn(state = st) {
                        items(shown, key = { it.id }) { s ->
                            ItemRow(s.title, "${s.artist} - ${s.album}", s,
                                trailing = { SongMenu({ playNext(player, s) }, { addToQueue(player, s) }, { addFor = s }) }
                            ) { playList(player, shown, shown.indexOf(s)); onNow() }
                        }
                        item { Spacer(Modifier.navigationBarsPadding()) }
                    }
                    FastScroller(st, Modifier.align(Alignment.CenterEnd))
                }
                1, 2 -> Box(Modifier.fillMaxSize()) {
                    val st = rememberLazyListState()
                    val groups = shown.groupBy { if (tab == 1) it.album else it.artist }.entries.toList()
                    LazyColumn(state = st) {
                        items(groups, key = { it.key }) { g ->
                            ItemRow(g.key.ifBlank { "Desconocido" }, "${g.value.size} canciones", g.value.first()) {
                                playList(player, g.value, 0); onNow()
                            }
                        }
                        item { Spacer(Modifier.navigationBarsPadding()) }
                    }
                    FastScroller(st, Modifier.align(Alignment.CenterEnd))
                }
                else -> PlaylistsTab(songs, lists, prefs) { playList(player, it, 0); onNow() }
            }
        }
        if (ps.title.isNotEmpty()) MaterialTheme(colorScheme = artCs) { MiniPlayer(player, ps, current, onNow) }
    }

    addFor?.let { s ->
        AlertDialog({ addFor = null }, confirmButton = {}, title = { Text("Agregar a lista") }, text = {
            Column {
                if (lists.isEmpty()) Text("Creá una lista primero en la pestaña Listas.")
                lists.keys.forEach { n ->
                    TextButton({
                        scope.launch { prefs.savePlaylists(lists + (n to (lists[n]!! + s.id).distinct())) }
                        addFor = null
                    }) { Text(n) }
                }
            }
        })
    }
}

/** Llega hasta el borde de abajo; los botones quedan arriba de la barra de gestos. */
@Composable
private fun MiniPlayer(player: Player, ps: PState, current: Song?, onNow: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val pos by rememberPos(player)
    val dur = player.duration.coerceAtLeast(1L)
    Surface(onClick = onNow, color = cs.primaryContainer, shape = RoundedCornerShape(topStart = cr(c, 32), topEnd = cr(c, 32))) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Art(current, 256, Modifier.size(56.dp))
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(ps.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(ps.artist, style = MaterialTheme.typography.bodyMedium, maxLines = 1, color = cs.onPrimaryContainer.copy(alpha = .7f))
                }
                IconButton({ reshuffle(player) }) { Icon(Icons.Rounded.Shuffle, "Mezclar la fila", tint = cs.onPrimaryContainer) }
                IconButton({ if (ps.playing) player.pause() else player.play() }, Modifier.size(52.dp)) {
                    Icon(if (ps.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(36.dp), tint = cs.primary)
                }
            }
            SeekBar(pos, dur, { player.seekTo(it) }, Modifier.fillMaxWidth(), 6.dp, cs.onPrimaryContainer.copy(alpha = .15f), cs.primary)
        }
    }
}

@Composable
private fun PlaylistsTab(songs: List<Song>, lists: Map<String, List<Long>>, prefs: Prefs, onPlay: (List<Song>) -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    Column(Modifier.padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(name, { name = it }, Modifier.weight(1f), placeholder = { Text("Nueva lista") }, singleLine = true,
                shape = RoundedCornerShape(cr(LocalCorner.current, 24)))
            IconButton({ if (name.isNotBlank()) { scope.launch { prefs.savePlaylists(lists + (name to emptyList())) }; name = "" } }) { Icon(Icons.Rounded.Add, "Crear") }
        }
        LazyColumn {
            items(lists.keys.toList()) { n ->
                ListItem(headlineContent = { Text(n, fontWeight = FontWeight.Bold) }, supportingContent = { Text("${lists[n]!!.size} canciones") },
                    trailingContent = { IconButton({ scope.launch { prefs.savePlaylists(lists - n) } }) { Icon(Icons.Rounded.Delete, "Borrar") } },
                    modifier = Modifier.clickable { onPlay(songs.filter { it.id in lists[n]!! }) })
            }
            item { Spacer(Modifier.navigationBarsPadding()) }
        }
    }
}

// ───────────── reproducción ─────────────

@Composable
private fun NowPlaying(player: Player, ps: PState, song: Song?, lists: Map<String, List<Long>>, prefs: Prefs, firstLine: String?,
                       onBack: () -> Unit, onLyrics: () -> Unit, onQueue: () -> Unit, onDelete: () -> Unit, onHide: () -> Unit, onNote: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val scope = rememberCoroutineScope()
    val pos by rememberPos(player)
    var menu by remember { mutableStateOf(false) }
    var eqOpen by remember { mutableStateOf(false) }
    val favs = lists["Favoritas"] ?: emptyList()
    val fav = song != null && song.id in favs
    val dur = player.duration.coerceAtLeast(1L)
    fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

    Surface(Modifier.fillMaxSize(), color = cs.primaryContainer) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp)) {
            IconButton(onBack) { Icon(Icons.Rounded.KeyboardArrowDown, "Volver", Modifier.size(30.dp)) }
            Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(cr(c, 40)))
                .background(cs.primary.copy(alpha = .3f).compositeOver(cs.primaryContainer)).padding(22.dp)) {
                Art(song, 800, Modifier.fillMaxSize(), cr(c, 22))
            }
            Spacer(Modifier.height(22.dp))
            Text(ps.title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = cs.primary,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(ps.artist, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    color = cs.onPrimaryContainer.copy(alpha = .6f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                IconButton({
                    song?.let { s -> scope.launch { prefs.savePlaylists(lists + ("Favoritas" to (if (s.id in favs) favs - s.id else favs + s.id))) } }
                }) {
                    Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorita",
                        tint = if (fav) cs.primary else cs.onPrimaryContainer.copy(alpha = .7f))
                }
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "Más") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Eliminar canción") }, { menu = false; onDelete() }, leadingIcon = { Icon(Icons.Rounded.Delete, null) })
                        DropdownMenuItem({ Text("Ocultar") }, { menu = false; onHide() }, leadingIcon = { Icon(Icons.Rounded.VisibilityOff, null) })
                        DropdownMenuItem({ Text("Crear anotación") }, { menu = false; onNote() }, leadingIcon = { Icon(Icons.Rounded.Edit, null) })
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            SeekBar(pos, dur, { player.seekTo(it) }, Modifier.fillMaxWidth(), 14.dp, cs.onPrimaryContainer.copy(alpha = .18f), cs.onPrimaryContainer.copy(alpha = .75f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(pos), color = cs.onPrimaryContainer.copy(alpha = .6f)); Text(fmt(dur), color = cs.onPrimaryContainer.copy(alpha = .6f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton({ player.seekToPrevious() }, Modifier.size(76.dp)) { Icon(Icons.Rounded.FastRewind, "Anterior", Modifier.size(52.dp), tint = cs.primary) }
                IconButton({ if (ps.playing) player.pause() else player.play() }, Modifier.size(108.dp)) {
                    Icon(if (ps.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(88.dp), tint = cs.primary)
                }
                IconButton({ player.seekToNext() }, Modifier.size(76.dp)) { Icon(Icons.Rounded.FastForward, "Siguiente", Modifier.size(52.dp), tint = cs.primary) }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ eqOpen = true }) { Icon(Icons.Rounded.Tune, "Ecualizador", tint = cs.onPrimaryContainer.copy(alpha = .7f)) }
                Surface(onClick = onLyrics, modifier = Modifier.weight(1f).padding(horizontal = 8.dp), shape = RoundedCornerShape(cr(c, 24)),
                    color = cs.onPrimaryContainer.copy(alpha = .08f)) {
                    Text(firstLine ?: "Letra", Modifier.padding(horizontal = 18.dp, vertical = 16.dp), fontWeight = FontWeight.Bold,
                        color = cs.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onQueue) { Icon(Icons.Default.QueueMusic, "Fila", tint = cs.onPrimaryContainer.copy(alpha = .7f)) }
            }
        }
    }

    if (eqOpen) {
        val eq = remember { PlayerHolder.equalizer(LocalContextHolder.ctx) }
        AlertDialog({ eqOpen = false }, confirmButton = { TextButton({ eqOpen = false }) { Text("Listo") } }, title = { Text("Ecualizador") }, text = {
            Column {
                val range = eq.bandLevelRange
                for (b in 0 until eq.numberOfBands) {
                    var lvl by remember { mutableFloatStateOf(eq.getBandLevel(b.toShort()).toFloat()) }
                    Text("${eq.getCenterFreq(b.toShort()) / 1000} Hz")
                    Slider(lvl, { lvl = it; eq.setBandLevel(b.toShort(), it.toInt().toShort()) }, valueRange = range[0].toFloat()..range[1].toFloat())
                }
            }
        })
    }
}

@Composable
private fun QueueScreen(player: Player, ps: PState, byId: Map<Long, Song>, cur: Song?, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val scope = rememberCoroutineScope()
    val pos by rememberPos(player)
    val q by rememberQueue(player)
    val listState = rememberLazyListState()
    val rowPx = with(LocalDensity.current) { 80.dp.toPx() }
    var dragId by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val sheet = cs.onPrimaryContainer.copy(alpha = .07f).compositeOver(cs.primaryContainer)
    val dur = player.duration.coerceAtLeast(1L)

    Surface(Modifier.fillMaxSize(), color = cs.primaryContainer) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(cur, 256, Modifier.size(64.dp))
                Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                    Text(ps.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(ps.artist, color = cs.onPrimaryContainer.copy(alpha = .65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton({ if (ps.playing) player.pause() else player.play() }, Modifier.size(56.dp)) {
                    Icon(if (ps.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(40.dp))
                }
            }
            SeekBar(pos, dur, { player.seekTo(it) }, Modifier.fillMaxWidth().padding(horizontal = 20.dp), 8.dp,
                cs.onPrimaryContainer.copy(alpha = .15f), cs.onPrimaryContainer.copy(alpha = .7f))
            Spacer(Modifier.height(8.dp))
            Surface(Modifier.weight(1f).fillMaxWidth(), shape = RoundedCornerShape(topStart = cr(c, 36), topEnd = cr(c, 36)), color = sheet) {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxWidth().clickable(onClick = onBack).padding(top = 8.dp), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "Cerrar", Modifier.size(32.dp), tint = cs.onPrimaryContainer.copy(alpha = .6f))
                    }
                    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Fila", Modifier.weight(1f), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        IconButton({ if (q.index >= 0) scope.launch { listState.animateScrollToItem(q.index) } }) {
                            Icon(Icons.Rounded.CenterFocusStrong, "Ir a la actual")
                        }
                        IconButton({ clearQueue(player) }) { Icon(Icons.Rounded.DeleteSweep, "Vaciar fila") }
                    }
                    LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
                        itemsIndexed(q.items, key = { _, m -> m.mediaId }) { index, item ->
                            val s = byId[item.mediaId.toLongOrNull()]
                            val isCur = index == q.index
                            val dragging = dragId == item.mediaId
                            Row(
                                Modifier.fillMaxWidth().height(80.dp).zIndex(if (dragging) 1f else 0f)
                                    .graphicsLayer { translationY = if (dragging) dragOffset else 0f }
                                    .clickable { player.seekTo(index, 0L); player.play() }
                                    .padding(start = 16.dp, end = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Art(s, 256, Modifier.size(64.dp))
                                    if (isCur) Box(Modifier.size(64.dp).clip(RoundedCornerShape(cr(c, 24))).background(Color.Black.copy(alpha = .38f)),
                                        contentAlignment = Alignment.Center) { Icon(Icons.Rounded.GraphicEq, null, tint = Color.White) }
                                }
                                Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                                    Text(s?.title ?: (item.mediaMetadata.title?.toString() ?: ""), style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold, color = if (isCur) cs.primary else cs.onPrimaryContainer,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(if (s != null) "${s.artist} - ${s.album}" else "", color = cs.onPrimaryContainer.copy(alpha = .6f),
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Icon(Icons.Rounded.DragHandle, "Mover", Modifier.size(48.dp).padding(10.dp).pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragStart = { dragId = item.mediaId; dragOffset = 0f },
                                        onDragEnd = { dragId = null; dragOffset = 0f },
                                        onDragCancel = { dragId = null; dragOffset = 0f },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            dragOffset += amount.y
                                            val from = indexOfId(player, item.mediaId)
                                            if (from >= 0) {
                                                val to = (from + (dragOffset / rowPx).roundToInt()).coerceIn(0, player.mediaItemCount - 1)
                                                if (to != from) { player.moveMediaItem(from, to); dragOffset -= (to - from) * rowPx }
                                            }
                                        }
                                    )
                                }, tint = cs.onPrimaryContainer.copy(alpha = .7f))
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        PillButton(Icons.Rounded.RepeatOne, ps.repeat == Player.REPEAT_MODE_ONE, Modifier.weight(1f)) {
                            player.repeatMode = if (ps.repeat == Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ONE
                        }
                        PillButton(Icons.Rounded.Repeat, ps.repeat == Player.REPEAT_MODE_ALL, Modifier.weight(1f)) {
                            player.repeatMode = if (ps.repeat == Player.REPEAT_MODE_ALL) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ALL
                        }
                        PillButton(Icons.Rounded.Shuffle, true, Modifier.weight(1.3f)) { reshuffle(player) }
                    }
                }
            }
        }
    }
}

@Composable
private fun LyricsScreen(song: Song?, lyrics: String, onBack: () -> Unit, onChanged: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val ctx = LocalContext.current
    var editing by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    val note = remember(song?.id, editing) { if (song == null) "" else Store.read(ctx, "notes", song.id) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && song != null) {
            val txt = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
            if (!txt.isNullOrBlank()) { Store.write(ctx, "lyrics", song.id, txt); onChanged() }
        }
    }
    Surface(Modifier.fillMaxSize(), color = cs.primaryContainer) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Rounded.KeyboardArrowDown, "Volver", Modifier.size(30.dp)) }
                Column(Modifier.weight(1f)) {
                    Text(song?.title ?: "", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song?.artist ?: "", color = cs.onPrimaryContainer.copy(alpha = .65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton({ picker.launch(arrayOf("*/*")) }) { Icon(Icons.Rounded.Description, "Importar archivo") }
                IconButton({ draft = lyrics; editing = true }) { Icon(Icons.Rounded.Edit, "Editar letra") }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 8.dp)) {
                if (note.isNotBlank()) {
                    Surface(shape = RoundedCornerShape(cr(c, 20)), color = cs.onPrimaryContainer.copy(alpha = .10f)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Rounded.Edit, null, Modifier.size(20.dp), tint = cs.primary)
                            Text(note, Modifier.padding(start = 10.dp))
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                }
                if (lyrics.isBlank()) Text(
                    "No hay letra para esta canción. Tocá el lápiz para pegarla o el ícono de archivo para importar un .lrc o .txt.",
                    color = cs.onPrimaryContainer.copy(alpha = .7f)
                ) else Text(lyrics, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, lineHeight = 38.sp)
                Spacer(Modifier.height(64.dp))
            }
        }
    }
    if (editing) AlertDialog(
        onDismissRequest = { editing = false },
        confirmButton = { TextButton({ if (song != null) Store.write(ctx, "lyrics", song.id, draft); editing = false; onChanged() }) { Text("Guardar") } },
        dismissButton = { TextButton({ editing = false }) { Text("Cancelar") } },
        title = { Text("Letra") },
        text = { OutlinedTextField(draft, { draft = it }, Modifier.fillMaxWidth().heightIn(min = 240.dp), placeholder = { Text("Pegá la letra acá") }) }
    )
}

// ───────────── ajustes y tema ─────────────

@Composable
private fun SettingsScreen(prefs: Prefs, mix: Boolean, silence: Boolean, cfOn: Boolean, cfSec: Int, sleepMin: Int,
                           onSleep: (Int) -> Unit, hiddenSongs: List<Song>, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var showHidden by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") }
            Text("Ajustes de reproducción", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        SwitchRow(Icons.Rounded.Headphones, "Reproduce junto con otras aplicaciones", null, mix) { scope.launch { prefs.setMix(it) } }
        SwitchRow(Icons.Rounded.GraphicEq, "Reproducción sin pausas", "Salta los silencios que haya en las pistas", silence) { scope.launch { prefs.setSilence(it) } }
        SwitchRow(Icons.Rounded.SwapHoriz, "Crossfade", "Mezcla el final de una canción con el inicio de la siguiente", cfOn) { scope.launch { prefs.setCrossfadeOn(it) } }
        if (cfOn) Row(Modifier.fillMaxWidth().padding(start = 46.dp), verticalAlignment = Alignment.CenterVertically) {
            Slider(cfSec.toFloat(), { scope.launch { prefs.setCrossfadeSec(it.roundToInt()) } }, Modifier.weight(1f), valueRange = 1f..12f, steps = 10)
            Text("${cfSec}s", Modifier.padding(start = 12.dp), fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Text("Temporizador de apagado", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0, 15, 30, 45, 60).forEach { m ->
                FilterChip(selected = sleepMin == m, onClick = { onSleep(m) }, label = { Text(if (m == 0) "Apagado" else "$m min") })
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().clickable { showHidden = true }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.VisibilityOff, null, Modifier.size(30.dp), tint = cs.onSurfaceVariant)
            Text("Canciones ocultas (${hiddenSongs.size})", Modifier.padding(start = 16.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.navigationBarsPadding())
    }
    if (showHidden) AlertDialog(
        onDismissRequest = { showHidden = false },
        confirmButton = { TextButton({ showHidden = false }) { Text("Cerrar") } },
        title = { Text("Canciones ocultas") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (hiddenSongs.isEmpty()) Text("No hay canciones ocultas.")
                hiddenSongs.forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(s.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        TextButton({ scope.launch { prefs.unhide(s.id) } }) { Text("Mostrar") }
                    }
                }
            }
        }
    )
}

@Composable
private fun ThemeScreen(prefs: Prefs, mode: String, seed: Int, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val c = LocalCorner.current
    val artOn = LocalArtTheme.current
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") }
            Text("Tema", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(cr(c, 32))).background(cs.secondaryContainer).padding(4.dp)) {
            if (seed == -3) {
                Row(Modifier.weight(1f).clip(RoundedCornerShape(cr(c, 28))).background(cs.primary).padding(vertical = 14.dp, horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.DarkMode, null, Modifier.size(22.dp), tint = cs.onPrimary)
                    Text("Halloween", Modifier.padding(start = 10.dp), fontWeight = FontWeight.Bold, color = cs.onPrimary)
                }
            } else listOf(Triple("dark", "Oscuro", Icons.Rounded.DarkMode), Triple("light", "Claro", Icons.Rounded.LightMode),
                Triple("system", "Sistema", Icons.Rounded.BrightnessAuto)).forEach { (k, label, icon) ->
                val sel = mode == k
                Row(Modifier.weight(1f).clip(RoundedCornerShape(cr(c, 28))).background(if (sel) cs.primary else Color.Transparent)
                    .clickable { scope.launch { prefs.setMode(k) } }.padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, null, Modifier.size(20.dp), tint = if (sel) cs.onPrimary else cs.onSecondaryContainer)
                    Spacer(Modifier.width(6.dp))
                    Text(label, fontWeight = FontWeight.Bold, color = if (sel) cs.onPrimary else cs.onSecondaryContainer)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        val all = (if (Build.VERSION.SDK_INT >= 31) listOf(-1) else emptyList()) + listOf(-2) + seeds.indices.toList() + listOf(-3)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(all) { i ->
                val sel = seed == i
                val fill = when (i) { -1 -> cs.surfaceVariant; -2 -> Color(0xFFFF7849); -3 -> Color.Black; else -> seeds[i] }
                Box(Modifier.size(64.dp).clip(CircleShape).background(fill)
                    .then(if (i == -3) Modifier.border(2.dp, Color(0xFFFF8800), CircleShape) else Modifier)
                    .then(if (sel) Modifier.border(3.dp, cs.onBackground, CircleShape) else Modifier)
                    .clickable { scope.launch { prefs.setSeed(i) } }, contentAlignment = Alignment.Center) {
                    if (sel) Icon(Icons.Rounded.Check, null, tint = if (i == -1) cs.onSurface else Color.White)
                    else if (i == -1) Icon(Icons.Rounded.AutoAwesome, null, tint = cs.onSurface)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        val startCorner = c
        var v by remember { mutableFloatStateOf(startCorner.toFloat()) }
        Text("Redondeo de esquinas", fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Slider(v, { v = it; scope.launch { prefs.setCorner(it.toInt()) } }, Modifier.weight(1f), valueRange = 0f..100f)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(cr(v.toInt(), 28))).background(cs.primary))
        }
        SwitchRow(Icons.Rounded.Palette, "Colores según la portada",
            "La pantalla de reproducción, el mini reproductor y la notificación toman los colores del álbum", artOn) { scope.launch { prefs.setArt(it) } }
        Spacer(Modifier.height(8.dp))
    }
}
