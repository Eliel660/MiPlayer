package com.example.miplayer

import android.content.Context
import android.media.audiofx.Equalizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Qué canción y qué posición mostrar en pantalla mientras dura la mezcla (la nueva), aunque el principal siga en la vieja. */
object CrossView {
    @Volatile var item: MediaItem? = null
    @Volatile var posMs = 0L
    @Volatile var durMs = 1L
    @Volatile var version = 0

    fun show(i: MediaItem, dur: Long) { posMs = 0L; durMs = if (dur == C.TIME_UNSET) 1L else dur; item = i; version++ }
    fun clear() { if (item != null) { item = null; version++ } }
    fun sync(pos: Long, dur: Long) { posMs = pos; if (dur != C.TIME_UNSET) durMs = dur }
}

/**
 * Crossfade con los papeles invertidos. Ideas clave:
 *  1) La canción que SE VA sigue sonando en el reproductor principal, sin copias ni cortes: solo le baja el volumen.
 *  2) La canción que VIENE suena en un segundo reproductor, que la empieza desde cero (ya cargada de antemano).
 *  3) La mezcla la maneja el reloj de la canción nueva: entra siempre desde silencio, aunque tarde en arrancar.
 *  4) Al terminar la mezcla, el principal salta a la canción nueva, cerca de su comienzo (donde un salto en el
 *     archivo es mucho más preciso que a mitad de canción), se alinea en silencio con el segundo y recién ahí se
 *     hace el traspaso corto entre las dos copias de la MISMA canción (lineal, sin salto).
 */
class Crossfader(
    private val ctx: Context,
    private val main: ExoPlayer,
    private val attrs: AudioAttributes,
    private val equalizer: () -> Equalizer?,
    private val seconds: () -> Int,
    private val shuffleOn: () -> Boolean,
    private val slowMix: () -> Boolean = { false }
) {
    private enum class Phase { IDLE, READY, MIX, HAND, SWAP }

    private var phase = Phase.IDLE
    private var helper: ExoPlayer? = null      // reproduce la canción que viene
    private var helperEq: Equalizer? = null
    private var oldId = ""
    private var nextId = ""
    private var nextIndex = 0
    private var phaseAt = 0L
    private var mixLeft0 = 0L
    private var mixMs = 1L
    private var stable = 0
    private var mainSpeed = 1f

    /** Cada cuánto conviene que corra el reloj: más seguido mientras se mezcla. */
    fun interval(): Long = when (phase) {
        Phase.IDLE -> 150L
        Phase.READY, Phase.HAND -> 40L
        else -> 20L
    }

    fun tick(now: Long) {
        when (phase) {
            Phase.MIX -> mix(now)
            Phase.HAND -> hand(now)
            Phase.SWAP -> swap(now)
            else -> watch(now)
        }
    }

    private fun watch(now: Long) {
        val sec = seconds()
        if (sec <= 0 || main.mediaItemCount < 2 || !main.hasNextMediaItem() || main.repeatMode == Player.REPEAT_MODE_ONE) {
            if (phase != Phase.IDLE) release()
            return
        }
        val ms = sec * 1000L
        val dur = main.duration
        if (dur == C.TIME_UNSET || dur < ms + 9000L) { if (phase != Phase.IDLE) release(); return }
        val left = dur - main.currentPosition
        val id = main.currentMediaItem?.mediaId ?: ""
        if (phase != Phase.IDLE) {
            // si cambió la canción, la siguiente o movieron la barra, se descarta lo preparado
            val ni = main.nextMediaItemIndex
            val nid = if (ni != C.INDEX_UNSET) main.getMediaItemAt(ni).mediaId else ""
            if (id != oldId || nid != nextId || left > ms + 9000L) { release(); return }
        }
        when (phase) {
            Phase.IDLE -> if (main.isPlaying && left in (ms + 4000L)..(ms + 7500L)) prepare(id)
            Phase.READY -> if (left <= ms + 300L) {
                if (helper?.playbackState == Player.STATE_READY) startMix(now, left, ms)
                else if (left <= ms - 800L) release()          // no llegó a cargar a tiempo: esta vez sin mezcla
            }
            else -> {}
        }
    }

    /** Unos segundos antes: deja listo, y ya cargado, el segundo reproductor con la canción que viene. */
    private fun prepare(id: String) {
        val ni = main.nextMediaItemIndex
        if (ni == C.INDEX_UNSET) return
        val item = main.getMediaItemAt(ni)
        val h = ExoPlayer.Builder(ctx).setAudioAttributes(attrs, false).build()
        h.volume = 0f
        h.setMediaItem(item)
        h.prepare()
        h.playWhenReady = false
        // mismo ecualizador que el principal, para que no se note el cambio
        helperEq = equalizer()?.let { src ->
            runCatching {
                Equalizer(0, h.audioSessionId).also { e2 ->
                    e2.enabled = true
                    for (b in 0 until src.numberOfBands) e2.setBandLevel(b.toShort(), src.getBandLevel(b.toShort()))
                }
            }.getOrNull()
        }
        helper = h; oldId = id; nextId = item.mediaId; nextIndex = ni; phase = Phase.READY
    }

    private fun startMix(now: Long, left: Long, ms: Long) {
        val h = helper ?: run { release(); return }
        mixMs = min(ms, left - 450L)                   // la mezcla termina antes de que termine la canción que se va
        if (mixMs < 1500L) { release(); return }
        mixLeft0 = left
        h.volume = 0f
        h.playWhenReady = main.playWhenReady
        CrossView.show(main.getMediaItemAt(nextIndex), h.duration)   // la pantalla ya muestra la canción nueva
        phase = Phase.MIX; phaseAt = now
    }

    /** La canción nueva sube con SU reloj; la que se va (en el principal) baja. Potencia constante. */
    private fun mix(now: Long) {
        val h = helper ?: run { release(); return }
        val dur = main.duration
        val id = main.currentMediaItem?.mediaId ?: ""
        val left = if (dur == C.TIME_UNSET) 0L else dur - main.currentPosition
        // cambiaron de canción o movieron la barra: se corta la mezcla
        if (id != oldId || dur == C.TIME_UNSET || left > mixLeft0 + 1500L) { release(); return }
        h.playWhenReady = main.playWhenReady
        CrossView.sync(h.currentPosition, h.duration)
        val started = h.isPlaying && h.currentPosition > 0
        val f = if (started) (h.currentPosition.toFloat() / mixMs).coerceIn(0f, 1f) else 0f
        val ff = if (left < 200L) 1f else f
        main.volume = sqrt(1f - ff)
        h.volume = sqrt(ff)
        if (slowMix()) {
            val target = ((1f - 0.07f * ff) * 100f).roundToInt() / 100f      // la que se va se frena de 1,00 a 0,93
            if (target != mainSpeed) { main.setPlaybackParameters(PlaybackParameters(target)); mainSpeed = target }
        }
        if (ff >= 1f) beginHand(now)
    }

    /** Termina la mezcla: el principal salta a la canción nueva, en silencio, al punto donde va el segundo. */
    private fun beginHand(now: Long) {
        val h = helper ?: run { release(); return }
        if (nextIndex >= main.mediaItemCount || main.getMediaItemAt(nextIndex).mediaId != nextId) { release(); return }
        val wasLast = main.currentMediaItemIndex == main.mediaItemCount - 1
        if (mainSpeed != 1f) { main.setPlaybackParameters(PlaybackParameters(1f)); mainSpeed = 1f }
        main.volume = 0f
        main.seekTo(nextIndex, h.currentPosition + 150L)
        if (wasLast && shuffleOn()) shuffleRest(main)
        phase = Phase.HAND; phaseAt = now; stable = 0
    }

    /** Alineado en silencio: el principal corrige su velocidad hasta quedar a pocos milisegundos del segundo. */
    private fun hand(now: Long) {
        val h = helper ?: run { release(); return }
        if (main.currentMediaItem?.mediaId != nextId) { release(); return }   // el usuario cambió de canción
        h.playWhenReady = main.playWhenReady
        CrossView.sync(h.currentPosition, h.duration)
        var aligned = false
        if (h.isPlaying && main.isPlaying) {
            val err = main.currentPosition - h.currentPosition      // positivo: el principal va adelantado
            val target = if (abs(err) <= 8L) 1f else (1f - err / 500f).coerceIn(0.85f, 1.2f)
            if (target != mainSpeed) { main.setPlaybackParameters(PlaybackParameters(target)); mainSpeed = target }
            if (abs(err) <= 10L && mainSpeed == 1f) stable++ else stable = 0
            aligned = stable >= 10
        }
        val elapsed = now - phaseAt
        if (aligned || (elapsed > 6000L && main.isPlaying)) {
            if (mainSpeed != 1f) { main.setPlaybackParameters(PlaybackParameters(1f)); mainSpeed = 1f }
            phase = Phase.SWAP; phaseAt = now
        } else if (elapsed > 15000L) {
            release()
        }
    }

    /** Traspaso de 80 ms entre las dos copias de la misma canción. Lineal: la suma de volúmenes no cambia. */
    private fun swap(now: Long) {
        val h = helper ?: run { release(); return }
        val f = ((now - phaseAt) / 80f).coerceIn(0f, 1f)
        main.volume = f
        h.volume = 1f - f
        h.playWhenReady = main.playWhenReady
        CrossView.sync(h.currentPosition, h.duration)
        if (f >= 1f) release()
    }

    private fun release() {
        CrossView.clear()
        runCatching { helper?.release() }; helper = null
        runCatching { helperEq?.release() }; helperEq = null
        if (mainSpeed != 1f) { runCatching { main.setPlaybackParameters(PlaybackParameters(1f)) }; mainSpeed = 1f }
        phase = Phase.IDLE; stable = 0
        runCatching { main.volume = 1f }
    }
}
