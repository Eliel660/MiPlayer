package com.example.miplayer

import android.content.Context
import android.net.Uri
import java.io.DataInputStream
import java.io.File

/** Letras y anotaciones guardadas por la persona (un archivo de texto por canción). */
object Store {
    private fun f(ctx: Context, dir: String, id: Long): File = File(File(ctx.filesDir, dir).apply { mkdirs() }, "$id.txt")
    fun read(ctx: Context, dir: String, id: Long): String =
        runCatching { f(ctx, dir, id).takeIf { it.exists() }?.readText() ?: "" }.getOrDefault("")
    fun write(ctx: Context, dir: String, id: Long, text: String) {
        runCatching { val file = f(ctx, dir, id); if (text.isBlank()) file.delete() else file.writeText(text) }
    }
}

private val tsRegex = Regex("""\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\]""")
private val tagRegex = Regex("""^\[[A-Za-z]+:[^\]]*\]\s*$""")

/** Saca las marcas de tiempo de un .lrc para dejar solo el texto. */
fun cleanLyrics(raw: String): String = raw.replace("\r\n", "\n").replace('\r', '\n').lines()
    .filterNot { tagRegex.matches(it.trim()) }
    .joinToString("\n") { tsRegex.replace(it, "").trim() }
    .trim()

/** Primero la letra guardada por la persona; si no hay, la que trae el archivo (MP3). */
fun loadLyrics(ctx: Context, s: Song): String {
    val saved = Store.read(ctx, "lyrics", s.id)
    if (saved.isNotBlank()) return cleanLyrics(saved)
    return cleanLyrics(id3Lyrics(ctx, s.uri) ?: "")
}

private fun synch(b: ByteArray, o: Int) = ((b[o].toInt() and 0x7F) shl 21) or ((b[o + 1].toInt() and 0x7F) shl 14) or
    ((b[o + 2].toInt() and 0x7F) shl 7) or (b[o + 3].toInt() and 0x7F)
private fun be32(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or
    ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)

fun id3Lyrics(ctx: Context, uri: Uri): String? = runCatching {
    ctx.contentResolver.openInputStream(uri)?.use { raw ->
        val din = DataInputStream(raw.buffered())
        val h = ByteArray(10); din.readFully(h)
        if (String(h, 0, 3, Charsets.ISO_8859_1) != "ID3") return@use null
        val ver = h[3].toInt()
        if (ver < 3) return@use null
        val size = synch(h, 6).coerceIn(0, 8_000_000)
        val tag = ByteArray(size); din.readFully(tag)
        var p = 0
        if ((h[5].toInt() and 0x40) != 0 && tag.size >= 4) p = if (ver == 4) synch(tag, 0) else be32(tag, 0) + 4
        while (p + 10 <= tag.size) {
            if (tag[p].toInt() == 0) break
            val id = String(tag, p, 4, Charsets.ISO_8859_1)
            val fs = if (ver == 4) synch(tag, p + 4) else be32(tag, p + 4)
            if (fs <= 0 || p + 10 + fs > tag.size) break
            if (id == "USLT") return@use decodeUslt(tag, p + 10, p + 10 + fs)
            p += 10 + fs
        }
        null
    }
}.getOrNull()

private fun decodeUslt(t: ByteArray, s: Int, e: Int): String? {
    if (e - s < 5) return null
    val enc = t[s].toInt()
    var i = s + 4
    val start: Int
    if (enc == 0 || enc == 3) { while (i < e && t[i].toInt() != 0) i++; start = i + 1 }
    else { while (i + 1 < e && !(t[i].toInt() == 0 && t[i + 1].toInt() == 0)) i += 2; start = i + 2 }
    if (start >= e) return null
    val cs = when (enc) { 0 -> Charsets.ISO_8859_1; 1 -> Charsets.UTF_16; 2 -> Charsets.UTF_16BE; else -> Charsets.UTF_8 }
    return String(t, start, e - start, cs).trim('\u0000', ' ', '\n', '\r').ifBlank { null }
}
