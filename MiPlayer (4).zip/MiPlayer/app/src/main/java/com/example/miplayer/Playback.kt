@file:OptIn(UnstableApi::class)
package com.example.miplayer

import android.app.Notification
import android.content.Context
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.collect.ImmutableList
import java.util.concurrent.Executors

/** Un solo reproductor compartido por la UI, la notificación y el ecualizador. También hace el crossfade. */
object PlayerHolder {
    private var player: ExoPlayer? = null
    private var eq: Equalizer? = null
    private lateinit var app: Context
    private val handler = Handler(Looper.getMainLooper())
    private val attrs = AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()
    private var mixOn = false
    private var silenceOn = false

    /** Segundos de crossfade (0 = apagado). */
    @Volatile var crossfadeSec = 0
    private var tail: ExoPlayer? = null
    private var fadeStart = 0L
    private var fadeMs = 1L

    private val ticker = object : Runnable {
        override fun run() { runCatching { tick() }; handler.postDelayed(this, 150) }
    }

    fun get(ctx: Context): ExoPlayer {
        player?.let { return it }
        app = ctx.applicationContext
        val p = ExoPlayer.Builder(app).setAudioAttributes(attrs, !mixOn).setHandleAudioBecomingNoisy(true).build()
        p.setSkipSilenceEnabled(silenceOn)
        player = p
        handler.post(ticker)
        return p
    }

    fun applyMix(mix: Boolean) { mixOn = mix; player?.setAudioAttributes(attrs, !mix) }
    fun applySilence(on: Boolean) { silenceOn = on; player?.setSkipSilenceEnabled(on) }

    fun equalizer(ctx: Context): Equalizer =
        eq ?: Equalizer(0, get(ctx).audioSessionId).apply { enabled = true }.also { eq = it }

    private fun tick() {
        val p = player ?: return
        val t = tail
        if (t != null) {
            val f = ((SystemClock.elapsedRealtime() - fadeStart).toFloat() / fadeMs).coerceIn(0f, 1f)
            p.volume = f
            t.volume = 1f - f
            t.playWhenReady = p.isPlaying
            if (f >= 1f) { t.release(); tail = null; p.volume = 1f }
            return
        }
        val sec = crossfadeSec
        if (sec <= 0 || !p.isPlaying || p.repeatMode == Player.REPEAT_MODE_ONE || !p.hasNextMediaItem()) return
        val dur = p.duration
        if (dur == C.TIME_UNSET || dur < sec * 2500L) return
        val left = dur - p.currentPosition
        if (left in 1..(sec * 1000L)) startFade(p, sec * 1000L)
    }

    /** Un segundo reproductor sigue con el final de la canción actual (bajando) mientras la siguiente arranca (subiendo). */
    private fun startFade(p: ExoPlayer, ms: Long) {
        val item = p.currentMediaItem ?: return
        val t = ExoPlayer.Builder(app).setAudioAttributes(attrs, false).build()
        t.setMediaItem(item); t.prepare(); t.seekTo(p.currentPosition); t.volume = 1f; t.play()
        tail = t; fadeStart = SystemClock.elapsedRealtime(); fadeMs = ms
        p.volume = 0f
        p.seekToNextMediaItem()
    }
}

/** Le pone a la notificación el color de la portada. */
class ArtColorProvider(private val ctx: Context) : MediaNotification.Provider {
    private val inner = DefaultMediaNotificationProvider(ctx).also { it.setSmallIcon(R.drawable.ic_stat) }
    private val worker = Executors.newSingleThreadExecutor()

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        val n = inner.createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
        val item = mediaSession.player.currentMediaItem
        if (item != null && ArtColors.enabled) {
            val key = item.mediaId
            val c = ArtColors.cached(key)
            if (c != null) {
                n.notification.color = c
                n.notification.extras.putBoolean(Notification.EXTRA_COLORIZED, true)
            } else if (!ArtColors.has(key)) {
                val uri = item.localConfiguration?.uri
                val albumId = item.mediaMetadata.artworkUri?.lastPathSegment?.toLongOrNull() ?: 0L
                if (uri != null) worker.execute {
                    if (ArtColors.compute(ctx, key, uri, albumId) != null) {
                        Handler(Looper.getMainLooper()).post {
                            onNotificationChangedCallback.onNotificationChanged(
                                createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
                            )
                        }
                    }
                }
            }
        }
        return n
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        inner.handleCustomCommand(session, action, extras)
}

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        setMediaNotificationProvider(ArtColorProvider(this))
        session = MediaSession.Builder(this, PlayerHolder.get(this)).build()
        addSession(session!!)
    }

    override fun onGetSession(info: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        session?.release(); session = null
        super.onDestroy()
    }
}
