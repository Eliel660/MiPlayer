@file:OptIn(UnstableApi::class)
package com.example.miplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.PlaybackParameters
import kotlin.math.abs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.collect.ImmutableList
import java.util.concurrent.Executors

/** Mezcla al azar todo lo que viene después de la canción que suena, sin cortarla. */
fun shuffleRest(p: Player) {
    val n = p.mediaItemCount
    if (n < 2) return
    val cur = p.currentMediaItemIndex
    val others = (0 until n).filter { it != cur }.map { p.getMediaItemAt(it) }.shuffled()
    p.removeMediaItems(cur + 1, n)
    p.removeMediaItems(0, cur)
    p.addMediaItems(others)
}

/** Deja la fila en el orden de la biblioteca, sin cortar la canción que suena. */
fun orderQueue(p: Player, order: List<Song>) {
    val n = p.mediaItemCount
    if (n < 2) return
    val rank = HashMap<String, Int>()
    order.forEachIndexed { i, s -> rank[s.id.toString()] = i }
    val cur = p.currentMediaItemIndex
    val curId = p.getMediaItemAt(cur).mediaId
    val items = (0 until n).map { p.getMediaItemAt(it) }.sortedBy { rank[it.mediaId] ?: Int.MAX_VALUE }
    val ci = items.indexOfFirst { it.mediaId == curId }
    if (ci < 0) return
    p.removeMediaItems(cur + 1, n)
    p.removeMediaItems(0, cur)
    p.addMediaItems(0, items.subList(0, ci).toList())
    p.addMediaItems(items.subList(ci + 1, items.size).toList())
}

/** Un solo reproductor compartido por la UI, la notificación y el ecualizador. El crossfade lo hace Crossfader. */
object PlayerHolder {
    private var player: ExoPlayer? = null
    private var eq: Equalizer? = null
    private lateinit var app: Context
    private var xf: Crossfader? = null
    private val handler = Handler(Looper.getMainLooper())
    private val attrs = AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build()
    private var mixOn = false
    private var silenceOn = false
    private var lastIdx = -1

    /** Segundos de crossfade (0 = apagado). */
    @Volatile var crossfadeSec = 0
    @Volatile var slowMix = true   // la canción que se va se ralentiza un poco al mezclar
    /** Si está en aleatorio, cada vuelta de la fila se vuelve a mezclar. */
    @Volatile var shuffleMode = false

    // contador de reproducciones
    @Volatile var onCounted: (() -> Unit)? = null

    // retomar al conectar auriculares
    @Volatile private var resumeOnHeadset = true
    private var pausedByUnplug = 0L   // 0 = no se pausó por desconexión
    private var trackId = ""
    private var playedMs = 0L
    private var counted = false
    private var lastCountTick = 0L

    private val ticker = object : Runnable {
        override fun run() { runCatching { tick() }; handler.postDelayed(this, xf?.interval() ?: 150L) }
    }

    fun get(ctx: Context): ExoPlayer {
        player?.let { return it }
        app = ctx.applicationContext
        val p = ExoPlayer.Builder(app).setAudioAttributes(attrs, !mixOn).setHandleAudioBecomingNoisy(true).build()
        p.setSkipSilenceEnabled(silenceOn)
        p.repeatMode = Player.REPEAT_MODE_ALL   // la fila siempre da la vuelta
        p.addListener(object : Player.Listener {
            override fun onTimelineChanged(timeline: Timeline, reason: Int) { lastIdx = p.currentMediaItemIndex }
            override fun onEvents(player: Player, events: Player.Events) { WidgetUpdater.request(app, player) }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                pausedByUnplug = if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_BECOMING_NOISY) SystemClock.elapsedRealtime() else 0L
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val idx = p.currentMediaItemIndex
                val wrapped = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && lastIdx >= 0 &&
                    lastIdx == p.mediaItemCount - 1 && idx == 0 && p.mediaItemCount > 1
                lastIdx = idx
                trackId = ""
                if (wrapped && shuffleMode) shuffleRest(p)
            }
        })
        xf = Crossfader(app, p, attrs, { eq }, { crossfadeSec }, { shuffleMode }, { slowMix })
        val headsets = setOf(AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_BLE_HEADSET)
        (app.getSystemService(Context.AUDIO_SERVICE) as AudioManager).registerAudioDeviceCallback(object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
                if (!resumeOnHeadset || pausedByUnplug == 0L || p.mediaItemCount == 0) return
                if (SystemClock.elapsedRealtime() - pausedByUnplug > 10 * 60_000L) { pausedByUnplug = 0L; return }
                if (addedDevices.any { it.isSink && it.type in headsets }) { pausedByUnplug = 0L; p.play() }
            }
        }, handler)
        player = p
        handler.post(ticker)
        return p
    }

    fun applyResume(on: Boolean) { resumeOnHeadset = on }
    fun applySlow(on: Boolean) { slowMix = on }
    fun applyMix(mix: Boolean) { mixOn = mix; player?.setAudioAttributes(attrs, !mix) }
    fun applySilence(on: Boolean) { silenceOn = on; player?.setSkipSilenceEnabled(on) }

    fun equalizer(ctx: Context): Equalizer =
        eq ?: Equalizer(0, get(ctx).audioSessionId).apply { enabled = true }.also { eq = it }

    private fun tick() {
        val p = player ?: return
        val now = SystemClock.elapsedRealtime()
        countPlay(p, now)
        xf?.tick(now)
    }

    private fun countPlay(p: ExoPlayer, now: Long) {
        val id = p.currentMediaItem?.mediaId ?: ""
        if (id != trackId) { trackId = id; playedMs = 0L; counted = false }
        if (p.isPlaying && lastCountTick != 0L) playedMs += (now - lastCountTick).coerceAtMost(500L)
        lastCountTick = now
        if (!counted && id.isNotEmpty() && playedMs >= 20_000L) {
            counted = true
            id.toLongOrNull()?.let { Plays.inc(app, it); onCounted?.invoke() }
        }
    }
}

/** Le pone a la notificación el color de la portada. */
class ArtColorProvider(private val ctx: Context) : MediaNotification.Provider {
    private val inner = DefaultMediaNotificationProvider(ctx).also { it.setSmallIcon(R.drawable.ic_stat) }
    private val worker = Executors.newSingleThreadExecutor()

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        val n = inner.createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
        runCatching {
            val item = mediaSession.player.currentMediaItem
            if (item != null && ArtColors.enabled) {
                val key = item.mediaId
                val c = ArtColors.cached(key)
                if (c != null) {
                    n.notification.color = c
                    n.notification.extras.putBoolean(Notification.EXTRA_COLORIZED, true)
                } else if (!ArtColors.has(key)) {
                    val uri = item.localConfiguration?.uri
                    val albumId = item.mediaMetadata.artworkUri?.lastPathSegment?.toLongOrNull() ?: 0L
                    if (uri != null) worker.execute {
                        if (ArtColors.compute(ctx, key, uri, albumId) != null) {
                            Handler(Looper.getMainLooper()).post {
                                onNotificationChangedCallback.onNotificationChanged(
                                    createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
                                )
                            }
                        }
                    }
                }
            }
        }
        return n
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        inner.handleCustomCommand(session, action, extras)
}

/** Notificación chica con el título de la canción. En Android 16 y en algunos sistemas se muestra como cápsula arriba. */
class ChipNotifier(private val ctx: Context, private val p: Player) : Player.Listener {
    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    @Volatile var enabled = true

    init {
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "Título en la barra de estado", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            )
        }
        p.addListener(this)
    }

    override fun onEvents(player: Player, events: Player.Events) { refresh() }

    fun refresh() {
        runCatching {
            val item = p.currentMediaItem
            if (!enabled || item == null || !p.isPlaying || !NotificationManagerCompat.from(ctx).areNotificationsEnabled()) {
                nm.cancel(ID); return
            }
            val title = item.mediaMetadata.title?.toString() ?: return
            val artist = item.mediaMetadata.artist?.toString() ?: ""
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val extras = Bundle().apply {
                putBoolean("android.requestPromotedOngoing", true)   // pide aparecer como cápsula (Android 16)
                putString("android.shortCriticalText", title)
            }
            val n = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title).setContentText(artist)
                .setColor(ArtColors.cached(item.mediaId) ?: 0xFFFF7849.toInt())
                .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false).setSilent(true)
                .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                .setContentIntent(open)
                .addExtras(extras)
                .build()
            nm.notify(ID, n)
        }
    }

    fun release() { p.removeListener(this); nm.cancel(ID) }

    companion object { const val CH = "titulo_barra"; const val ID = 4242 }
}

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var chip: ChipNotifier? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        setMediaNotificationProvider(ArtColorProvider(this))
        val player = PlayerHolder.get(this)
        session = MediaSession.Builder(this, player).build()
        addSession(session!!)
        val c = ChipNotifier(this, player)
        chip = c
        scope.launch { Prefs(this@PlaybackService).chip.collect { c.enabled = it; c.refresh() } }
    }

    override fun onGetSession(info: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        scope.cancel()
        chip?.release(); chip = null
        session?.release(); session = null
        super.onDestroy()
    }
}
