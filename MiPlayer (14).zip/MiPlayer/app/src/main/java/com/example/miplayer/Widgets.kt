package com.example.miplayer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import androidx.media3.common.Player
import java.util.concurrent.Executors

private class WState(val title: String, val artist: String, val playing: Boolean, val uri: Uri?, val albumId: Long)

/** Mantiene al día los widgets de la pantalla principal (reproductor y mini). */
object WidgetUpdater {
    private val exec = Executors.newSingleThreadExecutor()
    private var last = ""

    /** Se llama desde el hilo principal: lee el estado del reproductor y arma los widgets en segundo plano. */
    fun request(ctx: Context, p: Player, force: Boolean = false) {
        val item = p.currentMediaItem
        val st = WState(
            item?.mediaMetadata?.title?.toString() ?: "", item?.mediaMetadata?.artist?.toString() ?: "", p.isPlaying,
            item?.localConfiguration?.uri, item?.mediaMetadata?.artworkUri?.lastPathSegment?.toLongOrNull() ?: 0L
        )
        val key = "${st.title}|${st.artist}|${st.playing}|${st.uri}"
        if (!force && key == last) return
        last = key
        val app = ctx.applicationContext
        exec.execute { runCatching { push(app, st) } }
    }

    private fun push(ctx: Context, st: WState) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val cover = st.uri?.let { loadArtBitmap(ctx, it, st.albumId, 256) }
        val targets = listOf(PlayerWidget::class.java to R.layout.widget_player, PlayerWidgetMini::class.java to R.layout.widget_mini)
        for ((cls, layout) in targets) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isEmpty()) continue
            val v = RemoteViews(ctx.packageName, layout)
            v.setTextViewText(R.id.w_title, st.title.ifBlank { "M!Perla" })
            v.setTextViewText(R.id.w_artist, st.artist)
            if (cover != null) v.setImageViewBitmap(R.id.w_cover, cover) else v.setImageViewResource(R.id.w_cover, R.drawable.ic_stat)
            v.setImageViewResource(R.id.w_play, if (st.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            v.setOnClickPendingIntent(R.id.w_prev, action(ctx, "PREV"))
            v.setOnClickPendingIntent(R.id.w_play, action(ctx, "TOGGLE"))
            v.setOnClickPendingIntent(R.id.w_next, action(ctx, "NEXT"))
            v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            mgr.updateAppWidget(ids, v)
        }
    }

    private fun action(ctx: Context, act: String): PendingIntent = PendingIntent.getBroadcast(
        ctx, act.hashCode(), Intent(ctx, WidgetActionReceiver::class.java).setAction(act),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

class PlayerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.request(context, PlayerHolder.get(context), true)
    }
}

class PlayerWidgetMini : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.request(context, PlayerHolder.get(context), true)
    }
}

/** Botones de los widgets: anterior, reproducir/pausar y siguiente. */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = PlayerHolder.get(context)
        when (intent.action) {
            "PREV" -> p.seekToPrevious()
            "NEXT" -> p.seekToNext()
            "TOGGLE" -> if (p.mediaItemCount > 0) { if (p.isPlaying) p.pause() else p.play() }
        }
    }
}
