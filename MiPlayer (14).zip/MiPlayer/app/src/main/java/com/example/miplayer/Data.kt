package com.example.miplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

data class Song(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val durationMs: Long, val albumId: Long, val track: Int)

fun loadSongs(ctx: Context): List<Song> {
    val out = mutableListOf<Song>()
    val cols = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID,
        MediaStore.Audio.Media.TRACK
    )
    ctx.contentResolver.query(
        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.DATE_ADDED} DESC"
    )?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            out += Song(id, c.getString(1) ?: "Sin título", c.getString(2) ?: "Desconocido", c.getString(3) ?: "",
                ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id), c.getLong(4), c.getLong(5), c.getInt(6))
        }
    }
    // Cambios hechos desde la app: se aplican enseguida, sin esperar a que Android actualice su base
    val ov = Overrides.read(ctx)
    if (ov.isEmpty()) return out
    val keep = HashMap(ov)
    var changed = false
    val res = out.map { sg ->
        val o = ov[sg.id]
        if (o == null) sg
        else if (sg.title == o.first && sg.artist == o.second && sg.album == o.third) { keep.remove(sg.id); changed = true; sg }
        else sg.copy(title = o.first, artist = o.second, album = o.third)
    }
    if (changed) Overrides.write(ctx, keep)
    return res
}

private val Context.ds by preferencesDataStore("prefs")
private val THEME = stringPreferencesKey("theme")
private val SEED = intPreferencesKey("seed")
private val CORNER = intPreferencesKey("corner")
private val SORT = stringPreferencesKey("sort")
private val LISTS = stringPreferencesKey("playlists")
private val HIDDEN = stringSetPreferencesKey("hidden")
private val ART = booleanPreferencesKey("arttheme")
private val MIX = booleanPreferencesKey("mix")
private val SILENCE = booleanPreferencesKey("silence")
private val CF_ON = booleanPreferencesKey("cfon")
private val CF_SEC = intPreferencesKey("cfsec")
private val CHIP = booleanPreferencesKey("chip")
private val NOTE_STYLE = stringPreferencesKey("notestyle")
private val PARTICLES = stringPreferencesKey("particles")
private val VINYLS = stringPreferencesKey("vinyls")
private val TEXT_SCALE = intPreferencesKey("textscale")
private val LYRICS_SCALE = intPreferencesKey("lyricsscale")
private val SHUFFLE = booleanPreferencesKey("shuffle")

class Prefs(private val ctx: Context) {
    val mode = ctx.ds.data.map { it[THEME] ?: "system" }
    val seed = ctx.ds.data.map { it[SEED] ?: -2 }
    val corner = ctx.ds.data.map { it[CORNER] ?: 50 }
    val sort = ctx.ds.data.map { it[SORT] ?: "new" }
    val artTheme = ctx.ds.data.map { it[ART] ?: true }
    val mix = ctx.ds.data.map { it[MIX] ?: false }
    val silence = ctx.ds.data.map { it[SILENCE] ?: false }
    val crossfadeOn = ctx.ds.data.map { it[CF_ON] ?: false }
    val crossfadeSec = ctx.ds.data.map { it[CF_SEC] ?: 6 }
    /** Diseño del vinilo de cada álbum (por nombre de álbum). */
    val vinyls = ctx.ds.data.map { p ->
        val o = JSONObject(p[VINYLS] ?: "{}")
        o.keys().asSequence().associateWith { k -> o.getJSONObject(k).let { j -> VinylDesign(j.getString("t"), j.getInt("a"), j.getInt("b")) } }
    }
    suspend fun saveVinyl(album: String, d: VinylDesign?) {
        ctx.ds.edit { p ->
            val o = JSONObject(p[VINYLS] ?: "{}")
            if (d == null) o.remove(album) else o.put(album, JSONObject().put("t", d.texture).put("a", d.c1).put("b", d.c2))
            p[VINYLS] = o.toString()
        }
    }
    val noteStyle = ctx.ds.data.map { it[NOTE_STYLE] ?: "theme" }
    val particles = ctx.ds.data.map { it[PARTICLES] ?: "both" }
    val chip = ctx.ds.data.map { it[CHIP] ?: true }
    val textScale = ctx.ds.data.map { it[TEXT_SCALE] ?: 100 }
    val lyricsScale = ctx.ds.data.map { it[LYRICS_SCALE] ?: 100 }
    val shuffleOn = ctx.ds.data.map { it[SHUFFLE] ?: false }
    val hidden = ctx.ds.data.map { p -> (p[HIDDEN] ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet() }

    suspend fun setMode(m: String) { ctx.ds.edit { it[THEME] = m } }
    suspend fun setSeed(i: Int) { ctx.ds.edit { it[SEED] = i } }
    suspend fun setCorner(i: Int) { ctx.ds.edit { it[CORNER] = i } }
    suspend fun setSort(v: String) { ctx.ds.edit { it[SORT] = v } }
    suspend fun setArt(v: Boolean) { ctx.ds.edit { it[ART] = v } }
    suspend fun setMix(v: Boolean) { ctx.ds.edit { it[MIX] = v } }
    suspend fun setSilence(v: Boolean) { ctx.ds.edit { it[SILENCE] = v } }
    suspend fun setCrossfadeOn(v: Boolean) { ctx.ds.edit { it[CF_ON] = v } }
    suspend fun setCrossfadeSec(v: Int) { ctx.ds.edit { it[CF_SEC] = v } }
    suspend fun setNoteStyle(v: String) { ctx.ds.edit { it[NOTE_STYLE] = v } }
    suspend fun setParticles(v: String) { ctx.ds.edit { it[PARTICLES] = v } }
    suspend fun setChip(v: Boolean) { ctx.ds.edit { it[CHIP] = v } }
    suspend fun setTextScale(v: Int) { ctx.ds.edit { it[TEXT_SCALE] = v } }
    suspend fun setLyricsScale(v: Int) { ctx.ds.edit { it[LYRICS_SCALE] = v } }
    suspend fun setShuffle(v: Boolean) { ctx.ds.edit { it[SHUFFLE] = v } }
    suspend fun hide(id: Long) { ctx.ds.edit { it[HIDDEN] = (it[HIDDEN] ?: emptySet()) + id.toString() } }
    suspend fun unhide(id: Long) { ctx.ds.edit { it[HIDDEN] = (it[HIDDEN] ?: emptySet()) - id.toString() } }

    /** Listas de reproducción: nombre -> ids de canciones (guardadas como JSON). */
    val playlists = ctx.ds.data.map { p ->
        val o = JSONObject(p[LISTS] ?: "{}")
        o.keys().asSequence().filter { it.isNotBlank() }.associateWith { k -> o.getJSONArray(k).let { a -> List(a.length()) { a.getLong(it) } } }
    }
    suspend fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        ctx.ds.edit { it[LISTS] = o.toString() }
    }
}

/** "Victoria Justice, Ariana Grande" cuenta como dos artistas: la misma canción aparece en los dos. */
fun splitArtists(s: String): List<String> = s.split(',').map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf(s) }
