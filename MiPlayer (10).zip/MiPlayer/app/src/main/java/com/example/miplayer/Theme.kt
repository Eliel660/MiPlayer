package com.example.miplayer

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Colores base. Agregar uno nuevo = agregar una línea acá. */
val seeds = listOf(
    Color(0xFF00C46A), Color(0xFFD64FD0), Color(0xFF2196F3),
    Color(0xFFF04E5E), Color(0xFF14B8A6), Color(0xFFEAB308)
)

/** Redondeo de esquinas elegido por la persona (0 = rectas, 100 = lo más redondo). */
val LocalCorner = compositionLocalOf { 50 }
/** Si está activo, la pantalla de reproducción y el mini reproductor toman los colores de la portada. */
val LocalArtTheme = compositionLocalOf { true }
/** Tamaño de la letra de las canciones, en porcentaje. */
val LocalLyricsScale = compositionLocalOf { 100 }
fun cr(pct: Int, maxDp: Int): Dp = (maxDp * pct / 100f).dp


/**
 * Completa los roles que no definimos a mano (menús, diálogos, interruptores, campos de texto...)
 * para que sigan los colores del tema en vez de quedar con los grises violáceos por defecto.
 */
fun ColorScheme.tuned(): ColorScheme {
    val bg = background
    val on = onBackground
    fun mix(a: Float) = on.copy(alpha = a).compositeOver(bg)
    return copy(
        secondary = primary, onSecondary = onPrimary,
        tertiary = primary, onTertiary = onPrimary,
        tertiaryContainer = secondaryContainer, onTertiaryContainer = onSecondaryContainer,
        surfaceTint = primary,
        inverseSurface = on, inverseOnSurface = bg, inversePrimary = primaryContainer,
        outlineVariant = on.copy(alpha = .28f).compositeOver(bg),
        surfaceDim = bg, surfaceBright = mix(.16f),
        surfaceContainerLowest = bg, surfaceContainerLow = mix(.04f),
        surfaceContainerHigh = mix(.11f), surfaceContainerHighest = mix(.16f)
    )
}

fun schemeFromSeed(seed: Color, dark: Boolean): ColorScheme {
    val hsv = FloatArray(3); android.graphics.Color.colorToHSV(seed.toArgb(), hsv)
    val k = (hsv[1] * 1.6f).coerceIn(0.08f, 1f)
    fun c(s: Float, l: Float) = Color.hsl(hsv[0], (s * k).coerceIn(0f, 1f), l)
    return (if (dark) darkColorScheme(
        primary = c(.85f, .72f), onPrimary = c(.6f, .12f),
        primaryContainer = c(.45f, .26f), onPrimaryContainer = c(.9f, .88f),
        secondaryContainer = c(.30f, .20f), onSecondaryContainer = c(.6f, .90f),
        background = c(.25f, .08f), onBackground = c(.2f, .92f),
        surface = c(.25f, .08f), onSurface = c(.2f, .92f),
        surfaceVariant = c(.25f, .16f), onSurfaceVariant = c(.15f, .72f),
        surfaceContainer = c(.25f, .12f), outline = c(.15f, .45f)
    ) else lightColorScheme(
        primary = c(.70f, .40f), onPrimary = Color.White,
        primaryContainer = c(.80f, .88f), onPrimaryContainer = c(.9f, .15f),
        secondaryContainer = c(.40f, .90f), onSecondaryContainer = c(.6f, .15f),
        background = c(.30f, .97f), onBackground = c(.2f, .10f),
        surface = c(.30f, .97f), onSurface = c(.2f, .10f),
        surfaceVariant = c(.35f, .92f), onSurfaceVariant = c(.15f, .35f),
        surfaceContainer = c(.35f, .94f), outline = c(.15f, .55f)
    )).tuned()
}

/** Tema Naranja: marrón oscuro con naranja vivo. */
fun orangeScheme(dark: Boolean): ColorScheme = (if (dark) darkColorScheme(
    primary = Color(0xFFFF7849), onPrimary = Color(0xFF3A1608),
    primaryContainer = Color(0xFF5E3422), onPrimaryContainer = Color(0xFFFFDBCC),
    secondaryContainer = Color(0xFF47211A), onSecondaryContainer = Color(0xFFFFDBCC),
    background = Color(0xFF221713), onBackground = Color(0xFFF1DFD8),
    surface = Color(0xFF221713), onSurface = Color(0xFFF1DFD8),
    surfaceVariant = Color(0xFF47211A), onSurfaceVariant = Color(0xFFD7C1B8),
    surfaceContainer = Color(0xFF2D1C17), outline = Color(0xFF9F8D85)
) else lightColorScheme(
    primary = Color(0xFFC4501B), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDBCC), onPrimaryContainer = Color(0xFF3A1100),
    secondaryContainer = Color(0xFFF7DDD2), onSecondaryContainer = Color(0xFF2B1810),
    background = Color(0xFFFFF8F5), onBackground = Color(0xFF231915),
    surface = Color(0xFFFFF8F5), onSurface = Color(0xFF231915),
    surfaceVariant = Color(0xFFF5DED5), onSurfaceVariant = Color(0xFF53433D),
    surfaceContainer = Color(0xFFFCEAE2), outline = Color(0xFF85736C)
)).tuned()

/** Tema Halloween: negro puro, naranja fuerte y marrón. Solo existe en oscuro. */
fun halloweenScheme(): ColorScheme = darkColorScheme(
    primary = Color(0xFFFF8800), onPrimary = Color(0xFF3B1D00),
    primaryContainer = Color(0xFF4A2600), onPrimaryContainer = Color(0xFFFFDDB8),
    secondaryContainer = Color(0xFF5C3000), onSecondaryContainer = Color(0xFFFFDDB8),
    background = Color.Black, onBackground = Color(0xFFFFE9D6),
    surface = Color.Black, onSurface = Color(0xFFFFE9D6),
    surfaceVariant = Color(0xFF5C3000), onSurfaceVariant = Color(0xFFFFC48A),
    surfaceContainer = Color(0xFF140A00), outline = Color(0xFFB0753A)
).tuned()

/** Monocromo: negro, blanco y grises. Tiene versión oscura y clara. */
fun monoScheme(dark: Boolean): ColorScheme = (if (dark) darkColorScheme(
    primary = Color(0xFFFDFDFD), onPrimary = Color(0xFF101114),
    primaryContainer = Color(0xFF26272B), onPrimaryContainer = Color(0xFFF1F1F3),
    secondaryContainer = Color(0xFF1C1D21), onSecondaryContainer = Color(0xFFF1F1F3),
    background = Color(0xFF0A0A0B), onBackground = Color(0xFFF1F1F3),
    surface = Color(0xFF0A0A0B), onSurface = Color(0xFFF1F1F3),
    surfaceVariant = Color(0xFF1E1F23), onSurfaceVariant = Color(0xFFC4C5CA),
    surfaceContainer = Color(0xFF151618), outline = Color(0xFF8A8B90)
) else lightColorScheme(
    primary = Color(0xFF000000), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE6E7E8), onPrimaryContainer = Color(0xFF111213),
    secondaryContainer = Color(0xFFE6E7E8), onSecondaryContainer = Color(0xFF111213),
    background = Color(0xFFFDFDFD), onBackground = Color(0xFF111213),
    surface = Color(0xFFFDFDFD), onSurface = Color(0xFF111213),
    surfaceVariant = Color(0xFFE6E7E8), onSurfaceVariant = Color(0xFF47484B),
    surfaceContainer = Color(0xFFF1F2F3), outline = Color(0xFF767779)
)).tuned()

/** Chocolate: fondo de chocolate oscuro con caramelo como color de acento. Solo oscuro. */
fun chocolateScheme(): ColorScheme = darkColorScheme(
    primary = Color(0xFFB98D5F), onPrimary = Color(0xFF2E1707),
    primaryContainer = Color(0xFF815632), onPrimaryContainer = Color(0xFFFFE7D6),
    secondaryContainer = Color(0xFF644226), onSecondaryContainer = Color(0xFFFFE7D6),
    background = Color(0xFF45260F), onBackground = Color(0xFFFFE7D6),
    surface = Color(0xFF45260F), onSurface = Color(0xFFFFE7D6),
    surfaceVariant = Color(0xFF5A3A20), onSurfaceVariant = Color(0xFFE6CBB5),
    surfaceContainer = Color(0xFF3F230F), outline = Color(0xFFB08F72)
).tuned().copy(
    // menús y diálogos más oscuros que el fondo, así el texto caramelo se lee bien
    surfaceContainerLow = Color(0xFF4B2B13), surfaceContainerHigh = Color(0xFF38200E), surfaceContainerHighest = Color(0xFF301A09),
    surfaceBright = Color(0xFF5A3A20), surfaceDim = Color(0xFF2F190A), outlineVariant = Color(0xFF7A5A40)
)

/** Pastel de cumpleaños: rosa pastel sobre malva. Los menús y diálogos son malva más oscuro para que el texto claro se lea. */
fun pastelScheme(): ColorScheme = lightColorScheme(
    primary = Color(0xFFFFDDF1), onPrimary = Color(0xFF3A1630),
    primaryContainer = Color(0xFFF9D0E8), onPrimaryContainer = Color(0xFF3A1630),
    secondaryContainer = Color(0xFFEDAED3), onSecondaryContainer = Color(0xFF3A1630),
    background = Color(0xFFA56E8D), onBackground = Color(0xFFFFF1E6),
    surface = Color(0xFFA56E8D), onSurface = Color(0xFFFFF1E6),
    surfaceVariant = Color(0xFF8F5A78), onSurfaceVariant = Color(0xFFFFE0EE),
    surfaceContainer = Color(0xFF8F5A78), outline = Color(0xFFF4C5E0)
).tuned().copy(
    surfaceContainerLow = Color(0xFF9A6482), surfaceContainerHigh = Color(0xFF85506F), surfaceContainerHighest = Color(0xFF7A4764),
    surfaceBright = Color(0xFFB27C9A), surfaceDim = Color(0xFF8A5673), outlineVariant = Color(0xFFD8A9C6),
    inverseSurface = Color(0xFFFFF1E6), inverseOnSurface = Color(0xFF3A1630)
)

/** Rojo en modo oscuro, corregido. */
fun redDarkScheme(): ColorScheme = darkColorScheme(
    primary = Color(0xFFF45060), onPrimary = Color(0xFF3E0B14),
    primaryContainer = Color(0xFF6B1F2A), onPrimaryContainer = Color(0xFFFFD9DD),
    secondaryContainer = Color(0xFF4A151D), onSecondaryContainer = Color(0xFFFFD9DD),
    background = Color(0xFF2A181B), onBackground = Color(0xFFF2E0E2),
    surface = Color(0xFF2A181B), onSurface = Color(0xFFF2E0E2),
    surfaceVariant = Color(0xFF4A151D), onSurfaceVariant = Color(0xFFD9BFC3),
    surfaceContainer = Color(0xFF331C20), outline = Color(0xFFA08589)
).tuned()

/** Azul en modo oscuro, corregido: fondo azul noche y acento azul vivo. */
fun blueDarkScheme(): ColorScheme = darkColorScheme(
    primary = Color(0xFF2796FF), onPrimary = Color(0xFF0B2447),
    primaryContainer = Color(0xFF0F3F7A), onPrimaryContainer = Color(0xFFD6E8FF),
    secondaryContainer = Color(0xFF0A2F5E), onSecondaryContainer = Color(0xFFE7E8F1),
    background = Color(0xFF141F2D), onBackground = Color(0xFFE7E8F1),
    surface = Color(0xFF141F2D), onSurface = Color(0xFFE7E8F1),
    surfaceVariant = Color(0xFF0A2F5E), onSurfaceVariant = Color(0xFFC3CEDC),
    surfaceContainer = Color(0xFF1A2839), outline = Color(0xFF8798AD)
).tuned()

/** Spotify: negro, verde Spotify y grises. Solo oscuro. */
fun spotifyScheme(): ColorScheme = darkColorScheme(
    primary = Color(0xFF2DD060), onPrimary = Color(0xFF0A0A0A),
    primaryContainer = Color(0xFF1F1F1F), onPrimaryContainer = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFF242424), onSecondaryContainer = Color(0xFFFFE6D5),
    background = Color(0xFF000000), onBackground = Color(0xFFFFE6D5),
    surface = Color(0xFF000000), onSurface = Color(0xFFFFE6D5),
    surfaceVariant = Color(0xFF282828), onSurfaceVariant = Color(0xFFB3B3B3),
    surfaceContainer = Color(0xFF121212), outline = Color(0xFF7A7A7A)
).tuned()

/** Esquema armado con 5 colores: fondo, contenedor (píldoras y pistas), acento, texto sobre el acento y texto. */
private fun themed(dark: Boolean, bg: Long, cont: Long, pri: Long, onPri: Long, on: Long): ColorScheme {
    val bgC = Color(bg)
    val onC = Color(on)
    fun mix(a: Float) = onC.copy(alpha = a).compositeOver(bgC)
    return (if (dark) darkColorScheme(
        primary = Color(pri), onPrimary = Color(onPri), primaryContainer = Color(cont), onPrimaryContainer = onC,
        secondaryContainer = Color(cont), onSecondaryContainer = onC, background = bgC, onBackground = onC,
        surface = bgC, onSurface = onC, surfaceVariant = Color(cont), onSurfaceVariant = mix(.75f),
        surfaceContainer = mix(.06f), outline = mix(.5f)
    ) else lightColorScheme(
        primary = Color(pri), onPrimary = Color(onPri), primaryContainer = Color(cont), onPrimaryContainer = onC,
        secondaryContainer = Color(cont), onSecondaryContainer = onC, background = bgC, onBackground = onC,
        surface = bgC, onSurface = onC, surfaceVariant = Color(cont), onSurfaceVariant = mix(.75f),
        surfaceContainer = mix(.06f), outline = mix(.5f)
    )).tuned()
}

fun orangeLight(): ColorScheme = themed(false, 0xFFFAE6DE, 0xFFFCD7C8, 0xFFFC7A48, 0xFFFCE2D7, 0xFF230C05)

/** Colores base rediseñados: 0 verde, 1 violeta, 2 azul, 3 rojo, 4 turquesa, 5 amarillo (claro y oscuro). */
fun customSeedScheme(idx: Int, dark: Boolean): ColorScheme? = when (idx) {
    0 -> if (dark) themed(true, 0xFF1A2520, 0xFF184B34, 0xFF16C274, 0xFF0F3D28, 0xFFE6F4EA)
         else themed(false, 0xFFE1F5EC, 0xFFCDF7E4, 0xFF16EE8A, 0xFFE4F8EE, 0xFF0A321E)
    1 -> if (dark) themed(true, 0xFF291828, 0xFF4F1846, 0xFFD850C4, 0xFF501946, 0xFFF5E1F3)
         else themed(false, 0xFFF8E0F4, 0xFFFDC8F2, 0xFFEC40D2, 0xFFFAD7F5, 0xFF280A28)
    2 -> if (dark) blueDarkScheme() else themed(false, 0xFFE1ECF8, 0xFFC7E1FA, 0xFF2694FF, 0xFFDCEEFF, 0xFF19283C)
    3 -> if (dark) redDarkScheme() else themed(false, 0xFFFAE0E2, 0xFFFCC8CC, 0xFFF65F6E, 0xFFFCD7DC, 0xFF320F14)
    4 -> if (dark) themed(true, 0xFF142625, 0xFF0E4E4C, 0xFF1CC4B2, 0xFF08403C, 0xFFE2F5F3)
         else themed(false, 0xFFDAF6F3, 0xFFBEF0EA, 0xFF14D6C4, 0xFFD6FAF6, 0xFF06302C)
    5 -> if (dark) themed(true, 0xFF262111, 0xFF54420A, 0xFFF2BA14, 0xFF463205, 0xFFF7F0DC)
         else themed(false, 0xFFFAF3D6, 0xFFFCE8AA, 0xFFF8C410, 0xFFFEF4CD, 0xFF322305)
    else -> null
}

/**
 * seedIdx: -6 = Pastel de cumpleaños, -5 = Chocolate, -4 = Monocromo, -3 = Halloween, -2 = Naranja,
 * -1 = colores dinámicos del sistema (Android 12+), 0.. = colores base (3 = rojo).
 */
@Composable
fun MiPlayerTheme(mode: String, seedIdx: Int, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (seedIdx) {
        -3, -5, -7 -> true
        -6 -> false
        else -> when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    }
    val cs = when {
        seedIdx == -7 -> spotifyScheme()
        seedIdx == -6 -> pastelScheme()
        seedIdx == -5 -> chocolateScheme()
        seedIdx == -4 -> monoScheme(dark)
        seedIdx == -3 -> halloweenScheme()
        seedIdx == -1 && Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        seedIdx == -2 && !dark -> orangeLight()
        seedIdx < 0 -> orangeScheme(dark)
        else -> customSeedScheme(seedIdx, dark) ?: schemeFromSeed(seeds[seedIdx.coerceIn(0, seeds.lastIndex)], dark)
    }
    MaterialTheme(colorScheme = cs, content = content)
}
